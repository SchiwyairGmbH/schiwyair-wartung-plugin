<?php

namespace Schiwyair\Wartung;

defined('ABSPATH') || exit;

/**
 * Angaben für den Sicherheits-Check der Zentrale. Nur WordPress-eigene Funktionen,
 * nichts wird verändert.
 */
final class StatusSecurity
{
    /** Mehr Administratoren werden nicht einzeln gemeldet. */
    private const MAX_ADMINS = 50;

    public static function collect(): array
    {
        return [
            'administrators' => Status::section([self::class, 'administrators']),
            // Editor für Plugin- und Theme-Dateien im Backend
            'file_edit_disabled' => defined('DISALLOW_FILE_EDIT') && DISALLOW_FILE_EDIT,
            // true = von diesem Plugin abgeschaltet, false = steht so in der wp-config.php (oder ist an)
            'file_edit_disabled_by_plugin' => Plugin::$fileEditorDisabled,
            'file_mods_disabled' => defined('DISALLOW_FILE_MODS') && DISALLOW_FILE_MODS,
            'debug' => [
                'enabled' => defined('WP_DEBUG') && WP_DEBUG,
                // Fehlermeldungen für Besucher sichtbar
                'display' => defined('WP_DEBUG') && WP_DEBUG && (!defined('WP_DEBUG_DISPLAY') || WP_DEBUG_DISPLAY),
            ],
            'registration' => [
                'open' => (bool) get_option('users_can_register'),
                'default_role' => (string) get_option('default_role'),
            ],
        ];
    }

    /** Benutzer mit vollen Rechten: Ein unbekannter neuer Administrator ist ein typisches Zeichen für einen Einbruch. */
    public static function administrators(): array
    {
        $users = get_users([
            'role' => 'administrator',
            'orderby' => 'ID',
            'order' => 'ASC',
            'number' => self::MAX_ADMINS + 1,
            'fields' => ['ID', 'user_login', 'user_registered'],
        ]);

        $items = [];
        foreach (array_slice($users, 0, self::MAX_ADMINS) as $user) {
            $registered = strtotime((string) $user->user_registered . ' UTC');
            $items[] = [
                'id' => (int) $user->ID,
                'login' => (string) $user->user_login,
                'registered_at' => $registered ? (int) $registered : null,
            ];
        }

        return [
            'items' => $items,
            'truncated' => count($users) > self::MAX_ADMINS,
        ];
    }
}
