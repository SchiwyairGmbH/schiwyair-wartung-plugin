<?php

namespace Schiwyair\Wartung;

defined('ABSPATH') || exit;

final class Plugin
{
    public const REST_NAMESPACE = 'schiwyair-wartung/v1';

    /** true, wenn dieses Plugin den Datei-Editor abgeschaltet hat (nicht die wp-config.php) */
    public static $fileEditorDisabled = false;

    /**
     * Schaltet den Editor für Plugin- und Theme-Dateien im Backend ab, solange das Plugin aktiv ist.
     * WordPress prüft die Konstante erst bei der Rechteprüfung (map_meta_cap in wp-includes/capabilities.php),
     * deshalb reicht es, sie beim Laden des Plugins zu setzen. Steht sie schon in der wp-config.php, gilt jene.
     * Abschaltbar unter Einstellungen → Wartungszentrale.
     */
    private static function disableFileEditor(): void
    {
        if (defined('DISALLOW_FILE_EDIT') || (string) get_option(Schema::OPTION_FILE_EDITOR_OFF, '1') === '0') {
            return;
        }
        define('DISALLOW_FILE_EDIT', true);
        self::$fileEditorDisabled = true;
    }

    public static function init(): void
    {
        self::disableFileEditor();

        // Nur REST und Admin, keine Hooks im Frontend.
        add_action('rest_api_init', [self::class, 'onRestApiInit']);

        // Updates für dieses Plugin selbst (nur Filter, die WordPress bei der Update-Suche aufruft)
        SelfUpdate::init();

        // Formulartest der Zentrale: wirkt nur mit gültigem Einmal-Cookie
        FormTest::maybeActivate();

        if (is_admin()) {
            add_action('admin_init', [Schema::class, 'maybeUpgrade']);
            Settings::init();
        }
    }

    public static function onRestApiInit(): void
    {
        Schema::maybeUpgrade();
        Rest::registerRoutes();
    }
}
