<?php

namespace Schiwyair\Wartung;

defined('ABSPATH') || exit;

/**
 * Feste Plugins installieren und einrichten (ab 0.14.0): WP Statistics und Wordfence.
 *
 * Nur diese beiden, nur von wordpress.org, über denselben Weg wie „Installieren“ im Backend
 * (plugins_api, Plugin_Upgrader). Danach werden sie so eingestellt, wie die Agentur es vorgibt.
 * Option-Namen stehen in docs/fundstellen.md (im Quellcode der Plugins nachgelesen).
 */
final class Setup
{
    public const PLUGINS = [
        'wp-statistics' => 'wp-statistics/wp-statistics.php',
        'wordfence' => 'wordfence/wordfence.php',
    ];

    public static function run(string $slug, string $license = ''): array
    {
        if (!isset(self::PLUGINS[$slug])) {
            return self::fail($slug, 'bad_request', 'Dieses Plugin richtet die Zentrale nicht ein.');
        }
        $license = strtolower(trim($license));
        if ($license !== '' && ($slug !== 'wordfence' || !preg_match('/^[a-f0-9]{20,200}$/', $license))) {
            return self::fail($slug, 'bad_request', 'Der Lizenzschlüssel hat nicht das richtige Format (nur Ziffern und a bis f).');
        }
        foreach (['file.php', 'misc.php', 'plugin.php', 'plugin-install.php', 'class-wp-upgrader.php'] as $file) {
            require_once ABSPATH . 'wp-admin/includes/' . $file;
        }
        if (get_filesystem_method() !== 'direct') {
            return self::fail($slug, 'filesystem', 'WordPress kann Dateien nicht direkt schreiben (FTP-Zugang nötig).');
        }
        if (!Lock::acquire('setup:' . $slug, 600)) {
            return self::fail($slug, 'locked', 'Es läuft gerade ein anderer Vorgang.');
        }
        if (function_exists('set_time_limit')) {
            @set_time_limit(600);
        }
        ob_start();
        $steps = [];
        try {
            $file = self::PLUGINS[$slug];
            if (!array_key_exists($file, get_plugins())) {
                $installed = self::install($slug);
                if ($installed !== true) {
                    return self::fail($slug, 'install_failed', $installed);
                }
                $steps[] = 'installiert';
                wp_clean_plugins_cache();
            }
            if (!is_plugin_active($file)) {
                // Nicht still: Die Plugins legen beim Aktivieren ihre Tabellen an
                $activated = activate_plugin($file);
                if (is_wp_error($activated)) {
                    return self::fail($slug, 'activate_failed', Redact::text($activated->get_error_message(), 200));
                }
                $steps[] = 'aktiviert';
            }
            $configured = $slug === 'wp-statistics' ? self::configureStatistics() : self::configureWordfence($license);
            $steps = array_merge($steps, $configured['steps']);
            $result = ['ok' => true, 'slug' => $slug, 'steps' => $steps] + $configured['extra'];
        } catch (\Throwable $e) {
            $result = self::fail($slug, 'exception', 'Fehler beim Einrichten: ' . Redact::text($e->getMessage(), 200));
        } finally {
            ob_end_clean();
            Lock::release();
        }
        Log::add('setup', $result['ok'] ? 'ok' : 'error', $result['ok']
            ? sprintf('%s eingerichtet: %s', $slug, implode(', ', $steps))
            : sprintf('%s: %s', $slug, $result['message'] ?? ''));
        return $result;
    }

    /** @return true|string true oder Fehlermeldung */
    private static function install(string $slug)
    {
        $api = plugins_api('plugin_information', ['slug' => $slug, 'fields' => ['sections' => false]]);
        if (is_wp_error($api) || empty($api->download_link)) {
            return 'wordpress.org ist nicht erreichbar oder kennt das Plugin nicht.';
        }
        // Nur Pakete von wordpress.org
        $host = (string) wp_parse_url((string) $api->download_link, PHP_URL_HOST);
        if (!in_array($host, ['downloads.wordpress.org', 'wordpress.org'], true)) {
            return 'Unerwartete Download-Adresse, nicht installiert.';
        }
        if (!empty($api->requires) && version_compare(get_bloginfo('version'), (string) $api->requires, '<')) {
            return sprintf('Braucht WordPress %s, hier läuft %s.', $api->requires, get_bloginfo('version'));
        }
        if (!empty($api->requires_php) && version_compare(PHP_VERSION, (string) $api->requires_php, '<')) {
            return sprintf('Braucht PHP %s, hier läuft %s.', $api->requires_php, PHP_VERSION);
        }
        $skin = new \WP_Ajax_Upgrader_Skin();
        $upgrader = new \Plugin_Upgrader($skin);
        $result = $upgrader->install((string) $api->download_link);
        if ($result !== true) {
            $error = is_wp_error($result) ? $result : $skin->get_errors();
            $message = is_wp_error($error) && $error->has_errors() ? implode(' ', $error->get_error_messages()) : 'Installation fehlgeschlagen.';
            return Redact::text(wp_strip_all_tags($message), 200);
        }
        return true;
    }

    /**
     * WP Statistics: datenschutzfreundlich (IP gekürzt und verschlüsselt, kein Browser-Kennzeichen,
     * Admins nicht mitzählen), keine Bericht-Mails, keine Datenweitergabe an den Hersteller.
     */
    private static function configureStatistics(): array
    {
        $current = get_option('wp_statistics');
        $current = is_array($current) ? $current : [];
        $wanted = [
            'anonymize_ips' => true,
            'hash_ips' => true,
            'store_ua' => false,
            'exclude_administrator' => true,
            'time_report' => '0',
            'share_anonymous_data' => false,
        ];
        update_option('wp_statistics', array_merge($current, $wanted));
        return ['steps' => ['datenschutzfreundlich eingestellt', 'Bericht-Mails aus'], 'extra' => []];
    }

    /**
     * Wordfence: Firewall, Schutz vor Passwort-Raten und geplante Scans an, alle Mails von Wordfence aus
     * (die Zentrale meldet selbst). Lizenzschlüssel optional, wie „Install License“ im Backend.
     */
    private static function configureWordfence(string $license): array
    {
        if (!class_exists('wfConfig')) {
            return ['steps' => ['Wordfence lädt erst beim nächsten Aufruf, Einstellungen bitte erneut anstoßen'], 'extra' => ['pending' => true]];
        }
        $on = ['firewallEnabled', 'loginSecurityEnabled', 'scheduledScansEnabled'];
        $off = [
            'alertOn_update', 'alertOn_scanIssues', 'alertOn_throttle', 'alertOn_block', 'alertOn_loginLockout', 'alertOn_breachLogin',
            'alertOn_lostPasswdForm', 'alertOn_adminLogin', 'alertOn_firstAdminLoginOnly', 'alertOn_nonAdminLogin',
            'alertOn_firstNonAdminLoginOnly', 'alertOn_wordfenceDeactivated', 'alertOn_wafDeactivated',
            'email_summary_enabled', 'wafAlertOnAttacks',
        ];
        foreach ($on as $key) {
            \wfConfig::set($key, 1);
        }
        foreach ($off as $key) {
            \wfConfig::set($key, 0);
        }
        $steps = ['Firewall, Schutz vor Passwort-Raten und Scans an', 'Wordfence-Mails aus'];
        $extra = ['licensed' => (string) \wfConfig::get('apiKey', '') !== ''];

        if ($license !== '' && strtolower((string) \wfConfig::get('apiKey', '')) !== $license) {
            if (!class_exists('wfAPI') || !class_exists('wfUtils')) {
                $steps[] = 'Lizenz nicht eingetragen (Wordfence noch nicht geladen)';
            } else {
                try {
                    $api = new \wfAPI($license, \wfUtils::getWPVersion());
                    $existing = (string) \wfConfig::get('apiKey', '');
                    $res = $api->call('check_api_key', [], $existing !== '' ? ['previousLicense' => $existing] : []);
                    if (!empty($res['ok']) && isset($res['isPaid'])) {
                        $isPaid = \wfUtils::truthyToBoolean($res['isPaid']);
                        \wfConfig::set('apiKey', $license);
                        \wfConfig::set('isPaid', $isPaid);
                        if (!$isPaid && class_exists('wfLicense')) {
                            \wfConfig::set('keyType', \wfLicense::KEY_TYPE_FREE);
                        }
                        $steps[] = 'Lizenz eingetragen';
                        $extra['licensed'] = true;
                    } elseif (!empty($res['_hasKeyConflict'])) {
                        $steps[] = 'Lizenz wird schon auf einer anderen Seite benutzt';
                    } else {
                        $steps[] = 'Lizenz von Wordfence nicht angenommen';
                    }
                } catch (\Throwable $e) {
                    $steps[] = 'Lizenz nicht eingetragen: ' . Redact::text($e->getMessage(), 120);
                }
            }
        }
        return ['steps' => $steps, 'extra' => $extra];
    }

    private static function fail(string $slug, string $code, string $message): array
    {
        return ['ok' => false, 'slug' => $slug, 'code' => $code, 'message' => $message];
    }
}
