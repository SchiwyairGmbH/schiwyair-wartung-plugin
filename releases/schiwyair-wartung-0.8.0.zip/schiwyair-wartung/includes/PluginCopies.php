<?php

namespace Schiwyair\Wartung;

defined('ABSPATH') || exit;

/**
 * Kopien von Plugin-Ordnern vor einem Update (für den späteren Rollback, Etappe 4).
 * Ablage möglichst außerhalb des Webroots, sonst in einem Ordner mit zufälligem Namen
 * in wp-content mit Zugriffssperre. Aufbewahrt werden die letzten 3 Kopien je Plugin.
 */
final class PluginCopies
{
    public const KEEP = 3;

    /**
     * @return array{path: string, location: string}|null
     */
    public static function base(): ?array
    {
        $stored = get_option(Schema::OPTION_COPY_DIR, '');
        if (is_array($stored) && !empty($stored['path']) && @is_dir($stored['path']) && @is_writable($stored['path'])) {
            return $stored;
        }

        $outside = self::outsideWebroot();
        $base = $outside
            ? ['path' => $outside, 'location' => 'outside_webroot']
            : self::insideWpContent();
        if ($base === null) {
            return null;
        }
        update_option(Schema::OPTION_COPY_DIR, $base);
        return $base;
    }

    private static function outsideWebroot(): ?string
    {
        $docroot = isset($_SERVER['DOCUMENT_ROOT']) ? realpath((string) $_SERVER['DOCUMENT_ROOT']) : false;
        if (!$docroot) {
            return null; // Ohne bekannten Webroot lässt sich „außerhalb" nicht sicher bestimmen
        }
        $parent = realpath(dirname(untrailingslashit(ABSPATH)));
        if (!$parent) {
            return null;
        }
        $candidate = $parent . DIRECTORY_SEPARATOR . 'schiwyair-wartung-kopien';
        $docrootNorm = rtrim(wp_normalize_path($docroot), '/') . '/';
        if (strpos(rtrim(wp_normalize_path($candidate), '/') . '/', $docrootNorm) === 0) {
            return null; // läge im Webroot
        }
        if (!@is_dir($candidate) && !@mkdir($candidate, 0700)) {
            return null;
        }
        return @is_writable($candidate) ? $candidate : null;
    }

    private static function insideWpContent(): ?array
    {
        $dir = WP_CONTENT_DIR . '/sww-kopien-' . bin2hex(random_bytes(8));
        if (!@mkdir($dir, 0750)) {
            return null;
        }
        // Zugriffssperre für Apache und IIS; bei Nginx schützt der zufällige Name.
        @file_put_contents($dir . '/index.php', "<?php\n// Kein Zugriff.\n");
        @file_put_contents($dir . '/.htaccess', "Require all denied\n<IfModule !mod_authz_core.c>\nDeny from all\n</IfModule>\n");
        @file_put_contents($dir . '/web.config', '<?xml version="1.0"?><configuration><system.webServer><authorization><deny users="*" /></authorization></system.webServer></configuration>');
        return ['path' => $dir, 'location' => 'wp_content_protected'];
    }

    /**
     * Kopiert einen Plugin-Ordner (oder ein Einzeldatei-Plugin).
     *
     * @return array{id: string, location: string, files: int}|null
     */
    public static function create(string $slug, string $source, string $version): ?array
    {
        $base = self::base();
        if ($base === null || !preg_match('/^[A-Za-z0-9._-]+$/', $slug)) {
            return null;
        }
        $id = gmdate('Ymd-His') . '_' . preg_replace('/[^A-Za-z0-9.]+/', '-', $version);
        $target = $base['path'] . '/' . $slug . '/' . $id;
        if (!wp_mkdir_p($target)) {
            return null;
        }

        $files = 0;
        if (is_dir($source)) {
            $files = self::copyDir($source, $target . '/files');
        } elseif (is_file($source) && @mkdir($target . '/files') && @copy($source, $target . '/files/' . basename($source))) {
            $files = 1;
        }
        if ($files === 0) {
            self::removeDir($target);
            return null;
        }

        @file_put_contents($target . '/meta.json', wp_json_encode([
            'slug' => $slug,
            'version' => $version,
            'created_at' => time(),
            'source' => basename($source),
            'single_file' => !is_dir($source),
        ]));
        self::prune($slug);

        return ['id' => $id, 'location' => $base['location'], 'files' => $files];
    }

    /**
     * Spielt eine Kopie zurück (Standard: die neueste). Der aktuelle Ordner wird erst
     * beiseitegelegt und nur bei Erfolg gelöscht, sonst wiederhergestellt.
     *
     * @return array Ergebnis; bei Fehlern ok=false mit code und message
     */
    public static function restore(string $slug, string $copyId = ''): array
    {
        $fail = static function (string $code, string $message) use ($slug) {
            Log::add('rollback', 'error', "{$slug}: {$message}");
            return ['ok' => false, 'slug' => $slug, 'code' => $code, 'message' => $message];
        };
        $copies = self::list($slug);
        $copy = null;
        foreach ($copies as $candidate) {
            if ($copyId === '' || $candidate['id'] === $copyId) {
                $copy = $candidate;
                break;
            }
        }
        if ($copy === null) {
            return $fail('no_copy', 'Keine Sicherungskopie für dieses Plugin vorhanden');
        }
        $base = self::base();
        $dir = $base['path'] . '/' . $slug . '/' . $copy['id'];
        $meta = json_decode((string) @file_get_contents($dir . '/meta.json'), true);
        $singleFile = is_array($meta) && !empty($meta['single_file']);
        $source = $dir . '/files';
        $target = $singleFile ? WP_PLUGIN_DIR . '/' . basename((string) $meta['source']) : WP_PLUGIN_DIR . '/' . $slug;

        require_once ABSPATH . 'wp-admin/includes/plugin.php';
        $file = null;
        foreach (array_keys(get_plugins()) as $candidate) {
            $candidateSlug = dirname($candidate) === '.' ? basename($candidate, '.php') : dirname($candidate);
            if ($candidateSlug === $slug) {
                $file = $candidate;
                break;
            }
        }
        $wasActive = $file !== null && is_plugin_active($file);
        $current = $file !== null ? (string) (get_plugin_data(WP_PLUGIN_DIR . '/' . $file, false, false)['Version'] ?? '') : '';

        if (!Lock::acquire('rollback:' . $slug)) {
            return $fail('locked', 'Es läuft bereits ein anderer Vorgang.');
        }
        try {
            // Aktuellen Stand beiseitelegen (Punkt-Name: WordPress ignoriert den Ordner)
            $parked = WP_PLUGIN_DIR . '/.sww-alt-' . $slug . '-' . time();
            if (file_exists($target) && !@rename($target, $parked)) {
                return $fail('move_failed', 'Aktueller Plugin-Ordner ließ sich nicht verschieben');
            }
            $ok = $singleFile
                ? @copy($source . '/' . basename($target), $target)
                : self::copyDir($source, $target) > 0;
            if (!$ok) {
                if (file_exists($target)) {
                    is_dir($target) ? self::removeDir($target) : @unlink($target);
                }
                if (file_exists($parked)) {
                    @rename($parked, $target);
                }
                return $fail('copy_failed', 'Kopie ließ sich nicht zurückspielen, alter Stand wiederhergestellt');
            }
            if (file_exists($parked)) {
                is_dir($parked) ? self::removeDir($parked) : @unlink($parked);
            }
        } finally {
            Lock::release();
        }

        if (function_exists('opcache_reset')) {
            @opcache_reset();
        }
        wp_clean_plugins_cache();
        $reactivated = false;
        if ($wasActive && $file !== null && !is_plugin_active($file)) {
            $reactivated = !is_wp_error(activate_plugin($file, '', is_multisite() && is_plugin_active_for_network($file), true));
        }
        Log::add('rollback', 'ok', sprintf('%s: %s → %s zurückgespielt', $slug, $current, $copy['version']), ['copy' => $copy['id']]);
        return [
            'ok' => true,
            'slug' => $slug,
            'from_version' => $current,
            'to_version' => $copy['version'],
            'copy' => $copy['id'],
            'active' => $file !== null && is_plugin_active($file),
            'reactivated' => $reactivated,
        ];
    }

    /** @return array<int, array{id: string, version: string, created_at: int}> */
    public static function list(string $slug): array
    {
        $base = self::base();
        if ($base === null || !preg_match('/^[A-Za-z0-9._-]+$/', $slug)) {
            return [];
        }
        $dir = $base['path'] . '/' . $slug;
        $items = [];
        foreach ((array) @scandir($dir) as $entry) {
            if ($entry === '.' || $entry === '..' || !is_dir($dir . '/' . $entry)) {
                continue;
            }
            $meta = json_decode((string) @file_get_contents($dir . '/' . $entry . '/meta.json'), true);
            $items[] = [
                'id' => $entry,
                'version' => is_array($meta) ? (string) ($meta['version'] ?? '') : '',
                'created_at' => is_array($meta) ? (int) ($meta['created_at'] ?? 0) : 0,
            ];
        }
        usort($items, static function ($a, $b) {
            return strcmp($b['id'], $a['id']);
        });
        return $items;
    }

    private static function prune(string $slug): void
    {
        $base = self::base();
        foreach (array_slice(self::list($slug), self::KEEP) as $old) {
            self::removeDir($base['path'] . '/' . $slug . '/' . $old['id']);
        }
    }

    private static function copyDir(string $from, string $to): int
    {
        if (!wp_mkdir_p($to)) {
            return 0;
        }
        $count = 0;
        $iterator = new \RecursiveIteratorIterator(
            new \RecursiveDirectoryIterator($from, \FilesystemIterator::SKIP_DOTS),
            \RecursiveIteratorIterator::SELF_FIRST
        );
        foreach ($iterator as $item) {
            /** @var \SplFileInfo $item */
            if ($item->isLink()) {
                continue;
            }
            $relative = substr($item->getPathname(), strlen($from) + 1);
            $dest = $to . '/' . $relative;
            if ($item->isDir()) {
                if (!@is_dir($dest) && !@mkdir($dest, 0755, true)) {
                    return 0;
                }
            } elseif (!@copy($item->getPathname(), $dest)) {
                return 0;
            } else {
                $count++;
            }
        }
        return $count;
    }

    public static function removeDir(string $dir): void
    {
        if (!is_dir($dir) || is_link($dir)) {
            return;
        }
        $iterator = new \RecursiveIteratorIterator(
            new \RecursiveDirectoryIterator($dir, \FilesystemIterator::SKIP_DOTS),
            \RecursiveIteratorIterator::CHILD_FIRST
        );
        foreach ($iterator as $item) {
            $item->isDir() && !$item->isLink() ? @rmdir($item->getPathname()) : @unlink($item->getPathname());
        }
        @rmdir($dir);
    }
}
