<?php

namespace Schiwyair\Wartung;

defined('ABSPATH') || exit;

/**
 * Sperrmodus: Im Backend kann niemand Plugins oder Themes installieren, hochladen, aktualisieren
 * oder löschen, und dieses Plugin lässt sich nicht abschalten. Updates laufen über die Zentrale
 * (signierte Anfragen, ohne Rechteprüfung eines Benutzers) und über die automatischen Updates von
 * WordPress, die ebenfalls keine Benutzerrechte prüfen.
 *
 * Ein- und ausgeschaltet wird nur über die Zentrale (POST /lockdown). Im Backend gibt es keinen
 * Schalter, und die Einstellungen dieses Plugins lassen sich bei aktiver Sperre nicht ändern
 * (auch nicht über wp-admin/options.php): Sonst könnte ein übernommenes Administrator-Konto
 * einen eigenen Schlüssel eintragen und die Sperre mit diesem aufheben.
 *
 * Notausgang mit Zugang zum Server: define('SCHIWYAIR_WARTUNG_LOCKDOWN_OFF', true); in der wp-config.php.
 *
 * Grenzen: Schützt nicht vor Code, der schon auf der Seite läuft (andere Plugins mit Dateimanager,
 * Code-Schnipseln oder Wiederherstellung von Backups) und nicht vor direktem Zugriff auf Server
 * oder Datenbank.
 */
final class Lockdown
{
    public const OPTION = 'schiwyair_wartung_lockdown';
    /** Längste Aufhebung am Stück */
    public const MAX_UNLOCK_MINUTES = 240;

    /** Rechte, die bei aktiver Sperre niemand hat (siehe map_meta_cap in wp-includes/capabilities.php). */
    private const DENIED_CAPS = [
        'install_plugins', 'upload_plugins', 'update_plugins', 'delete_plugins', 'edit_plugins',
        'install_themes', 'upload_themes', 'update_themes', 'delete_themes', 'edit_themes',
        'update_core', 'edit_files', 'update_languages', 'install_languages',
    ];

    /** Optionen, die bei aktiver Sperre nur das Plugin selbst ändern darf */
    private const PROTECTED_OPTIONS = [
        Schema::OPTION_PUBLIC_KEY,
        Schema::OPTION_IP_ALLOWLIST,
        Schema::OPTION_CLIENT_IP_SOURCE,
    ];

    /** true, während das Plugin selbst den Zustand speichert */
    private static $internalWrite = false;

    public static function init(): void
    {
        $state = self::state();
        if (!$state['enabled']) {
            return;
        }
        // Der Zustand selbst ist immer geschützt, auch während einer Aufhebung
        add_filter('pre_update_option_' . self::OPTION, [self::class, 'guardOwnOption'], 10, 2);
        if (!$state['active']) {
            return;
        }
        add_filter('map_meta_cap', [self::class, 'filterCaps'], 10, 4);
        foreach (self::PROTECTED_OPTIONS as $option) {
            add_filter('pre_update_option_' . $option, [self::class, 'guardOwnOption'], 10, 2);
        }
        // Dieses Plugin bleibt aktiv, auch wenn jemand die Liste der aktiven Plugins direkt überschreibt
        add_filter('pre_update_option_active_plugins', [self::class, 'keepActive'], 10, 2);
        add_filter('pre_update_site_option_active_sitewide_plugins', [self::class, 'keepActiveNetwork'], 10, 2);
        if (is_admin()) {
            add_action('admin_notices', [self::class, 'notice']);
            add_action('network_admin_notices', [self::class, 'notice']);
        }
    }

    /** @return array{enabled:bool,active:bool,unlocked_until:int,disabled_by_config:bool} */
    public static function state(): array
    {
        $disabledByConfig = defined('SCHIWYAIR_WARTUNG_LOCKDOWN_OFF') && SCHIWYAIR_WARTUNG_LOCKDOWN_OFF;
        $raw = get_option(self::OPTION, null);
        $enabled = is_array($raw) && !empty($raw['enabled']);
        // Unlesbarer Wert (etwa von Hand überschrieben): sicherheitshalber gesperrt
        if ($raw !== null && $raw !== false && !is_array($raw)) {
            $enabled = true;
        }
        $until = is_array($raw) && isset($raw['unlocked_until']) ? (int) $raw['unlocked_until'] : 0;
        $enabled = $enabled && !$disabledByConfig;
        return [
            'enabled' => $enabled,
            'active' => $enabled && $until <= time(),
            'unlocked_until' => $until > time() ? $until : 0,
            'disabled_by_config' => $disabledByConfig,
        ];
    }

    /**
     * Setzt den Zustand (nur über die signierte Anfrage der Zentrale).
     *
     * @param int $unlockMinutes 0 = gesperrt, sonst so lange aufgehoben
     */
    public static function set(bool $enabled, int $unlockMinutes = 0): array
    {
        $unlockMinutes = max(0, min(self::MAX_UNLOCK_MINUTES, $unlockMinutes));
        $value = ['enabled' => $enabled, 'unlocked_until' => $enabled && $unlockMinutes > 0 ? time() + $unlockMinutes * 60 : 0];
        self::$internalWrite = true;
        try {
            if (get_option(self::OPTION, null) === null) {
                add_option(self::OPTION, $value, '', 'yes');
            } else {
                update_option(self::OPTION, $value, 'yes');
            }
        } finally {
            self::$internalWrite = false;
        }
        if (!$enabled) {
            $summary = 'Sperrmodus ausgeschaltet';
        } elseif ($unlockMinutes > 0) {
            $summary = 'Sperrmodus für ' . $unlockMinutes . ' Minuten aufgehoben';
        } else {
            $summary = 'Sperrmodus eingeschaltet';
        }
        Log::add('lockdown', 'ok', $summary);
        return self::state();
    }

    /** Eigene Einstellungen ändert bei aktiver Sperre nur das Plugin selbst. */
    public static function guardOwnOption($value, $oldValue)
    {
        return self::$internalWrite ? $value : $oldValue;
    }

    public static function filterCaps(array $caps, string $cap, int $userId, array $args): array
    {
        if (in_array($cap, self::DENIED_CAPS, true)) {
            $caps[] = 'do_not_allow';
        } elseif ($cap === 'deactivate_plugin' && isset($args[0]) && $args[0] === plugin_basename(SCHIWYAIR_WARTUNG_FILE)) {
            $caps[] = 'do_not_allow';
        }
        return $caps;
    }

    public static function keepActive($value, $oldValue)
    {
        $own = plugin_basename(SCHIWYAIR_WARTUNG_FILE);
        if (!is_array($value)) {
            return $oldValue;
        }
        if (is_array($oldValue) && in_array($own, $oldValue, true) && !in_array($own, $value, true)) {
            $value[] = $own;
        }
        return $value;
    }

    public static function keepActiveNetwork($value, $oldValue)
    {
        $own = plugin_basename(SCHIWYAIR_WARTUNG_FILE);
        if (!is_array($value)) {
            return $oldValue;
        }
        if (is_array($oldValue) && isset($oldValue[$own]) && !isset($value[$own])) {
            $value[$own] = $oldValue[$own];
        }
        return $value;
    }

    /** Hinweis im Backend, damit niemand nach dem fehlenden Knopf „Installieren" sucht. */
    public static function notice(): void
    {
        $screen = function_exists('get_current_screen') ? get_current_screen() : null;
        $screens = ['plugins', 'plugins-network', 'plugin-install', 'themes', 'themes-network', 'theme-install', 'update-core', 'update-core-network', 'settings_page_schiwyair-wartung'];
        if (!$screen || !in_array($screen->id, $screens, true) || !current_user_can('activate_plugins')) {
            return;
        }
        echo '<div class="notice notice-info"><p><strong>Sperrmodus der Wartungszentrale ist aktiv.</strong> '
            . 'Plugins und Themes lassen sich hier nicht installieren, hochladen, aktualisieren oder löschen. '
            . 'Das schützt die Seite, falls ein Konto in falsche Hände gerät. Updates übernimmt die Schiwyair GmbH. '
            . 'Für eigene Arbeiten an der Seite bitte bei der Schiwyair GmbH melden, die Sperre wird dann zeitweise aufgehoben.</p></div>';
    }
}
