<?php

namespace Schiwyair\Wartung;

defined('ABSPATH') || exit;

/**
 * Sperre gegen gleichzeitige Updates auf dieser Seite. add_option ist atomar:
 * Nur eine Anfrage kann die Option anlegen.
 */
final class Lock
{
    public static function acquire(string $what, int $seconds = 600): bool
    {
        $value = ['what' => $what, 'until' => time() + $seconds];
        if (add_option(Schema::OPTION_LOCK, $value, '', 'no')) {
            return true;
        }
        $current = get_option(Schema::OPTION_LOCK);
        if (is_array($current) && isset($current['until']) && (int) $current['until'] < time()) {
            // Abgelaufene Sperre (z. B. nach einem Abbruch) entfernen und neu versuchen
            delete_option(Schema::OPTION_LOCK);
            return add_option(Schema::OPTION_LOCK, $value, '', 'no');
        }
        return false;
    }

    public static function release(): void
    {
        delete_option(Schema::OPTION_LOCK);
    }

    public static function current(): ?array
    {
        $current = get_option(Schema::OPTION_LOCK);
        return is_array($current) && (int) ($current['until'] ?? 0) >= time() ? $current : null;
    }
}
