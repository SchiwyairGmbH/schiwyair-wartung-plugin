<?php

namespace Schiwyair\Wartung;

defined('ABSPATH') || exit;

/**
 * Ein einzelnes Update (Plugin, Theme oder Core) über die Upgrader-Klassen von WordPress,
 * wie beim Klick auf „Jetzt aktualisieren" in der Pluginliste (bulk_upgrade mit Ajax-Skin:
 * Plugins bleiben aktiv).
 */
final class Updater
{
    /**
     * @return array Ergebnis; bei Fehlern ok=false mit code und message
     */
    public static function run(string $type, string $target, string $version = ''): array
    {
        self::loadIncludes();

        if (!in_array($type, ['plugin', 'theme', 'core'], true)) {
            return self::fail($type, $target, 'bad_request', 'Unbekannter Typ');
        }
        if (get_filesystem_method() !== 'direct') {
            return self::fail($type, $target, 'filesystem', 'WordPress kann Dateien nicht direkt schreiben (FTP-Zugang nötig). Updates sind so nicht möglich.');
        }
        if (Backup::runningJob() !== null) {
            return self::fail($type, $target, 'backup_running', 'Es läuft gerade ein Backup.');
        }
        if (!Lock::acquire($type . ':' . $target)) {
            return self::fail($type, $target, 'locked', 'Es läuft bereits ein anderes Update.');
        }

        if (function_exists('set_time_limit')) {
            @set_time_limit(600);
        }
        ob_start();
        try {
            if ($type === 'plugin') {
                $result = self::plugin($target);
            } elseif ($type === 'theme') {
                $result = self::theme($target);
            } else {
                $result = self::core($version);
            }
        } catch (\Throwable $e) {
            $result = self::fail($type, $target, 'exception', 'Fehler beim Update: ' . Redact::text($e->getMessage(), 200));
        } finally {
            ob_end_clean();
            Lock::release();
        }

        Log::add(
            'update',
            $result['ok'] ? 'ok' : (in_array($result['code'], ['up_to_date', 'no_package', 'requirements', 'locked', 'backup_running'], true) ? 'skipped' : 'error'),
            $result['ok']
                ? sprintf('%s %s: %s → %s', $type, $target !== '' ? $target : 'WordPress', $result['from_version'] ?? '?', $result['to_version'] ?? '?')
                : sprintf('%s %s: %s', $type, $target !== '' ? $target : 'WordPress', $result['message'] ?? $result['code']),
            array_intersect_key($result, array_flip(['code', 'from_version', 'to_version', 'copy']))
        );
        return $result;
    }

    private static function loadIncludes(): void
    {
        foreach (['file.php', 'misc.php', 'plugin.php', 'theme.php', 'update.php', 'class-wp-upgrader.php'] as $file) {
            require_once ABSPATH . 'wp-admin/includes/' . $file;
        }
    }

    private static function fail(string $type, string $target, string $code, string $message, array $extra = []): array
    {
        return array_merge(['ok' => false, 'type' => $type, 'target' => $target, 'code' => $code, 'message' => $message], $extra);
    }

    /** Liest die Fehler aus dem Upgrader-Skin. */
    private static function skinErrors(\WP_Ajax_Upgrader_Skin $skin, $result): string
    {
        $messages = [];
        if (is_wp_error($result)) {
            $messages = array_merge($messages, $result->get_error_messages());
        }
        $errors = $skin->get_errors();
        if (is_wp_error($errors) && $errors->has_errors()) {
            $messages = array_merge($messages, $errors->get_error_messages());
        }
        $messages = array_unique(array_filter(array_map('wp_strip_all_tags', $messages)));
        return Redact::text($messages ? implode(' ', $messages) : 'Unbekannter Fehler beim Update', 400);
    }

    private static function plugin(string $slug): array
    {
        $file = null;
        foreach (array_keys(get_plugins()) as $candidate) {
            $candidateSlug = dirname($candidate) === '.' ? basename($candidate, '.php') : dirname($candidate);
            if ($candidateSlug === $slug || $candidate === $slug) {
                $file = $candidate;
                break;
            }
        }
        if ($file === null) {
            return self::fail('plugin', $slug, 'not_found', 'Plugin nicht gefunden');
        }

        // Frisch nach Updates suchen, damit das Paket aktuell ist
        delete_site_transient('update_plugins');
        wp_update_plugins();
        $transient = get_site_transient('update_plugins');
        $offer = isset($transient->response[$file]) ? (object) $transient->response[$file] : null;
        $data = get_plugin_data(WP_PLUGIN_DIR . '/' . $file, false, false);
        $from = (string) $data['Version'];

        if ($offer === null || empty($offer->new_version)) {
            $known = isset($transient->no_update[$file]) ? (object) $transient->no_update[$file] : null;
            if ($known && !empty($known->new_version) && version_compare((string) $known->new_version, $from, '>')) {
                return self::fail('plugin', $slug, 'requirements', 'Die neue Version braucht ein neueres WordPress oder PHP.', ['from_version' => $from]);
            }
            return self::fail('plugin', $slug, 'up_to_date', 'Kein Update verfügbar', ['from_version' => $from]);
        }
        if (empty($offer->package)) {
            return self::fail('plugin', $slug, 'no_package', 'Kein Download-Paket, meist fehlende oder abgelaufene Lizenz.', ['from_version' => $from]);
        }

        $wasActive = is_plugin_active($file);
        $source = dirname($file) === '.' ? WP_PLUGIN_DIR . '/' . $file : WP_PLUGIN_DIR . '/' . dirname($file);
        $copy = PluginCopies::create($slug, $source, $from);
        if ($copy === null) {
            return self::fail('plugin', $slug, 'copy_failed', 'Die Sicherungskopie des Plugins konnte nicht angelegt werden. Update abgebrochen.', ['from_version' => $from]);
        }

        $skin = new \WP_Ajax_Upgrader_Skin();
        $upgrader = new \Plugin_Upgrader($skin);
        $results = $upgrader->bulk_upgrade([$file]);
        $single = is_array($results) ? ($results[$file] ?? null) : $results;
        if (!$single || is_wp_error($single) || is_wp_error($skin->result)) {
            return self::fail('plugin', $slug, 'upgrade_failed', self::skinErrors($skin, is_wp_error($single) ? $single : $skin->result), ['from_version' => $from, 'copy' => $copy]);
        }

        wp_clean_plugins_cache();
        $after = get_plugin_data(WP_PLUGIN_DIR . '/' . $file, false, false);
        $reactivated = false;
        if ($wasActive && !is_plugin_active($file)) {
            $reactivated = !is_wp_error(activate_plugin($file, '', is_plugin_active_for_network($file), true));
        }

        return [
            'ok' => true,
            'type' => 'plugin',
            'target' => $slug,
            'from_version' => $from,
            'to_version' => (string) $after['Version'],
            'active' => is_plugin_active($file),
            'reactivated' => $reactivated,
            'copy' => $copy,
        ];
    }

    private static function theme(string $stylesheet): array
    {
        $theme = wp_get_theme($stylesheet);
        if (!$theme->exists()) {
            return self::fail('theme', $stylesheet, 'not_found', 'Theme nicht gefunden');
        }
        delete_site_transient('update_themes');
        wp_update_themes();
        $transient = get_site_transient('update_themes');
        $offer = $transient->response[$stylesheet] ?? null;
        $from = (string) $theme->get('Version');
        if (!$offer || empty($offer['new_version'])) {
            return self::fail('theme', $stylesheet, 'up_to_date', 'Kein Update verfügbar', ['from_version' => $from]);
        }
        if (empty($offer['package'])) {
            return self::fail('theme', $stylesheet, 'no_package', 'Kein Download-Paket, meist fehlende oder abgelaufene Lizenz.', ['from_version' => $from]);
        }

        $skin = new \WP_Ajax_Upgrader_Skin();
        $upgrader = new \Theme_Upgrader($skin);
        $results = $upgrader->bulk_upgrade([$stylesheet]);
        $single = is_array($results) ? ($results[$stylesheet] ?? null) : $results;
        if (!$single || is_wp_error($single) || is_wp_error($skin->result)) {
            return self::fail('theme', $stylesheet, 'upgrade_failed', self::skinErrors($skin, is_wp_error($single) ? $single : $skin->result), ['from_version' => $from]);
        }
        wp_clean_themes_cache();
        return [
            'ok' => true,
            'type' => 'theme',
            'target' => $stylesheet,
            'from_version' => $from,
            'to_version' => (string) wp_get_theme($stylesheet)->get('Version'),
        ];
    }

    private static function core(string $version): array
    {
        global $wp_version;
        $from = $wp_version;
        if ($version === '' || !preg_match('/^\d+\.\d+(\.\d+)?$/', $version)) {
            return self::fail('core', '', 'bad_request', 'Zielversion fehlt', ['from_version' => $from]);
        }
        wp_version_check([], true);
        $update = find_core_update($version, get_locale()) ?: find_core_update($version, 'en_US');
        if (!$update) {
            return self::fail('core', '', 'up_to_date', 'Diese WordPress-Version wird nicht angeboten', ['from_version' => $from]);
        }
        if (!empty($update->php_version) && version_compare(PHP_VERSION, $update->php_version, '<')) {
            return self::fail('core', '', 'requirements', 'WordPress ' . $version . ' braucht PHP ' . $update->php_version, ['from_version' => $from]);
        }

        $skin = new \WP_Ajax_Upgrader_Skin();
        $upgrader = new \Core_Upgrader($skin);
        $result = $upgrader->upgrade($update, ['attempt_rollback' => true]);
        if (is_wp_error($result) || !$result) {
            return self::fail('core', '', 'upgrade_failed', self::skinErrors($skin, $result), ['from_version' => $from]);
        }
        return [
            'ok' => true,
            'type' => 'core',
            'target' => '',
            'from_version' => $from,
            'to_version' => is_string($result) ? $result : $version,
        ];
    }
}
