<?php

namespace Schiwyair\Wartung;

defined('ABSPATH') || exit;

/**
 * UpdraftPlus-Backup anstoßen und verfolgen, auf demselben Weg wie der Knopf „Jetzt sichern"
 * (kostenlose Version, keine WP-CLI). Fundstellen: docs/fundstellen.md
 */
final class Backup
{
    /** Ohne Lebenszeichen im Protokoll gilt ein Backup nach dieser Zeit als hängengeblieben. */
    private const STALL_SECONDS = 1200;

    public static function available(): ?string
    {
        global $updraftplus;
        if (!class_exists('UpdraftPlus') || !class_exists('UpdraftPlus_Options') || !is_object($updraftplus)) {
            return 'UpdraftPlus ist nicht aktiv';
        }
        foreach (['backup_time_nonce', 'close_browser_connection', 'jobdata_getarray', 'backups_dir_location'] as $method) {
            if (!method_exists($updraftplus, $method)) {
                return 'Diese UpdraftPlus-Version wird nicht unterstützt (' . $method . ' fehlt)';
            }
        }
        return null;
    }

    /**
     * Schickt die Antwort an die Zentrale, schließt die Verbindung und führt dann das
     * Backup im selben PHP-Aufruf aus, wie UpdraftPlus es beim Knopf „Jetzt sichern" tut.
     * Weitere Etappen laufen anschließend über WP-Cron. Kehrt nicht zurück.
     */
    public static function startAndDetach(): void
    {
        global $updraftplus;

        $nonce = $updraftplus->backup_time_nonce();
        // Merken, bis UpdraftPlus seinen ersten Wiederaufnahme-Termin angelegt hat
        update_option(Schema::OPTION_BACKUP_JOB, ['job' => $nonce, 'started' => time()], false);
        Log::add('backup', 'info', 'Backup gestartet', ['job' => $nonce]);

        $response = wp_json_encode([
            'started' => true,
            'job' => $nonce,
            'time' => time(),
        ]);

        if (!headers_sent()) {
            status_header(202);
            header('Cache-Control: no-store, max-age=0');
        }
        ignore_user_abort(true);
        if (function_exists('set_time_limit')) {
            @set_time_limit(900);
        }
        $updraftplus->close_browser_connection($response);

        $options = ['nocloud' => false, 'use_nonce' => $nonce, 'always_keep' => false];
        do_action('updraft_backupnow_backup_all', apply_filters('updraft_backupnow_options', $options, []));
        exit;
    }

    /** Läuft gerade irgendein UpdraftPlus-Backup? */
    public static function runningJob(): ?string
    {
        $started = get_option(Schema::OPTION_BACKUP_JOB);
        if (class_exists('UpdraftPlus_Options') && is_array($started) && !empty($started['job']) && time() - (int) $started['started'] < self::STALL_SECONDS) {
            $last = \UpdraftPlus_Options::get_updraft_option('updraft_last_backup', null);
            if (!is_array($last) || ($last['backup_nonce'] ?? '') !== $started['job']) {
                return (string) $started['job'];
            }
        }
        $crons = function_exists('_get_cron_array') ? (array) _get_cron_array() : [];
        foreach ($crons as $hooks) {
            if (is_array($hooks) && isset($hooks['updraft_backup_resume'])) {
                foreach ((array) $hooks['updraft_backup_resume'] as $event) {
                    if (isset($event['args'][1])) {
                        return (string) $event['args'][1];
                    }
                }
            }
        }
        return null;
    }

    /**
     * Stand eines Backups. state: finished, running, stalled, unknown.
     */
    public static function status(string $job): array
    {
        global $updraftplus;

        $last = \UpdraftPlus_Options::get_updraft_option('updraft_last_backup', null);
        $lastBackup = StatusUpdraftPlus::lastBackup();
        $finished = is_array($last) && isset($last['backup_nonce']) && (string) $last['backup_nonce'] === $job;

        $jobdata = (array) $updraftplus->jobdata_getarray($job);
        $nextResumption = null;
        $crons = function_exists('_get_cron_array') ? (array) _get_cron_array() : [];
        foreach ($crons as $time => $hooks) {
            foreach ((array) ($hooks['updraft_backup_resume'] ?? []) as $event) {
                if (isset($event['args'][1]) && (string) $event['args'][1] === $job) {
                    $nextResumption = (int) $time;
                }
            }
        }

        $logFile = rtrim((string) $updraftplus->backups_dir_location(), '/') . '/log.' . $job . '.txt';
        $logModified = @is_file($logFile) ? (int) @filemtime($logFile) : null;
        $lastMessage = $logModified ? self::lastLogLine($logFile) : null;

        $services = isset($jobdata['service']) ? self::services($jobdata['service']) : [];
        // Nach dem Abschluss löscht UpdraftPlus die Auftragsdaten. Der Speicherort steht dann im Backup-Verlauf.
        if ($finished && $services === [] && method_exists('UpdraftPlus_Backup_History', 'get_backup_set_by_nonce')) {
            $set = \UpdraftPlus_Backup_History::get_backup_set_by_nonce($job);
            if (is_array($set) && isset($set['service'])) {
                $services = self::services($set['service']);
            }
        }

        if ($finished) {
            $state = 'finished';
        } elseif ($nextResumption !== null || (!empty($jobdata['jobstatus']) && $jobdata['jobstatus'] !== 'finished'
            && $logModified && time() - $logModified < self::STALL_SECONDS)) {
            $state = 'running';
        } elseif ($logModified && time() - $logModified >= self::STALL_SECONDS) {
            $state = 'stalled';
        } else {
            $state = 'unknown';
        }

        return [
            'job' => $job,
            'state' => $state,
            'stage' => isset($jobdata['jobstatus']) ? (string) $jobdata['jobstatus'] : null,
            'started_at' => isset($jobdata['backup_time']) ? (int) $jobdata['backup_time'] : null,
            'next_resumption_at' => $nextResumption,
            'log_modified_at' => $logModified,
            'last_message' => $lastMessage,
            'remote_services' => $services,
            'result' => $finished ? $lastBackup : null,
        ];
    }

    /** Externe Speicher eines Backups. UpdraftPlus speichert eine Liste, einen einzelnen Namen oder „none". */
    private static function services($value): array
    {
        return array_values(array_filter(array_map('strval', (array) $value), static function ($s) {
            return $s !== '' && $s !== 'none';
        }));
    }

    private static function lastLogLine(string $file): ?string
    {
        $size = (int) @filesize($file);
        $handle = @fopen($file, 'rb');
        if ($handle === false) {
            return null;
        }
        fseek($handle, max(0, $size - 4096));
        $chunk = (string) fread($handle, 4096);
        fclose($handle);
        $lines = array_values(array_filter(preg_split('/\r\n|\n|\r/', $chunk), static function ($l) {
            return trim($l) !== '';
        }));
        $line = end($lines);
        return $line === false ? null : Redact::text(preg_replace('/^\d+\.\d+\s+\(\d+\)\s+/', '', $line), 200);
    }
}
