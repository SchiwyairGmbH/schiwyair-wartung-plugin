<?php

namespace Schiwyair\Wartung;

defined('ABSPATH') || exit;

/**
 * Entfernt sensible Angaben aus Texten, bevor sie die Seite verlassen.
 */
final class Redact
{
    public static function text(string $text, int $maxLength = 500): string
    {
        // Serverpfade kürzen
        $root = rtrim(str_replace('\\', '/', ABSPATH), '/');
        if ($root !== '') {
            $text = str_replace([$root, str_replace('/', '\\', $root)], '[ABSPATH]', $text);
        }
        // E-Mail-Adressen
        $text = (string) preg_replace('/[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}/', '[email]', $text);
        // IPv4-Adressen
        $text = (string) preg_replace('/\b(?:\d{1,3}\.){3}\d{1,3}\b/', '[ip]', $text);
        // Schlüssel=Wert-Paare mit sensiblen Namen, auch in URLs und JSON
        $text = (string) preg_replace(
            '/((?:pass(?:word|wd)?|pwd|token|secret|api[_-]?key|auth|key|license|licence|nonce|session|cookie)["\']?\s*[=:]\s*["\']?)[^\s&"\',;]+/i',
            '$1[redacted]',
            $text
        );
        // Lange Zufallszeichenketten (Tokens, Hashes)
        $text = (string) preg_replace('/\b[A-Za-z0-9_\-]{32,}\b/', '[redacted]', $text);

        if (strlen($text) > $maxLength) {
            $text = substr($text, 0, $maxLength) . ' …';
        }
        return $text;
    }
}
