<?php

namespace Schiwyair\Wartung;

defined('ABSPATH') || exit;

/**
 * WordPress-Konten für das Team der Agentur (ab 0.13.0).
 *
 * Die Zentrale sieht, wer auf der Seite Administrator oder Redakteur ist (mit Mailadresse, damit sie
 * ihre Teammitglieder erkennt), und kann ein Konto für ein Teammitglied anlegen. Ein Passwort geht
 * dabei nie über die Leitung: WordPress schickt der Person selbst die Mail zum Festlegen des Passworts,
 * wie beim Anlegen im Backend. Konten anderer Rollen (Kunden eines Shops usw.) werden nicht gemeldet.
 */
final class Accounts
{
    public const ROLES = ['administrator', 'editor'];
    private const MAX = 50;

    /** @return array{items: list<array<string,mixed>>, truncated: bool} */
    public static function list(): array
    {
        $users = get_users([
            'role__in' => self::ROLES,
            'orderby' => 'ID',
            'order' => 'ASC',
            'number' => self::MAX + 1,
            'fields' => 'all',
        ]);
        $items = [];
        foreach (array_slice($users, 0, self::MAX) as $user) {
            $registered = strtotime((string) $user->user_registered . ' UTC');
            $items[] = [
                'id' => (int) $user->ID,
                'login' => (string) $user->user_login,
                'email' => strtolower((string) $user->user_email),
                'roles' => array_values(array_intersect((array) $user->roles, self::ROLES)),
                'registered_at' => $registered ? (int) $registered : null,
            ];
        }
        return ['items' => $items, 'truncated' => count($users) > self::MAX];
    }

    /**
     * Legt ein Konto an und lässt WordPress die Mail zum Festlegen des Passworts schicken.
     *
     * @return array<string,mixed> ok=true mit id/login, sonst ok=false mit code und message
     */
    public static function create(string $email, string $name, string $role): array
    {
        $email = strtolower(trim($email));
        $name = trim(wp_strip_all_tags($name));
        if (!is_email($email) || strlen($email) > 100 || !in_array($role, self::ROLES, true) || strlen($name) > 80) {
            return self::fail('bad_request', 'Ungültige Angaben');
        }
        if (is_multisite()) {
            return self::fail('multisite', 'Auf Multisite-Installationen legt das Plugin keine Konten an.');
        }
        $existing = get_user_by('email', $email);
        if ($existing) {
            return self::fail('exists', 'Für diese Mailadresse gibt es schon ein Konto.', [
                'id' => (int) $existing->ID,
                'login' => (string) $existing->user_login,
                'roles' => array_values((array) $existing->roles),
            ]);
        }

        require_once ABSPATH . 'wp-admin/includes/user.php';
        $login = self::freeLogin($email);
        $parts = preg_split('/\s+/', $name, 2) ?: [];
        $userId = wp_insert_user([
            'user_login' => $login,
            'user_email' => $email,
            // Zufällig und nirgends gespeichert: Die Person legt ihr Passwort über die Mail selbst fest
            'user_pass' => wp_generate_password(40, true, true),
            'display_name' => $name !== '' ? $name : $login,
            'first_name' => $parts[0] ?? '',
            'last_name' => $parts[1] ?? '',
            'role' => $role,
        ]);
        if (is_wp_error($userId)) {
            return self::fail('create_failed', Redact::text($userId->get_error_message(), 200));
        }
        // Mail „Passwort festlegen" an die Person (wie „Neuen Benutzer hinzufügen" mit Benachrichtigung)
        wp_new_user_notification($userId, null, 'user');
        $user = get_userdata($userId);
        $registered = $user ? strtotime((string) $user->user_registered . ' UTC') : false;
        Log::add('account', 'ok', sprintf('Konto %s (%s) als %s angelegt', $login, $email, $role));
        return ['ok' => true, 'id' => (int) $userId, 'login' => $login, 'roles' => [$role], 'registered_at' => $registered ? (int) $registered : null];
    }

    /** Benutzername aus dem Teil vor dem @, bei Bedarf mit Zahl, damit er frei ist */
    private static function freeLogin(string $email): string
    {
        $base = sanitize_user(strtolower((string) strstr($email, '@', true)), true);
        $base = $base !== '' ? substr($base, 0, 50) : 'team';
        $login = $base;
        for ($i = 2; username_exists($login); $i++) {
            $login = $base . $i;
        }
        return $login;
    }

    private static function fail(string $code, string $message, array $extra = []): array
    {
        return array_merge(['ok' => false, 'code' => $code, 'message' => $message], $extra);
    }
}
