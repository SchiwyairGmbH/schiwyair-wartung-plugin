<?php

namespace Schiwyair\Wartung;

defined('ABSPATH') || exit;

/**
 * Entfernt sensible Angaben aus Texten, bevor sie die Seite verlassen.
 */
final class Redact
{
    public static function text(string $text, int $maxLength = 500): string
    {
        // Serverpfade kürzen
        $root = rtrim(str_replace('\\', '/', ABSPATH), '/');
        if ($root !== '') {
            $text = str_replace([$root, str_replace('/', '\\', $root)], '[ABSPATH]', $text);
        }
        // E-Mail-Adressen
        $text = (string) preg_replace('/[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}/', '[email]', $text);
        // IPv4- und IPv6-Adressen
        $text = (string) preg_replace('/\b(?:\d{1,3}\.){3}\d{1,3}\b/', '[ip]', $text);
        $text = (string) preg_replace('/\b(?:[0-9a-f]{1,4}:){2,7}[0-9a-f]{0,4}\b/i', '[ip]', $text);
        // Datenbank-Benutzer in Fehlermeldungen ('benutzer'@'host')
        $text = (string) preg_replace("/'[^'\s]{1,80}'@'[^'\s]{1,120}'/", '[db-user]', $text);
        // Schlüssel=Wert-Paare mit sensiblen Namen, auch in URLs und JSON
        $text = (string) preg_replace(
            '/((?:pass(?:word|wd)?|pwd|token|secret|api[_-]?key|auth|key|license|licence|nonce|session|cookie)["\']?\s*[=:]\s*["\']?)[^\s&"\',;]+/i',
            '$1[redacted]',
            $text
        );
        // Lange Zufallszeichenketten (Tokens, Hashes)
        $text = (string) preg_replace('/\b[A-Za-z0-9_\-]{32,}\b/', '[redacted]', $text);

        if (strlen($text) > $maxLength) {
            $text = substr($text, 0, $maxLength) . ' …';
        }
        return $text;
    }
}
