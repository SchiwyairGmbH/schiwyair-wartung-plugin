<?php

namespace Schiwyair\Wartung;

defined('ABSPATH') || exit;

/**
 * Plugins und ungenutzte Themes löschen (Befehl der Zentrale), über dieselben Funktionen
 * wie „Löschen" in der Plugin- bzw. Themeliste von WordPress (delete_plugins, delete_theme).
 * Aktive Plugins löscht die Zentrale in Schritten (ab 0.12.0): deaktivieren, Seite prüfen, bei Problemen
 * wieder aktivieren, sonst löschen. Gelöscht wird nur, was inaktiv ist. Das aktive Theme, sein Eltern-Theme
 * und dieses Plugin selbst werden nie gelöscht. Vor dem Löschen eines Plugins wird eine Kopie angelegt.
 */
final class Remover
{
    public static function run(string $type, string $slug, string $action = 'delete'): array
    {
        foreach (['file.php', 'misc.php', 'plugin.php', 'theme.php'] as $file) {
            require_once ABSPATH . 'wp-admin/includes/' . $file;
        }
        if (!in_array($type, ['plugin', 'theme'], true) || !PluginCopies::validSlug($slug)
            || !in_array($action, ['delete', 'deactivate', 'activate'], true) || ($type === 'theme' && $action !== 'delete')
        ) {
            return self::fail($type, $slug, 'bad_request', 'Ungültige Angaben');
        }
        if ($action !== 'delete') {
            return self::toggle($slug, $action === 'activate');
        }
        if (get_filesystem_method() !== 'direct') {
            return self::fail($type, $slug, 'filesystem', 'WordPress kann Dateien nicht direkt schreiben (FTP-Zugang nötig).');
        }
        if (!Lock::acquire('delete:' . $type . ':' . $slug, 300)) {
            return self::fail($type, $slug, 'locked', 'Es läuft gerade ein Update.');
        }
        ob_start();
        try {
            $result = $type === 'plugin' ? self::plugin($slug) : self::theme($slug);
        } catch (\Throwable $e) {
            $result = self::fail($type, $slug, 'exception', 'Fehler beim Löschen: ' . Redact::text($e->getMessage(), 200));
        } finally {
            ob_end_clean();
            Lock::release();
        }
        Log::add('delete', $result['ok'] ? 'ok' : 'error', $result['ok']
            ? sprintf('%s %s %s gelöscht', $type === 'plugin' ? 'Plugin' : 'Theme', $result['name'] ?? $slug, $result['version'] ?? '')
            : sprintf('%s %s: %s', $type, $slug, $result['message'] ?? ''));
        return $result;
    }

    /** @return array{0:string|null,1:array|null} Plugin-Datei und Kopfdaten zum Slug */
    private static function find(string $slug): array
    {
        foreach (get_plugins() as $candidate => $info) {
            $candidateSlug = dirname($candidate) === '.' ? basename($candidate, '.php') : dirname($candidate);
            if ($candidateSlug === $slug) {
                return [$candidate, $info];
            }
        }
        return [null, null];
    }

    /** Plugin deaktivieren oder wieder aktivieren (Schritte beim Löschen aktiver Plugins). */
    private static function toggle(string $slug, bool $activate): array
    {
        [$file, $data] = self::find($slug);
        if ($file === null) {
            return self::fail('plugin', $slug, 'not_found', 'Plugin nicht gefunden');
        }
        if ($file === plugin_basename(SCHIWYAIR_WARTUNG_FILE)) {
            return self::fail('plugin', $slug, 'not_allowed', 'Das Wartungs-Plugin lässt sich nicht aus der Zentrale abschalten.');
        }
        $network = is_multisite() && is_plugin_active_for_network($file);
        $name = (string) ($data['Name'] ?? $slug);
        if ($activate) {
            $result = activate_plugin($file, '', $network, true);
            if (is_wp_error($result)) {
                return self::fail('plugin', $slug, 'activate_failed', Redact::text($result->get_error_message(), 200));
            }
        } else {
            deactivate_plugins([$file], true, $network);
        }
        $active = is_plugin_active($file);
        Log::add('delete', $active === $activate ? 'ok' : 'error', sprintf('Plugin %s %s', $name, $activate ? 'wieder aktiviert' : 'deaktiviert (vor dem Löschen)'));
        return ['ok' => $active === $activate, 'type' => 'plugin', 'slug' => $slug, 'name' => $name, 'active' => $active, 'network' => $network]
            + ($active === $activate ? [] : ['code' => 'toggle_failed', 'message' => 'Zustand des Plugins hat sich nicht geändert']);
    }

    private static function plugin(string $slug): array
    {
        [$file, $data] = self::find($slug);
        if ($file === null) {
            return self::fail('plugin', $slug, 'not_found', 'Plugin nicht gefunden');
        }
        if ($file === plugin_basename(SCHIWYAIR_WARTUNG_FILE)) {
            return self::fail('plugin', $slug, 'not_allowed', 'Das Wartungs-Plugin lässt sich nicht aus der Zentrale löschen.');
        }
        if (is_plugin_active($file) || (is_multisite() && is_plugin_active_for_network($file))) {
            return self::fail('plugin', $slug, 'active', 'Das Plugin ist aktiv. Nur inaktive Plugins werden gelöscht.');
        }
        $version = (string) ($data['Version'] ?? '');
        $source = dirname($file) === '.' ? WP_PLUGIN_DIR . '/' . $file : WP_PLUGIN_DIR . '/' . dirname($file);
        $copy = PluginCopies::create($slug, $source, $version);
        if ($copy === null) {
            return self::fail('plugin', $slug, 'copy_failed', 'Die Sicherungskopie konnte nicht angelegt werden. Nicht gelöscht.');
        }
        $deleted = delete_plugins([$file]);
        if ($deleted !== true) {
            $message = is_wp_error($deleted) ? $deleted->get_error_message() : 'WordPress konnte das Plugin nicht löschen.';
            return self::fail('plugin', $slug, 'delete_failed', Redact::text($message, 200), ['copy' => $copy]);
        }
        wp_clean_plugins_cache();
        return ['ok' => true, 'type' => 'plugin', 'slug' => $slug, 'name' => (string) ($data['Name'] ?? $slug), 'version' => $version, 'copy' => $copy];
    }

    private static function theme(string $stylesheet): array
    {
        $theme = wp_get_theme($stylesheet);
        if (!$theme->exists()) {
            return self::fail('theme', $stylesheet, 'not_found', 'Theme nicht gefunden');
        }
        if ($stylesheet === get_stylesheet() || $stylesheet === get_template()) {
            return self::fail('theme', $stylesheet, 'active', 'Das Theme ist aktiv oder Eltern-Theme des aktiven Themes.');
        }
        $name = (string) $theme->get('Name');
        $version = (string) $theme->get('Version');
        $deleted = delete_theme($stylesheet);
        if ($deleted !== true) {
            $message = is_wp_error($deleted) ? $deleted->get_error_message() : 'WordPress konnte das Theme nicht löschen.';
            return self::fail('theme', $stylesheet, 'delete_failed', Redact::text($message, 200));
        }
        wp_clean_themes_cache();
        return ['ok' => true, 'type' => 'theme', 'slug' => $stylesheet, 'name' => $name, 'version' => $version, 'copy' => null];
    }

    private static function fail(string $type, string $slug, string $code, string $message, array $extra = []): array
    {
        return array_merge(['ok' => false, 'type' => $type, 'slug' => $slug, 'code' => $code, 'message' => $message], $extra);
    }
}
