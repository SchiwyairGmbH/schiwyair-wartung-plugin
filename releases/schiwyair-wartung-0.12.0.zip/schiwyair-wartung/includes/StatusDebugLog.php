<?php

namespace Schiwyair\Wartung;

defined('ABSPATH') || exit;

/**
 * Letzte Einträge aus debug.log. Gelesen wird nur die Datei, die WordPress
 * selbst dafür verwendet, gekürzt und ohne sensible Angaben.
 */
final class StatusDebugLog
{
    private const READ_BYTES = 65536;
    private const MAX_LINES = 50;

    public static function collect(): array
    {
        $logging = defined('WP_DEBUG') && WP_DEBUG && defined('WP_DEBUG_LOG') && WP_DEBUG_LOG;
        $path = self::path();

        $base = [
            'logging_enabled' => $logging,
            'exists' => false,
            'publicly_reachable_location' => false,
            'size_bytes' => null,
            'modified_at' => null,
            'counts' => null,
            'lines' => [],
            'reason' => null,
        ];

        if ($path === null || !@is_file($path)) {
            $base['reason'] = $logging ? 'Keine debug.log vorhanden' : 'Fehlerprotokoll ist ausgeschaltet und keine debug.log vorhanden';
            return $base;
        }

        $base['exists'] = true;
        $base['publicly_reachable_location'] = strpos(wp_normalize_path($path), wp_normalize_path(WP_CONTENT_DIR) . '/') === 0;

        if (!@is_readable($path)) {
            $base['reason'] = 'debug.log ist nicht lesbar';
            return $base;
        }

        $size = (int) @filesize($path);
        $base['size_bytes'] = $size;
        $base['modified_at'] = (int) @filemtime($path);

        $handle = @fopen($path, 'rb');
        if ($handle === false) {
            $base['reason'] = 'debug.log konnte nicht geöffnet werden';
            return $base;
        }
        $offset = max(0, $size - self::READ_BYTES);
        fseek($handle, $offset);
        $chunk = (string) fread($handle, self::READ_BYTES);
        fclose($handle);

        $lines = preg_split('/\r\n|\n|\r/', $chunk);
        if ($offset > 0) {
            array_shift($lines); // erste Zeile ist vermutlich abgeschnitten
        }
        $lines = array_values(array_filter($lines, static function ($line) {
            return trim($line) !== '';
        }));

        $base['counts'] = [
            'fatal' => self::count($lines, '/PHP (Fatal error|Parse error)/'),
            'warning' => self::count($lines, '/PHP Warning/'),
            'notice' => self::count($lines, '/PHP Notice/'),
            'deprecated' => self::count($lines, '/PHP Deprecated/'),
            'scope' => $offset > 0 ? 'letzte 64 KB' : 'ganze Datei',
        ];
        $base['lines'] = array_map(static function ($line) {
            return Redact::text($line, 300);
        }, array_slice($lines, -self::MAX_LINES));

        return $base;
    }

    private static function path(): ?string
    {
        if (defined('WP_DEBUG_LOG') && is_string(WP_DEBUG_LOG) && WP_DEBUG_LOG !== ''
            && !in_array(strtolower(WP_DEBUG_LOG), ['true', 'false', '1', '0'], true)
        ) {
            return WP_DEBUG_LOG;
        }
        return WP_CONTENT_DIR . '/debug.log';
    }

    private static function count(array $lines, string $pattern): int
    {
        return count(preg_grep($pattern, $lines));
    }
}
