<?php

namespace Schiwyair\Wartung;

defined('ABSPATH') || exit;

/**
 * Wordfence (kostenlose Version). Fundstellen: docs/fundstellen.md
 */
final class StatusWordfence
{
    private const PLUGIN_FILE = 'wordfence/wordfence.php';

    public static function collect(): array
    {
        $active = defined('WORDFENCE_VERSION') && class_exists('wfConfig');

        if (!$active) {
            $installed = array_key_exists(self::PLUGIN_FILE, get_plugins());
            return Status::thirdParty(
                self::PLUGIN_FILE,
                false,
                null,
                null,
                $installed ? 'Wordfence ist installiert, aber nicht aktiv' : 'Wordfence ist nicht installiert'
            );
        }

        return Status::thirdParty(self::PLUGIN_FILE, true, (string) WORDFENCE_VERSION, [
            'scan' => Status::section([self::class, 'scan']),
            'issues' => Status::section([self::class, 'issues']),
            'firewall' => Status::section([self::class, 'firewall']),
        ], null);
    }

    public static function scan(): array
    {
        $time = class_exists('wfScanner') ? \wfScanner::shared()->lastScanTime() : \wfConfig::get('scanTime');
        $result = (string) \wfConfig::get('lastScanCompleted', '');
        $failed = class_exists('wfIssues') ? \wfIssues::hasScanFailed() : false;

        return [
            'last_scan_at' => $time ? (int) $time : null,
            'last_scan_ok' => $result === '' ? null : $result === 'ok',
            'last_scan_message' => ($result !== '' && $result !== 'ok') ? Redact::text($result, 300) : null,
            'running' => class_exists('wfScanner') ? (bool) \wfScanner::shared()->isRunning() : null,
            // Scan angefordert, aber noch nicht angelaufen (Wordfence löscht den Eintrag, sobald der Scan loslegt)
            'start_pending' => (int) \wfConfig::get('scanStartAttempt', 0) > 0,
            'failure' => $failed ? (string) $failed : null,
        ];
    }

    public static function issues(): array
    {
        global $wpdb;
        if (!class_exists('wfDB')) {
            return ['open' => null, 'reason' => 'Wordfence-Tabellen nicht ermittelbar'];
        }
        $table = \wfDB::networkTable('wfIssues');
        $table = str_replace('`', '', $table);

        // Bei eingeschalteter Fehleranzeige gäbe wpdb Fehler als HTML aus und zerstörte die JSON-Antwort
        $suppress = $wpdb->suppress_errors(true);
        $rows = $wpdb->get_results(
            "SELECT severity, COUNT(*) AS c FROM `{$table}` WHERE status = 'new' GROUP BY severity",
            ARRAY_A
        );
        $ignored = $wpdb->get_var("SELECT COUNT(*) FROM `{$table}` WHERE status IN ('ignoreP', 'ignoreC')");

        if ($rows === null || $wpdb->last_error !== '') {
            $wpdb->suppress_errors($suppress);
            return ['open' => null, 'reason' => 'Tabelle der Funde nicht lesbar'];
        }

        $bySeverity = ['critical' => 0, 'high' => 0, 'medium' => 0, 'low' => 0, 'none' => 0];
        foreach ($rows as $row) {
            $bySeverity[self::severityName((int) $row['severity'])] += (int) $row['c'];
        }

        // Die offenen Funde selbst (Kurztext wie in Wordfence), die schwersten zuerst
        $items = [];
        $list = $wpdb->get_results(
            "SELECT type, severity, shortMsg, time FROM `{$table}` WHERE status = 'new' ORDER BY severity DESC, time DESC LIMIT 20",
            ARRAY_A
        );
        foreach ((array) $list as $row) {
            $items[] = [
                'type' => (string) $row['type'],
                'severity' => self::severityName((int) $row['severity']),
                'text' => Redact::text(wp_strip_all_tags((string) $row['shortMsg']), 200),
                'time' => (int) $row['time'],
            ];
        }
        $wpdb->suppress_errors($suppress);

        return [
            'open' => array_sum($bySeverity),
            'by_severity' => $bySeverity,
            'items' => $items,
            'ignored' => (int) $ignored,
        ];
    }

    /** Schweregrade laut wfIssues::SEVERITY_* (100, 75, 50, 25, 0). */
    private static function severityName(int $severity): string
    {
        if ($severity >= 100) {
            return 'critical';
        }
        if ($severity >= 75) {
            return 'high';
        }
        if ($severity >= 50) {
            return 'medium';
        }
        if ($severity >= 25) {
            return 'low';
        }
        return 'none';
    }

    public static function firewall(): array
    {
        if (!class_exists('wfFirewall')) {
            return ['mode' => null, 'reason' => 'Firewall-Modul nicht geladen'];
        }
        $firewall = new \wfFirewall();
        return [
            'mode' => (string) $firewall->firewallMode(),
            'protection' => (string) $firewall->protectionMode(),
        ];
    }
}
