<?php

namespace Schiwyair\Wartung;

defined('ABSPATH') || exit;

/**
 * Caches leeren. Jedes Cache-Plugin wird nur angesprochen, wenn es aktiv ist (Funktion, Klasse
 * oder Hook vorhanden). Fundstellen und Prüfstand je Plugin: docs/fundstellen.md
 *
 * Reihenfolge: zuerst, was Dateien neu erzeugt (Elementor-CSS, zusammengefasste CSS/JS),
 * dann die Seiten-Caches, zuletzt der Objekt-Cache. Sonst lägen im Seiten-Cache Verweise auf
 * gerade gelöschte Dateien.
 */
final class Cache
{
    public static function clearAll(): array
    {
        $results = [
            self::run('Elementor (CSS-Dateien)', null, static function () {
                \Elementor\Plugin::$instance->files_manager->clear_cache();
            }, static function () {
                return class_exists('\Elementor\Plugin') && isset(\Elementor\Plugin::$instance->files_manager)
                    && method_exists(\Elementor\Plugin::$instance->files_manager, 'clear_cache');
            }),
            self::run('Autoptimize', null, static function () {
                \autoptimizeCache::clearall();
            }, static function () {
                return class_exists('autoptimizeCache') && method_exists('autoptimizeCache', 'clearall');
            }),
            // Wie der Knopf „Cache leeren" in WP Rocket (do_admin_post_rocket_purge_cache, Fall „all"):
            // Seiten-Cache, zusammengefasste CSS/JS und Cache-Busting-Dateien. Die neuen Minify-Schlüssel,
            // die WP Rocket dabei in seine Einstellungen schreibt, lässt das Plugin aus (keine fremden Einstellungen).
            self::run('WP Rocket', 'rocket_clean_domain', static function () {
                rocket_clean_domain();
                if (function_exists('rocket_clean_minify')) {
                    rocket_clean_minify();
                }
                if (function_exists('rocket_clean_cache_busting')) {
                    rocket_clean_cache_busting();
                }
            }),
            self::run('WP Super Cache', 'wp_cache_clear_cache', static function () {
                wp_cache_clear_cache();
            }),
            self::run('W3 Total Cache', 'w3tc_flush_all', static function () {
                w3tc_flush_all();
            }),
            self::run('LiteSpeed Cache', null, static function () {
                do_action('litespeed_purge_all');
            }, static function () {
                return defined('LSCWP_V') && has_action('litespeed_purge_all');
            }),
            self::run('WP Fastest Cache', 'wpfc_clear_all_cache', static function () {
                // true = auch zusammengefasste CSS/JS, wie „Cache und Minify leeren" in der Werkzeugleiste
                $result = wpfc_clear_all_cache(true);
                if (is_array($result) && isset($result['success']) && $result['success'] === false) {
                    throw new \RuntimeException((string) ($result['message'] ?? 'abgelehnt'));
                }
            }),
            self::run('WP-Optimize', null, static function () {
                wpo_cache_flush();
            }, static function () {
                return function_exists('wpo_cache_flush') && class_exists('WP_Optimize');
            }),
            self::run('Cache Enabler', null, static function () {
                \Cache_Enabler::clear_complete_cache();
            }, static function () {
                return class_exists('Cache_Enabler') && method_exists('Cache_Enabler', 'clear_complete_cache');
            }),
            self::run('Breeze', null, static function () {
                do_action('breeze_clear_all_cache');
            }, static function () {
                return class_exists('Breeze_Admin') && has_action('breeze_clear_all_cache');
            }),
            self::run('SiteGround Speed Optimizer', 'sg_cachepress_purge_everything', static function () {
                sg_cachepress_purge_everything();
            }),
            // Den Hook gibt es nur bei eingeschaltetem Seiten-Cache. Den Cache der Asset-Optimierung leert
            // Hummingbird nur zusammen mit dem Zurücksetzen seiner Einstellungen, deshalb bleibt er unberührt.
            self::run('Hummingbird', null, static function () {
                if (!has_action('wphb_clear_page_cache')) {
                    return 'Seiten-Cache in Hummingbird ist aus';
                }
                do_action('wphb_clear_page_cache');
                return null;
            }, static function () {
                return defined('WPHB_VERSION');
            }),
            self::run('Nginx Helper', null, static function () {
                global $nginx_purger;
                $nginx_purger->purge_all();
            }, static function () {
                global $nginx_purger, $nginx_helper_admin;
                return is_object($nginx_purger) && method_exists($nginx_purger, 'purge_all') && is_object($nginx_helper_admin);
            }),
            self::run('Objekt-Cache', null, static function () {
                wp_cache_flush();
            }, static function () {
                return function_exists('wp_using_ext_object_cache') && wp_using_ext_object_cache();
            }),
        ];

        $cleared = array_values(array_filter($results, static function ($r) {
            return $r['cleared'] === true;
        }));
        $failed = array_values(array_filter($results, static function ($r) {
            return $r['cleared'] === false;
        }));
        Log::add(
            'cache',
            $failed ? 'error' : ($cleared ? 'ok' : 'info'),
            $cleared ? 'Geleert: ' . implode(', ', array_column($cleared, 'name')) : 'Kein Cache-Plugin gefunden',
            ['results' => $results]
        );

        return ['ok' => !$failed, 'caches' => $results];
    }

    private static function run(string $name, ?string $function, callable $clear, ?callable $detect = null): array
    {
        $found = $detect ? (bool) $detect() : ($function !== null && function_exists($function));
        if (!$found) {
            return ['name' => $name, 'found' => false, 'cleared' => null, 'reason' => 'nicht aktiv'];
        }
        try {
            // Rückgabe eines Textes: gefunden, aber nichts zu leeren (Grund)
            $skipped = $clear();
            if (is_string($skipped)) {
                return ['name' => $name, 'found' => true, 'cleared' => null, 'reason' => $skipped];
            }
            return ['name' => $name, 'found' => true, 'cleared' => true, 'reason' => null];
        } catch (\Throwable $e) {
            return ['name' => $name, 'found' => true, 'cleared' => false, 'reason' => Redact::text($e->getMessage(), 200)];
        }
    }
}
