<?php

namespace Schiwyair\Wartung;

defined('ABSPATH') || exit;

/**
 * Sperre gegen gleichzeitige Updates und Rollbacks auf dieser Seite.
 *
 * add_option() ist dafür nicht geeignet: Es fragt erst nach und schreibt dann mit
 * „INSERT … ON DUPLICATE KEY UPDATE", zwei gleichzeitige Anfragen bekämen beide die Sperre.
 * Deshalb direkt „INSERT IGNORE" auf die Optionstabelle: Nur genau eine Anfrage legt die Zeile an.
 */
final class Lock
{
    /** Länger hält keine Sperre, auch wenn ein gespeicherter Wert etwas anderes sagt */
    private const MAX_SECONDS = 3600;

    public static function acquire(string $what, int $seconds = 600): bool
    {
        $seconds = max(1, min(self::MAX_SECONDS, $seconds));
        $value = maybe_serialize(['what' => $what, 'until' => time() + $seconds]);
        if (self::insert($value)) {
            return true;
        }
        // Abgelaufene Sperre (z. B. nach einem Abbruch) entfernen, aber nur genau diese, und neu versuchen
        $raw = self::raw();
        if ($raw !== null && self::parse($raw) === null) {
            global $wpdb;
            $wpdb->query($wpdb->prepare("DELETE FROM {$wpdb->options} WHERE option_name = %s AND option_value = %s", Schema::OPTION_LOCK, $raw));
            self::flushCache();
            return self::insert($value);
        }
        return false;
    }

    public static function release(): void
    {
        global $wpdb;
        $wpdb->query($wpdb->prepare("DELETE FROM {$wpdb->options} WHERE option_name = %s", Schema::OPTION_LOCK));
        self::flushCache();
    }

    public static function current(): ?array
    {
        $raw = self::raw();
        return $raw === null ? null : self::parse($raw);
    }

    /** Gültige, nicht abgelaufene Sperre oder null */
    private static function parse(string $raw): ?array
    {
        $value = maybe_unserialize($raw);
        if (!is_array($value)) {
            return null;
        }
        $until = (int) ($value['until'] ?? 0);
        return $until >= time() && $until <= time() + self::MAX_SECONDS ? $value : null;
    }

    private static function insert(string $serialized): bool
    {
        global $wpdb;
        $suppress = $wpdb->suppress_errors(true);
        $result = $wpdb->query($wpdb->prepare(
            "INSERT IGNORE INTO {$wpdb->options} (option_name, option_value, autoload) VALUES (%s, %s, 'no')",
            Schema::OPTION_LOCK,
            $serialized
        ));
        $wpdb->suppress_errors($suppress);
        self::flushCache();
        return $result === 1;
    }

    /** Direkt aus der Datenbank, am Zwischenspeicher vorbei */
    private static function raw(): ?string
    {
        global $wpdb;
        $raw = $wpdb->get_var($wpdb->prepare("SELECT option_value FROM {$wpdb->options} WHERE option_name = %s", Schema::OPTION_LOCK));
        return $raw === null ? null : (string) $raw;
    }

    private static function flushCache(): void
    {
        wp_cache_delete(Schema::OPTION_LOCK, 'options');
        wp_cache_delete('notoptions', 'options');
    }
}
