<?php

namespace Schiwyair\Wartung;

defined('ABSPATH') || exit;

/**
 * Protokoll der Aktionen auf dieser Seite (GET /log). Behält die letzten 500 Einträge.
 */
final class Log
{
    private const KEEP = 500;

    /**
     * @param string $status ok, error, info, skipped
     */
    public static function add(string $action, string $status, string $summary, array $details = []): void
    {
        global $wpdb;
        $table = Schema::logTable();
        // Fehler (etwa fehlende Tabelle) nicht als HTML in die JSON-Antwort schreiben
        $suppress = $wpdb->suppress_errors(true);
        $wpdb->insert($table, [
            'created_at' => time(),
            'action' => substr($action, 0, 40),
            'status' => substr($status, 0, 20),
            'summary' => substr(Redact::text($summary, 250), 0, 255),
            'details' => $details ? wp_json_encode($details) : null,
        ], ['%d', '%s', '%s', '%s', '%s']);
        $wpdb->suppress_errors($suppress);

        if (wp_rand(1, 20) === 1) {
            $cutoff = (int) $wpdb->get_var("SELECT id FROM `{$table}` ORDER BY id DESC LIMIT 1 OFFSET " . self::KEEP);
            if ($cutoff > 0) {
                $wpdb->query($wpdb->prepare("DELETE FROM `{$table}` WHERE id <= %d", $cutoff));
            }
        }
    }

    public static function recent(int $limit = 50): array
    {
        global $wpdb;
        $limit = max(1, min(200, $limit));
        $rows = $wpdb->get_results(
            $wpdb->prepare('SELECT id, created_at, action, status, summary, details FROM `' . Schema::logTable() . '` ORDER BY id DESC LIMIT %d', $limit),
            ARRAY_A
        );
        return array_map(static function ($row) {
            return [
                'id' => (int) $row['id'],
                'time' => (int) $row['created_at'],
                'action' => $row['action'],
                'status' => $row['status'],
                'summary' => $row['summary'],
                'details' => $row['details'] ? json_decode($row['details'], true) : null,
            ];
        }, is_array($rows) ? $rows : []);
    }
}
