<?php

namespace Schiwyair\Wartung;

defined('ABSPATH') || exit;

final class Plugin
{
    public const REST_NAMESPACE = 'schiwyair-wartung/v1';

    /** true, wenn dieses Plugin den Datei-Editor abgeschaltet hat (nicht die wp-config.php) */
    public static $fileEditorDisabled = false;

    /**
     * Schaltet den Editor für Plugin- und Theme-Dateien im Backend ab, solange das Plugin aktiv ist.
     * WordPress prüft die Konstante erst bei der Rechteprüfung (map_meta_cap in wp-includes/capabilities.php),
     * deshalb reicht es, sie beim Laden des Plugins zu setzen.
     *
     * Bewusst ohne Schalter im Backend: Wer ein Administrator-Konto übernommen hat, könnte ihn sonst einfach umlegen.
     * Eine Ausnahme geht nur über die wp-config.php (define('DISALLOW_FILE_EDIT', false);), also mit Zugang zum Server.
     */
    private static function disableFileEditor(): void
    {
        if (defined('DISALLOW_FILE_EDIT')) {
            return;
        }
        define('DISALLOW_FILE_EDIT', true);
        self::$fileEditorDisabled = true;
    }

    public static function init(): void
    {
        self::disableFileEditor();
        Lockdown::init();

        // Nur REST und Admin, keine Hooks im Frontend.
        add_action('rest_api_init', [self::class, 'onRestApiInit']);

        // Updates für dieses Plugin selbst (nur Filter, die WordPress bei der Update-Suche aufruft)
        SelfUpdate::init();

        // Formulartest der Zentrale: wirkt nur mit gültigem Einmal-Cookie
        FormTest::maybeActivate();

        if (is_admin()) {
            add_action('admin_init', [Schema::class, 'maybeUpgrade']);
            Settings::init();
        }
    }

    public static function onRestApiInit(): void
    {
        // Nur bei Anfragen an dieses Plugin, nicht bei jeder REST-Anfrage der Seite (Editor, Formulare …)
        $uri = isset($_SERVER['REQUEST_URI']) ? (string) $_SERVER['REQUEST_URI'] : '';
        if (strpos($uri, self::REST_NAMESPACE) !== false || strpos(rawurldecode($uri), self::REST_NAMESPACE) !== false) {
            Schema::maybeUpgrade();
        }
        Rest::registerRoutes();
    }
}
