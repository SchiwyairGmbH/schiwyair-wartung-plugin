<?php

namespace Schiwyair\Wartung;

defined('ABSPATH') || exit;

/**
 * Wordfence-Scan anstoßen, über denselben Weg wie der Knopf „Neuen Scan starten".
 * Fundstellen: docs/fundstellen.md
 */
final class WordfenceScan
{
    /** @return string|null Grund, warum kein Scan möglich ist */
    public static function available(): ?string
    {
        if (!defined('WORDFENCE_VERSION') || !class_exists('wfConfig')) {
            return 'Wordfence ist nicht aktiv';
        }
        if (!class_exists('wfScanEngine') || !class_exists('wfScanner') || !method_exists('wfScanEngine', 'startScan')) {
            return 'Diese Wordfence-Version lässt sich nicht von außen starten';
        }
        return null;
    }

    public static function running(): bool
    {
        return (bool) \wfScanner::shared()->isRunning();
    }

    /**
     * Startet den Scan. Wordfence prüft dabei, ob die Seite sich selbst aufrufen kann,
     * und lässt den Scan dann in eigenen Anfragen weiterlaufen.
     */
    public static function start(): array
    {
        try {
            $error = \wfScanEngine::startScan();
        } catch (\Throwable $e) {
            $error = $e->getMessage();
        }
        if ($error) {
            $message = Redact::text(wp_strip_all_tags((string) $error), 300);
            Log::add('wordfence_scan', 'error', 'Scan nicht gestartet: ' . $message);
            return ['started' => false, 'code' => 'failed', 'message' => $message];
        }
        Log::add('wordfence_scan', 'ok', 'Wordfence-Scan gestartet');
        return ['started' => true];
    }

    /** Stand des Scans, klein gehalten für häufiges Nachfragen. */
    public static function state(): array
    {
        return [
            'scan' => Status::section([StatusWordfence::class, 'scan']),
            'issues' => Status::section([StatusWordfence::class, 'issues']),
        ];
    }
}
