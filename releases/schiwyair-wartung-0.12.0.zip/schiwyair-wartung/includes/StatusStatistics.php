<?php

namespace Schiwyair\Wartung;

defined('ABSPATH') || exit;

/**
 * Besucherzahlen aus WP Statistics (kostenlos). Fundstellen: docs/fundstellen.md
 *
 * Nur Tageswerte (Besucher, Aufrufe) der letzten 62 Tage, keine Einzeldaten von Besuchern.
 * Tagessummen stehen in statistics_summary_totals (ab gestern, täglich per WP-Cron),
 * fehlende Tage und heute werden wie in WP Statistics aus statistics_visitor gezählt.
 */
final class StatusStatistics
{
    private const PLUGIN_FILE = 'wp-statistics/wp-statistics.php';
    private const DAYS = 62;

    public static function collect(): array
    {
        $active = defined('WP_STATISTICS_VERSION');
        if (!$active) {
            $installed = array_key_exists(self::PLUGIN_FILE, get_plugins());
            return Status::thirdParty(
                self::PLUGIN_FILE,
                false,
                null,
                null,
                $installed ? 'WP Statistics ist installiert, aber nicht aktiv' : 'WP Statistics ist nicht installiert'
            );
        }

        return Status::thirdParty(self::PLUGIN_FILE, true, (string) WP_STATISTICS_VERSION, [
            'daily' => Status::section([self::class, 'daily']),
        ], null);
    }

    private static function tableExists(string $table): bool
    {
        global $wpdb;
        return $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $wpdb->esc_like($table))) === $table;
    }

    /**
     * Tageswerte, ältester Tag zuerst. Datum in der Zeitzone der Seite (wie WP Statistics).
     *
     * @return array{days:int, today:string, items:list<array{date:string,visitors:int,views:int}>}|array{error:true,reason:string}
     */
    public static function daily(): array
    {
        global $wpdb;
        $visitorTable = $wpdb->prefix . 'statistics_visitor';
        $summaryTable = $wpdb->prefix . 'statistics_summary_totals';
        if (!self::tableExists($visitorTable)) {
            return ['error' => true, 'reason' => 'Tabelle von WP Statistics fehlt'];
        }

        $today = current_time('Y-m-d');
        $from = gmdate('Y-m-d', strtotime($today . ' -' . (self::DAYS - 1) . ' days'));
        $byDate = [];

        $wpdb->suppress_errors(true);
        // Gezählt wie VisitorsModel::getVisitorsHits(): eine Zeile je Besucher und Tag, hits = Aufrufe
        $rows = $wpdb->get_results($wpdb->prepare(
            "SELECT last_counter AS d, COUNT(ID) AS v, SUM(hits) AS h FROM `$visitorTable` WHERE last_counter >= %s GROUP BY last_counter",
            $from
        ), ARRAY_A);
        foreach ((array) $rows as $row) {
            $byDate[(string) $row['d']] = ['visitors' => (int) $row['v'], 'views' => (int) $row['h']];
        }
        // Tagessummen haben Vorrang (alte Besucherzeilen können bereinigt sein)
        if (self::tableExists($summaryTable)) {
            $rows = $wpdb->get_results($wpdb->prepare(
                "SELECT `date` AS d, visitors AS v, views AS h FROM `$summaryTable` WHERE `date` >= %s",
                $from
            ), ARRAY_A);
            foreach ((array) $rows as $row) {
                $byDate[(string) $row['d']] = ['visitors' => (int) $row['v'], 'views' => (int) $row['h']];
            }
        }
        $wpdb->suppress_errors(false);

        $items = [];
        for ($i = self::DAYS - 1; $i >= 0; $i--) {
            $date = gmdate('Y-m-d', strtotime($today . ' -' . $i . ' days'));
            $items[] = ['date' => $date] + ($byDate[$date] ?? ['visitors' => 0, 'views' => 0]);
        }
        return ['days' => self::DAYS, 'today' => $today, 'items' => $items];
    }
}
