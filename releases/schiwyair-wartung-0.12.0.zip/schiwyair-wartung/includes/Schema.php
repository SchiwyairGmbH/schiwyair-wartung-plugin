<?php

namespace Schiwyair\Wartung;

defined('ABSPATH') || exit;

/**
 * Eigene Tabellen und Optionen. Alle Optionen ohne autoload.
 */
final class Schema
{
    public const DB_VERSION = '3';

    public const OPTION_PUBLIC_KEY = 'schiwyair_wartung_public_key';
    public const OPTION_IP_ALLOWLIST = 'schiwyair_wartung_ip_allowlist';
    public const OPTION_CLIENT_IP_SOURCE = 'schiwyair_wartung_client_ip_source';
    public const OPTION_LAST_SUCCESS = 'schiwyair_wartung_last_success';
    public const OPTION_LAST_FAILURE = 'schiwyair_wartung_last_failure';
    public const OPTION_DB_VERSION = 'schiwyair_wartung_db_version';
    public const OPTION_COPY_DIR = 'schiwyair_wartung_copy_dir';
    public const OPTION_LOCK = 'schiwyair_wartung_lock';
    public const OPTION_BACKUP_JOB = 'schiwyair_wartung_backup_job';

    /** Standardwerte der Optionen. */
    public static function defaults(): array
    {
        return [
            self::OPTION_PUBLIC_KEY => '',
            self::OPTION_IP_ALLOWLIST => '',
            self::OPTION_CLIENT_IP_SOURCE => 'remote_addr',
            self::OPTION_LAST_SUCCESS => 0,
            self::OPTION_LAST_FAILURE => [],
            self::OPTION_DB_VERSION => '',
            self::OPTION_COPY_DIR => '',
        ];
    }

    public static function noncesTable(): string
    {
        global $wpdb;
        return $wpdb->base_prefix . 'sww_nonces';
    }

    public static function throttleTable(): string
    {
        global $wpdb;
        return $wpdb->base_prefix . 'sww_throttle';
    }

    public static function logTable(): string
    {
        global $wpdb;
        return $wpdb->base_prefix . 'sww_log';
    }

    public static function install(): void
    {
        global $wpdb;

        foreach (self::defaults() as $name => $value) {
            // add_option legt nur an, wenn die Option fehlt. autoload aus.
            add_option($name, $value, '', 'no');
        }

        $nonces = self::noncesTable();
        $throttle = self::throttleTable();

        // Nonce binär vergleichen (Groß-/Kleinschreibung zählt).
        $wpdb->query(
            "CREATE TABLE IF NOT EXISTS `{$nonces}` (
                nonce VARCHAR(64) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
                created_at INT UNSIGNED NOT NULL,
                PRIMARY KEY (nonce),
                KEY created_at (created_at)
            ) ENGINE=InnoDB"
        );
        $wpdb->query(
            "CREATE TABLE IF NOT EXISTS `{$throttle}` (
                ip VARCHAR(45) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
                failures INT UNSIGNED NOT NULL DEFAULT 0,
                window_start INT UNSIGNED NOT NULL DEFAULT 0,
                blocked_until INT UNSIGNED NOT NULL DEFAULT 0,
                PRIMARY KEY (ip)
            ) ENGINE=InnoDB"
        );

        $log = self::logTable();
        $wpdb->query(
            "CREATE TABLE IF NOT EXISTS `{$log}` (
                id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                created_at INT UNSIGNED NOT NULL,
                action VARCHAR(40) NOT NULL,
                status VARCHAR(20) NOT NULL,
                summary VARCHAR(255) NOT NULL DEFAULT '',
                details TEXT NULL,
                PRIMARY KEY (id),
                KEY created_at (created_at)
            ) ENGINE=InnoDB {$wpdb->get_charset_collate()}"
        );

        // Sperrmodus-Zustand gleich anlegen (klein, autoload), damit nicht jeder Seitenaufruf danach fragt
        if (get_option(Lockdown::OPTION, null) === null) {
            add_option(Lockdown::OPTION, ['enabled' => false, 'unlocked_until' => 0], '', 'yes');
        }
        Lockdown::internalUpdate(self::OPTION_DB_VERSION, self::DB_VERSION);
    }

    public static function maybeUpgrade(): void
    {
        if (get_option(self::OPTION_DB_VERSION) !== self::DB_VERSION) {
            self::install();
        }
    }
}
