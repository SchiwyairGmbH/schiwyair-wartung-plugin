<?php
/**
 * Entfernt beim Löschen des Plugins alle Optionen und Tabellen restlos.
 */

defined('WP_UNINSTALL_PLUGIN') || exit;

global $wpdb;

$sww_options = [
    'schiwyair_wartung_public_key',
    'schiwyair_wartung_ip_allowlist',
    'schiwyair_wartung_client_ip_source',
    'schiwyair_wartung_last_success',
    'schiwyair_wartung_last_failure',
    'schiwyair_wartung_db_version',
    'schiwyair_wartung_copy_dir',
    'schiwyair_wartung_lock',
    'schiwyair_wartung_backup_job',
    'schiwyair_wartung_formtest',
    'schiwyair_wartung_file_editor_off',
    'schiwyair_wartung_lockdown',
];

// Plugin-Kopien löschen (außerhalb des Webroots oder im zufällig benannten Ordner in wp-content)
$sww_remove_dir = static function ($dir) use (&$sww_remove_dir) {
    if (!is_string($dir) || $dir === '' || !is_dir($dir) || is_link($dir)) {
        return;
    }
    foreach ((array) scandir($dir) as $entry) {
        if ($entry === '.' || $entry === '..') {
            continue;
        }
        $path = $dir . '/' . $entry;
        is_dir($path) && !is_link($path) ? $sww_remove_dir($path) : @unlink($path);
    }
    @rmdir($dir);
};

$sww_delete_site_data = static function () use ($sww_options, $sww_remove_dir) {
    $copies = get_option('schiwyair_wartung_copy_dir');
    if (is_array($copies) && !empty($copies['path'])
        && (basename($copies['path']) === 'schiwyair-wartung-kopien' || strpos(basename($copies['path']), 'sww-kopien-') === 0)) {
        $sww_remove_dir($copies['path']);
    }
    foreach ($sww_options as $option) {
        delete_option($option);
    }
    delete_transient('sww_selftest_result');
    delete_transient('sww_update_manifest');
};

if (is_multisite()) {
    foreach (get_sites(['fields' => 'ids', 'number' => 0]) as $sww_blog_id) {
        switch_to_blog($sww_blog_id);
        $sww_delete_site_data();
        restore_current_blog();
    }
} else {
    $sww_delete_site_data();
}

$wpdb->query('DROP TABLE IF EXISTS `' . $wpdb->base_prefix . 'sww_nonces`');
$wpdb->query('DROP TABLE IF EXISTS `' . $wpdb->base_prefix . 'sww_throttle`');
$wpdb->query('DROP TABLE IF EXISTS `' . $wpdb->base_prefix . 'sww_log`');
