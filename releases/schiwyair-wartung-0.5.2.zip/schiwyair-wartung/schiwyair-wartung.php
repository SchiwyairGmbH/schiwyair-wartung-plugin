<?php
/**
 * Plugin Name: Schiwyair Wartungszentrale
 * Description: Verbindung zu der Wartungszentrale der Schiwyair GmbH. Beantwortet nur signierte Anfragen der Zentrale.
 * Version: 0.5.2
 * Author: Schiwyair GmbH
 * Requires at least: 6.0
 * Requires PHP: 7.4
 * Update URI: https://raw.githubusercontent.com/SchiwyairGmbH/schiwyair-wartung-plugin/main/update.json
 * License: proprietär
 * Text Domain: schiwyair-wartung
 */

defined('ABSPATH') || exit;

define('SCHIWYAIR_WARTUNG_VERSION', '0.5.2');
define('SCHIWYAIR_WARTUNG_FILE', __FILE__);
define('SCHIWYAIR_WARTUNG_DIR', __DIR__);

spl_autoload_register(static function ($class) {
    $prefix = 'Schiwyair\\Wartung\\';
    if (strpos($class, $prefix) !== 0) {
        return;
    }
    $relative = str_replace('\\', '/', substr($class, strlen($prefix)));
    $file = SCHIWYAIR_WARTUNG_DIR . '/includes/' . $relative . '.php';
    if (is_readable($file)) {
        require $file;
    }
});

register_activation_hook(__FILE__, ['Schiwyair\\Wartung\\Schema', 'install']);

Schiwyair\Wartung\Plugin::init();
