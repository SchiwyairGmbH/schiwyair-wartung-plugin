<?php

namespace Schiwyair\Wartung;

defined('ABSPATH') || exit;

final class Plugin
{
    public const REST_NAMESPACE = 'schiwyair-wartung/v1';

    public static function init(): void
    {
        // Nur REST und Admin, keine Hooks im Frontend.
        add_action('rest_api_init', [self::class, 'onRestApiInit']);

        // Updates für dieses Plugin selbst (nur Filter, die WordPress bei der Update-Suche aufruft)
        SelfUpdate::init();

        // Formulartest der Zentrale: wirkt nur mit gültigem Einmal-Cookie
        FormTest::maybeActivate();

        if (is_admin()) {
            add_action('admin_init', [Schema::class, 'maybeUpgrade']);
            Settings::init();
        }
    }

    public static function onRestApiInit(): void
    {
        Schema::maybeUpgrade();
        Rest::registerRoutes();
    }
}
