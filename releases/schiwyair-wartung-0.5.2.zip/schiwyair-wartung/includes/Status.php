<?php

namespace Schiwyair\Wartung;

defined('ABSPATH') || exit;

/**
 * Sammelt den Zustand der Seite für GET /status.
 * Jeder Abschnitt ist einzeln abgesichert: Ein Fehler in einem Abschnitt
 * liefert dort null plus Grund, der Rest bleibt vollständig.
 */
final class Status
{
    public const SCHEMA = 1;

    public static function collect(bool $refresh = false): array
    {
        self::loadAdminIncludes();

        if ($refresh) {
            self::section(static function () {
                // Auch die eigene Version frisch abfragen, damit ein neues Wartungs-Plugin sofort erscheint
                SelfUpdate::forgetManifest();
                wp_version_check([], true);
                wp_update_plugins();
                wp_update_themes();
                return true;
            });
        }

        return [
            'schema' => self::SCHEMA,
            'generated_at' => gmdate('c'),
            'plugin_version' => SCHIWYAIR_WARTUNG_VERSION,
            'site' => self::section([self::class, 'site']),
            'wordpress' => self::section([self::class, 'wordpress']),
            'server' => self::section([self::class, 'server']),
            'plugins' => self::section([self::class, 'plugins']),
            'themes' => self::section([self::class, 'themes']),
            'updraftplus' => self::section([StatusUpdraftPlus::class, 'collect']),
            'wordfence' => self::section([StatusWordfence::class, 'collect']),
            'debug_log' => self::section([StatusDebugLog::class, 'collect']),
            'cron' => self::section([self::class, 'cron']),
            'disk' => self::section([self::class, 'disk']),
        ];
    }

    /** Führt einen Abschnitt aus und fängt jeden Fehler ab. */
    public static function section(callable $collector)
    {
        try {
            return $collector();
        } catch (\Throwable $e) {
            return [
                'error' => true,
                'reason' => 'Fehler beim Auslesen: ' . Redact::text($e->getMessage()),
            ];
        }
    }

    private static function loadAdminIncludes(): void
    {
        foreach (['plugin.php', 'update.php', 'theme.php'] as $file) {
            $path = ABSPATH . 'wp-admin/includes/' . $file;
            if (is_readable($path)) {
                require_once $path;
            }
        }
    }

    public static function site(): array
    {
        return [
            'name' => get_bloginfo('name'),
            'home_url' => home_url(),
            'site_url' => site_url(),
            'host' => Auth::siteHost(),
            'multisite' => is_multisite(),
            'environment' => function_exists('wp_get_environment_type') ? wp_get_environment_type() : null,
            'https' => strpos(home_url(), 'https://') === 0,
            'timezone' => wp_timezone_string(),
        ];
    }

    public static function wordpress(): array
    {
        global $wp_version;
        $transient = get_site_transient('update_core');
        $update = null;

        if (is_object($transient) && !empty($transient->updates) && is_array($transient->updates)) {
            foreach ($transient->updates as $offer) {
                if (!is_object($offer) || !isset($offer->response) || $offer->response !== 'upgrade') {
                    continue;
                }
                $requiresPhp = isset($offer->php_version) ? (string) $offer->php_version : null;
                $update = [
                    'version' => isset($offer->current) ? (string) $offer->current : null,
                    'requires_php' => $requiresPhp,
                    'php_compatible' => $requiresPhp === null || version_compare(PHP_VERSION, $requiresPhp, '>='),
                ];
                break;
            }
        }

        return [
            'version' => $wp_version,
            'update' => $update,
            'updates_checked_at' => is_object($transient) && isset($transient->last_checked) ? (int) $transient->last_checked : null,
            'auto_update_core' => defined('WP_AUTO_UPDATE_CORE') ? WP_AUTO_UPDATE_CORE : null,
        ];
    }

    public static function server(): array
    {
        global $wpdb;
        $dbInfo = method_exists($wpdb, 'db_server_info') ? (string) $wpdb->db_server_info() : '';
        $dbVersion = (string) $wpdb->db_version();

        return [
            'php_version' => PHP_VERSION,
            'php_sodium' => extension_loaded('sodium'),
            'database' => [
                'type' => stripos($dbInfo, 'mariadb') !== false ? 'MariaDB' : 'MySQL',
                'version' => $dbVersion,
                'server_info' => $dbInfo,
            ],
            'memory_limit' => (string) ini_get('memory_limit'),
            'wp_memory_limit' => defined('WP_MEMORY_LIMIT') ? WP_MEMORY_LIMIT : null,
            'wp_max_memory_limit' => defined('WP_MAX_MEMORY_LIMIT') ? WP_MAX_MEMORY_LIMIT : null,
            'max_execution_time' => (int) ini_get('max_execution_time'),
            'server_software' => isset($_SERVER['SERVER_SOFTWARE']) ? substr((string) $_SERVER['SERVER_SOFTWARE'], 0, 100) : null,
        ];
    }

    public static function plugins(): array
    {
        $all = get_plugins();
        $transient = get_site_transient('update_plugins');
        $response = is_object($transient) && isset($transient->response) ? (array) $transient->response : [];
        $noUpdate = is_object($transient) && isset($transient->no_update) ? (array) $transient->no_update : [];
        $autoUpdates = (array) get_site_option('auto_update_plugins', []);

        $items = [];
        foreach ($all as $file => $data) {
            $offer = isset($response[$file]) ? (object) $response[$file] : null;
            $known = isset($noUpdate[$file]) ? (object) $noUpdate[$file] : null;

            $update = self::pendingUpdate($offer, $known, (string) $data['Version']);

            $items[] = [
                'file' => $file,
                'slug' => self::pluginSlug($file),
                'name' => $data['Name'],
                'version' => $data['Version'],
                'author' => wp_strip_all_tags((string) $data['Author']),
                'active' => is_plugin_active($file),
                'network_active' => is_multisite() && is_plugin_active_for_network($file),
                'auto_update' => in_array($file, $autoUpdates, true),
                'update_source' => self::updateSource($offer ?: $known, isset($data['UpdateURI']) ? (string) $data['UpdateURI'] : ''),
                'update' => $update,
            ];
        }

        return [
            'updates_checked_at' => is_object($transient) && isset($transient->last_checked) ? (int) $transient->last_checked : null,
            'items' => $items,
            'must_use' => array_values(array_map(static function ($data) {
                return ['name' => $data['Name'], 'version' => $data['Version']];
            }, get_mu_plugins())),
            'dropins' => array_keys(get_dropins()),
        ];
    }

    public static function themes(): array
    {
        $transient = get_site_transient('update_themes');
        $response = is_object($transient) && isset($transient->response) ? (array) $transient->response : [];
        $noUpdate = is_object($transient) && isset($transient->no_update) ? (array) $transient->no_update : [];

        $stylesheet = get_stylesheet();
        $template = get_template();

        $items = [];
        foreach (wp_get_themes() as $slug => $theme) {
            $offer = isset($response[$slug]) ? (object) $response[$slug] : null;
            $known = isset($noUpdate[$slug]) ? (object) $noUpdate[$slug] : null;
            $items[] = [
                'slug' => (string) $slug,
                'name' => $theme->get('Name'),
                'version' => $theme->get('Version'),
                'active' => $slug === $stylesheet,
                'parent_of_active' => $slug === $template && $stylesheet !== $template,
                'parent' => $theme->parent() ? $theme->get_template() : null,
                'update_source' => $offer || $known
                    ? self::updateSource($offer ?: $known, '')
                    : 'unknown',
                'update' => self::pendingUpdate($offer, $known, (string) $theme->get('Version')),
            ];
        }

        return [
            'updates_checked_at' => is_object($transient) && isset($transient->last_checked) ? (int) $transient->last_checked : null,
            'active' => $stylesheet,
            'is_child_theme' => $stylesheet !== $template,
            'parent' => $stylesheet !== $template ? $template : null,
            'items' => $items,
        ];
    }

    /**
     * Offenes Update. wordpress.org legt Updates, die ein neueres WordPress oder
     * PHP brauchen, unter no_update ab. Sie werden trotzdem gemeldet, mit Grund.
     */
    private static function pendingUpdate($offer, $known, string $installedVersion): ?array
    {
        if ($offer !== null && !empty($offer->new_version)) {
            return self::updateOffer($offer);
        }
        if ($known !== null && !empty($known->new_version)
            && version_compare((string) $known->new_version, $installedVersion, '>')
        ) {
            return self::updateOffer($known);
        }
        return null;
    }

    /**
     * Update-Angebot. Ohne Paket liefert der Hersteller meist wegen fehlender
     * oder abgelaufener Lizenz keinen Download: Das ist kein technischer Fehler.
     */
    private static function updateOffer($offer): array
    {
        $requiresPhp = !empty($offer->requires_php) ? (string) $offer->requires_php : null;
        $requiresWp = !empty($offer->requires) ? (string) $offer->requires : null;
        global $wp_version;

        $phpOk = $requiresPhp === null || version_compare(PHP_VERSION, $requiresPhp, '>=');
        $wpOk = $requiresWp === null || version_compare($wp_version, $requiresWp, '>=');
        $hasPackage = !empty($offer->package);

        $problem = null;
        if (!$hasPackage) {
            $problem = 'no_package';
        } elseif (!$phpOk) {
            $problem = 'requires_php';
        } elseif (!$wpOk) {
            $problem = 'requires_wp';
        }

        return [
            'version' => (string) $offer->new_version,
            'package_available' => $hasPackage,
            'requires_php' => $requiresPhp,
            'requires_wp' => $requiresWp,
            'tested_wp' => !empty($offer->tested) ? (string) $offer->tested : null,
            'problem' => $problem,
        ];
    }

    /** wordpress.org, vendor (anderer Update-Dienst) oder unknown (niemand prüft Updates). */
    private static function updateSource($entry, string $updateUri): string
    {
        if ($entry !== null) {
            $id = isset($entry->id) ? (string) $entry->id : '';
            $package = isset($entry->package) ? (string) $entry->package : '';
            $url = isset($entry->url) ? (string) $entry->url : '';
            if (strpos($id, 'w.org/') === 0
                || strpos($package, 'https://downloads.wordpress.org/') === 0
                || strpos($url, 'https://wordpress.org/') === 0
            ) {
                return 'wordpress.org';
            }
            return 'vendor';
        }
        if ($updateUri !== '' && $updateUri !== 'false') {
            return 'vendor';
        }
        return 'unknown';
    }

    private static function pluginSlug(string $file): string
    {
        $dir = dirname($file);
        return $dir === '.' ? basename($file, '.php') : $dir;
    }

    public static function cron(): array
    {
        $crons = function_exists('_get_cron_array') ? _get_cron_array() : [];
        $crons = is_array($crons) ? $crons : [];
        $now = time();
        $grace = 600;

        $total = 0;
        $overdue = [];
        foreach ($crons as $timestamp => $hooks) {
            if (!is_array($hooks)) {
                continue;
            }
            foreach ($hooks as $hook => $events) {
                $count = is_array($events) ? count($events) : 0;
                $total += $count;
                if ((int) $timestamp < $now - $grace) {
                    $overdue[] = ['hook' => (string) $hook, 'due_at' => (int) $timestamp, 'count' => $count];
                }
            }
        }
        usort($overdue, static function ($a, $b) {
            return $a['due_at'] <=> $b['due_at'];
        });

        return [
            'disabled' => defined('DISABLE_WP_CRON') && DISABLE_WP_CRON,
            'alternate' => defined('ALTERNATE_WP_CRON') && ALTERNATE_WP_CRON,
            'events_total' => $total,
            'overdue_count' => array_sum(array_column($overdue, 'count')),
            'overdue' => array_slice($overdue, 0, 20),
            'overdue_grace_seconds' => $grace,
        ];
    }

    public static function disk(): array
    {
        $disabled = array_map('trim', explode(',', (string) ini_get('disable_functions')));
        if (!function_exists('disk_free_space') || in_array('disk_free_space', $disabled, true)) {
            return ['free_bytes' => null, 'total_bytes' => null, 'reason' => 'Vom Hoster deaktiviert'];
        }
        $free = @disk_free_space(ABSPATH);
        $total = function_exists('disk_total_space') && !in_array('disk_total_space', $disabled, true)
            ? @disk_total_space(ABSPATH)
            : false;

        return [
            'free_bytes' => $free !== false ? (int) $free : null,
            'total_bytes' => $total !== false ? (int) $total : null,
            'reason' => $free === false ? 'Nicht ermittelbar (Hoster-Einschränkung)' : null,
        ];
    }

    /** Einheitliche Antwort für Fremd-Plugins. */
    public static function thirdParty(string $pluginFile, bool $active, ?string $version, ?array $data, ?string $reason): array
    {
        $installed = array_key_exists($pluginFile, get_plugins());
        return [
            'installed' => $installed || $active,
            'active' => $active,
            'version' => $version,
            'data' => $data,
            'reason' => $reason,
        ];
    }
}
