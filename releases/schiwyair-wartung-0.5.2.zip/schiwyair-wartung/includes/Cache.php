<?php

namespace Schiwyair\Wartung;

defined('ABSPATH') || exit;

/**
 * Caches leeren. Jedes Cache-Plugin wird nur angesprochen, wenn seine Funktion existiert.
 * Fundstellen und Prüfstand je Plugin: docs/fundstellen.md
 */
final class Cache
{
    public static function clearAll(): array
    {
        $results = [
            self::run('WP Super Cache', 'wp_cache_clear_cache', static function () {
                wp_cache_clear_cache();
            }),
            // Noch nicht im Quellcode geprüft (Premium, nicht in /dev): auf Staging verifizieren
            self::run('WP Rocket', 'rocket_clean_domain', static function () {
                rocket_clean_domain();
                if (function_exists('rocket_clean_minify')) {
                    rocket_clean_minify();
                }
            }),
            self::run('Elementor (CSS-Dateien)', null, static function () {
                \Elementor\Plugin::$instance->files_manager->clear_cache();
            }, static function () {
                return class_exists('\Elementor\Plugin') && isset(\Elementor\Plugin::$instance->files_manager)
                    && method_exists(\Elementor\Plugin::$instance->files_manager, 'clear_cache');
            }),
            self::run('Objekt-Cache', null, static function () {
                wp_cache_flush();
            }, static function () {
                return function_exists('wp_using_ext_object_cache') && wp_using_ext_object_cache();
            }),
        ];

        $cleared = array_values(array_filter($results, static function ($r) {
            return $r['cleared'] === true;
        }));
        $failed = array_values(array_filter($results, static function ($r) {
            return $r['cleared'] === false;
        }));
        Log::add(
            'cache',
            $failed ? 'error' : ($cleared ? 'ok' : 'info'),
            $cleared ? 'Geleert: ' . implode(', ', array_column($cleared, 'name')) : 'Kein Cache-Plugin gefunden',
            ['results' => $results]
        );

        return ['ok' => !$failed, 'caches' => $results];
    }

    private static function run(string $name, ?string $function, callable $clear, ?callable $detect = null): array
    {
        $found = $detect ? (bool) $detect() : ($function !== null && function_exists($function));
        if (!$found) {
            return ['name' => $name, 'found' => false, 'cleared' => null, 'reason' => 'nicht aktiv'];
        }
        try {
            $clear();
            return ['name' => $name, 'found' => true, 'cleared' => true, 'reason' => null];
        } catch (\Throwable $e) {
            return ['name' => $name, 'found' => true, 'cleared' => false, 'reason' => Redact::text($e->getMessage(), 200)];
        }
    }
}
