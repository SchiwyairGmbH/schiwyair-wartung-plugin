<?php

namespace Schiwyair\Wartung;

use WP_REST_Request;
use WP_REST_Response;

defined('ABSPATH') || exit;

/**
 * Feste, einzeln definierte Befehle. Jede Route prüft die Signatur über Auth::check.
 *
 * Parameter werden erst im Callback gelesen ("args" bleibt leer): WordPress prüft "args"
 * vor der Signatur und würde Unbekannten sonst Fehlerdetails zeigen.
 */
final class Rest
{
    public static function registerRoutes(): void
    {
        $routes = [
            ['/ping', 'GET', 'ping'],
            // refresh=1: vorher bei wordpress.org und Herstellern nach Updates suchen
            ['/status', 'GET', 'status'],
            ['/backup', 'POST', 'backup'],
            // job=<ID aus POST /backup>
            ['/backup/status', 'GET', 'backupStatus'],
            // Body: {"type": "plugin"|"theme"|"core", "slug": "...", "version": "..." (nur core)}
            ['/update', 'POST', 'update'],
            ['/cache/clear', 'POST', 'cacheClear'],
            // Body: {"slug": "contact-form-7", "copy": "<ID, optional>"}
            ['/rollback', 'POST', 'rollback'],
            // slug=contact-form-7
            ['/copies', 'GET', 'copies'],
            // limit=1..200
            ['/log', 'GET', 'log'],
            // Body: {"redirect_to": "test@agentur.de"}
            ['/formtest/start', 'POST', 'formtestStart'],
            ['/formtest/status', 'GET', 'formtestStatus'],
            ['/formtest/stop', 'POST', 'formtestStop'],
        ];
        foreach ($routes as [$path, $method, $callback]) {
            register_rest_route(Plugin::REST_NAMESPACE, $path, [
                'methods' => $method,
                'callback' => [self::class, $callback],
                'permission_callback' => [Auth::class, 'check'],
                'args' => [],
            ]);
        }
    }

    public static function ping(WP_REST_Request $request): WP_REST_Response
    {
        return self::respond([
            'ok' => true,
            'plugin_version' => SCHIWYAIR_WARTUNG_VERSION,
            'host' => Auth::siteHost(),
            'time' => time(),
        ]);
    }

    public static function status(WP_REST_Request $request): WP_REST_Response
    {
        $refresh = (string) $request->get_param('refresh') === '1';
        return self::respond(Status::collect($refresh));
    }

    public static function backup(WP_REST_Request $request): WP_REST_Response
    {
        $problem = Backup::available();
        if ($problem !== null) {
            return self::respond(['started' => false, 'code' => 'unavailable', 'message' => $problem], 409);
        }
        $running = Backup::runningJob();
        if ($running !== null) {
            return self::respond(['started' => false, 'code' => 'already_running', 'job' => $running, 'message' => 'Es läuft bereits ein Backup.'], 409);
        }
        if (Lock::current() !== null) {
            return self::respond(['started' => false, 'code' => 'locked', 'message' => 'Es läuft gerade ein Update.'], 409);
        }
        Backup::startAndDetach(); // kehrt nicht zurück
        return self::respond(['started' => false], 500);
    }

    public static function backupStatus(WP_REST_Request $request): WP_REST_Response
    {
        $job = (string) $request->get_param('job');
        if (!preg_match('/^[0-9a-f]{6,32}$/', $job)) {
            return self::respond(['code' => 'bad_request', 'message' => 'Ungültige Job-ID'], 400);
        }
        $problem = Backup::available();
        if ($problem !== null) {
            return self::respond(['code' => 'unavailable', 'message' => $problem], 409);
        }
        return self::respond(Backup::status($job));
    }

    public static function update(WP_REST_Request $request): WP_REST_Response
    {
        $body = $request->get_json_params();
        $type = is_array($body) && isset($body['type']) ? (string) $body['type'] : '';
        $slug = is_array($body) && isset($body['slug']) ? (string) $body['slug'] : '';
        $version = is_array($body) && isset($body['version']) ? (string) $body['version'] : '';
        if (($type === 'plugin' || $type === 'theme') && !preg_match('/^[A-Za-z0-9._\/-]{1,200}$/', $slug)) {
            return self::respond(['ok' => false, 'code' => 'bad_request', 'message' => 'Ungültiger Name'], 400);
        }
        $result = Updater::run($type, $slug, $version);
        $status = 200;
        if (!$result['ok']) {
            $status = in_array($result['code'], ['locked', 'backup_running', 'up_to_date', 'no_package', 'requirements', 'filesystem'], true) ? 409 : 500;
            if (in_array($result['code'], ['bad_request', 'not_found'], true)) {
                $status = 400;
            }
        }
        return self::respond($result, $status);
    }

    public static function rollback(WP_REST_Request $request): WP_REST_Response
    {
        $body = $request->get_json_params();
        $slug = is_array($body) && isset($body['slug']) ? (string) $body['slug'] : '';
        $copy = is_array($body) && isset($body['copy']) ? (string) $body['copy'] : '';
        if (!preg_match('/^[A-Za-z0-9._-]{1,200}$/', $slug) || ($copy !== '' && !preg_match('/^[A-Za-z0-9._-]{1,80}$/', $copy))) {
            return self::respond(['ok' => false, 'code' => 'bad_request', 'message' => 'Ungültiger Name'], 400);
        }
        $result = PluginCopies::restore($slug, $copy);
        return self::respond($result, $result['ok'] ? 200 : ($result['code'] === 'no_copy' || $result['code'] === 'locked' ? 409 : 500));
    }

    public static function copies(WP_REST_Request $request): WP_REST_Response
    {
        $slug = (string) $request->get_param('slug');
        if (!preg_match('/^[A-Za-z0-9._-]{1,200}$/', $slug)) {
            return self::respond(['code' => 'bad_request', 'message' => 'Ungültiger Name'], 400);
        }
        return self::respond(['slug' => $slug, 'copies' => PluginCopies::list($slug)]);
    }

    public static function cacheClear(WP_REST_Request $request): WP_REST_Response
    {
        return self::respond(Cache::clearAll());
    }

    public static function log(WP_REST_Request $request): WP_REST_Response
    {
        $limit = (int) ($request->get_param('limit') ?: 50);
        return self::respond(['entries' => Log::recent($limit)]);
    }

    public static function formtestStart(WP_REST_Request $request): WP_REST_Response
    {
        $body = $request->get_json_params();
        $email = is_array($body) && isset($body['redirect_to']) ? sanitize_email((string) $body['redirect_to']) : '';
        if (!is_email($email)) {
            return self::respond(['code' => 'bad_request', 'message' => 'Ungültige Testadresse'], 400);
        }
        return self::respond(FormTest::start($email));
    }

    public static function formtestStatus(WP_REST_Request $request): WP_REST_Response
    {
        return self::respond(FormTest::status());
    }

    public static function formtestStop(WP_REST_Request $request): WP_REST_Response
    {
        return self::respond(FormTest::stop());
    }

    private static function respond(array $data, int $status = 200): WP_REST_Response
    {
        $response = new WP_REST_Response($data, $status);
        $response->header('Cache-Control', 'no-store, max-age=0');
        return $response;
    }
}
