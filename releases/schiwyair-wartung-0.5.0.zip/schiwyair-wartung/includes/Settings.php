<?php

namespace Schiwyair\Wartung;

defined('ABSPATH') || exit;

/**
 * Einstellungen → Wartungszentrale
 */
final class Settings
{
    private const PAGE = 'schiwyair-wartung';
    private const GROUP = 'schiwyair_wartung';

    public static function init(): void
    {
        add_action('admin_menu', [self::class, 'addMenu']);
        add_action('admin_init', [self::class, 'registerSettings']);
        add_action('admin_post_sww_selftest', [self::class, 'handleSelfTest']);
        add_action('admin_post_sww_reset_throttle', [self::class, 'handleResetThrottle']);
        add_filter('plugin_action_links_' . plugin_basename(SCHIWYAIR_WARTUNG_FILE), [self::class, 'actionLinks']);
    }

    public static function addMenu(): void
    {
        add_options_page('Schiwyair Wartungszentrale', 'Wartungszentrale', 'manage_options', self::PAGE, [self::class, 'render']);
    }

    public static function actionLinks(array $links): array
    {
        array_unshift($links, '<a href="' . esc_url(self::pageUrl()) . '">Einstellungen</a>');
        return $links;
    }

    private static function pageUrl(array $args = []): string
    {
        return add_query_arg(array_merge(['page' => self::PAGE], $args), admin_url('options-general.php'));
    }

    public static function registerSettings(): void
    {
        register_setting(self::GROUP, Schema::OPTION_PUBLIC_KEY, [
            'type' => 'string',
            'sanitize_callback' => [self::class, 'sanitizePublicKey'],
            'default' => '',
        ]);
        register_setting(self::GROUP, Schema::OPTION_IP_ALLOWLIST, [
            'type' => 'string',
            'sanitize_callback' => [self::class, 'sanitizeAllowlist'],
            'default' => '',
        ]);
        register_setting(self::GROUP, Schema::OPTION_CLIENT_IP_SOURCE, [
            'type' => 'string',
            'sanitize_callback' => [self::class, 'sanitizeIpSource'],
            'default' => 'remote_addr',
        ]);
    }

    public static function sanitizePublicKey($value): string
    {
        $value = trim((string) $value);
        if ($value === '') {
            return '';
        }
        if (Auth::decodePublicKey($value) === null) {
            add_settings_error(Schema::OPTION_PUBLIC_KEY, 'sww_bad_key', 'Der öffentliche Schlüssel ist ungültig. Bitte genau so einfügen, wie ihn die Zentrale anzeigt. Der bisherige Schlüssel bleibt erhalten.');
            return (string) get_option(Schema::OPTION_PUBLIC_KEY, '');
        }
        return $value;
    }

    public static function sanitizeAllowlist($value): string
    {
        $entries = preg_split('/[\s,]+/', (string) $value, -1, PREG_SPLIT_NO_EMPTY);
        $valid = [];
        $invalid = [];
        foreach ((array) $entries as $entry) {
            if (Auth::isValidAllowlistEntry($entry)) {
                $valid[] = $entry;
            } else {
                $invalid[] = $entry;
            }
        }
        if ($invalid !== []) {
            add_settings_error(Schema::OPTION_IP_ALLOWLIST, 'sww_bad_ip', 'Ungültige Einträge wurden entfernt: ' . esc_html(implode(', ', $invalid)));
        }
        return implode("\n", array_unique($valid));
    }

    public static function sanitizeIpSource($value): string
    {
        $value = (string) $value;
        return isset(Auth::IP_SOURCES[$value]) ? $value : 'remote_addr';
    }

    public static function render(): void
    {
        if (!current_user_can('manage_options')) {
            return;
        }

        $publicKey = (string) get_option(Schema::OPTION_PUBLIC_KEY, '');
        $keyBytes = Auth::decodePublicKey($publicKey);
        $lastSuccess = (int) get_option(Schema::OPTION_LAST_SUCCESS, 0);
        $lastFailure = get_option(Schema::OPTION_LAST_FAILURE, []);
        $source = (string) get_option(Schema::OPTION_CLIENT_IP_SOURCE, 'remote_addr');
        $selfTest = get_transient('sww_selftest_result');
        if ($selfTest !== false) {
            delete_transient('sww_selftest_result');
        }
        ?>
        <div class="wrap">
            <h1>Schiwyair Wartungszentrale</h1>
            <p>Dieses Plugin verbindet die Seite mit der Wartungszentrale der Schiwyair GmbH. Es beantwortet nur Anfragen, die mit dem Schlüssel der Zentrale unterschrieben sind.</p>

            <?php settings_errors(); ?>
            <?php if (isset($_GET['sww_notice']) && $_GET['sww_notice'] === 'throttle_reset') : ?>
                <div class="notice notice-success"><p>Alle Sperren wurden aufgehoben.</p></div>
            <?php endif; ?>

            <h2>Verbindung</h2>
            <table class="widefat striped" style="max-width:900px">
                <tbody>
                <tr>
                    <th style="width:260px">Schlüssel</th>
                    <td><?php echo $keyBytes
                        ? '✅ eingetragen, Fingerabdruck <code>' . esc_html(Auth::fingerprint($keyBytes)) . '</code>'
                        : '⚠️ noch kein Schlüssel eingetragen'; ?></td>
                </tr>
                <tr>
                    <th>Adresse dieser Seite</th>
                    <td><code><?php echo esc_html(Auth::siteHost()); ?></code><br>
                        <span class="description">Die Seite nimmt nur Anfragen an, die für genau diese Adresse unterschrieben sind. Eine Staging-Kopie unter anderer Adresse reagiert deshalb nicht auf Anfragen für die Live-Seite.</span></td>
                </tr>
                <tr>
                    <th>Letzte erfolgreiche Anfrage</th>
                    <td><?php echo $lastSuccess ? esc_html(self::formatTime($lastSuccess)) : 'noch keine'; ?></td>
                </tr>
                <tr>
                    <th>Letzte abgelehnte Anfrage</th>
                    <td><?php
                        if (is_array($lastFailure) && !empty($lastFailure['time'])) {
                            $reason = Auth::REASONS[$lastFailure['reason']] ?? (string) $lastFailure['reason'];
                            echo esc_html(self::formatTime((int) $lastFailure['time']) . ', von ' . $lastFailure['ip'] . ': ' . $reason);
                        } else {
                            echo 'keine';
                        }
                    ?></td>
                </tr>
                <tr>
                    <th>Signaturprüfung</th>
                    <td><?php echo extension_loaded('sodium')
                        ? 'PHP-Erweiterung sodium'
                        : 'sodium_compat aus WordPress (langsamer, aber funktionsfähig)'; ?></td>
                </tr>
                </tbody>
            </table>

            <div style="margin:1em 0">
                <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" style="display:inline">
                    <input type="hidden" name="action" value="sww_selftest">
                    <?php wp_nonce_field('sww_selftest'); ?>
                    <?php submit_button('Erreichbarkeit prüfen', 'secondary', 'submit', false); ?>
                </form>
                <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" style="display:inline;margin-left:8px">
                    <input type="hidden" name="action" value="sww_reset_throttle">
                    <?php wp_nonce_field('sww_reset_throttle'); ?>
                    <?php submit_button('Sperren aufheben', 'secondary', 'submit', false); ?>
                </form>
            </div>
            <?php if (is_array($selfTest)) : ?>
                <div class="notice notice-<?php echo esc_attr($selfTest['ok'] ? 'success' : 'warning'); ?> inline" style="max-width:900px">
                    <p><strong><?php echo esc_html($selfTest['title']); ?></strong></p>
                    <p><?php echo esc_html($selfTest['text']); ?></p>
                </div>
            <?php endif; ?>

            <h2>Einstellungen</h2>
            <form method="post" action="options.php">
                <?php settings_fields(self::GROUP); ?>
                <table class="form-table" role="presentation">
                    <tr>
                        <th scope="row"><label for="sww_public_key">Öffentlicher Schlüssel</label></th>
                        <td>
                            <input type="text" class="large-text code" id="sww_public_key"
                                   name="<?php echo esc_attr(Schema::OPTION_PUBLIC_KEY); ?>"
                                   value="<?php echo esc_attr($publicKey); ?>" autocomplete="off" spellcheck="false">
                            <p class="description">Aus der Zentrale kopieren. Der Schlüssel ist kein Geheimnis und darf in Backups und Staging-Kopien stehen.</p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="sww_ip_allowlist">IP-Freigabeliste (optional)</label></th>
                        <td>
                            <textarea class="large-text code" rows="3" id="sww_ip_allowlist"
                                      name="<?php echo esc_attr(Schema::OPTION_IP_ALLOWLIST); ?>"><?php echo esc_textarea((string) get_option(Schema::OPTION_IP_ALLOWLIST, '')); ?></textarea>
                            <p class="description">Eine Adresse oder ein Bereich pro Zeile (z. B. <code>203.0.113.10</code> oder <code>203.0.113.0/24</code>). Leer = jede Adresse, die Signatur wird trotzdem immer geprüft.</p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="sww_ip_source">Herkunft der IP-Adresse</label></th>
                        <td>
                            <select id="sww_ip_source" name="<?php echo esc_attr(Schema::OPTION_CLIENT_IP_SOURCE); ?>">
                                <?php foreach (Auth::IP_SOURCES as $key => $info) : ?>
                                    <option value="<?php echo esc_attr($key); ?>" <?php selected($source, $key); ?>><?php echo esc_html($info[1]); ?></option>
                                <?php endforeach; ?>
                            </select>
                            <p class="description">Nur ändern, wenn die Seite hinter Cloudflare oder einem Proxy liegt. Sonst sehen alle Anfragen gleich aus und Sperren treffen die Falschen. Ihre Adresse laut dieser Einstellung: <code><?php echo esc_html(Auth::clientIp()); ?></code></p>
                        </td>
                    </tr>
                </table>
                <?php submit_button('Speichern'); ?>
            </form>

            <h2>Wenn die Zentrale die Seite nicht erreicht</h2>
            <ul style="list-style:disc;margin-left:20px;max-width:900px">
                <li><strong>Wordfence:</strong> Unter Wordfence → Firewall → „Allowlisted IP addresses" die Adresse der Zentrale eintragen. Die REST-API darf nicht blockiert sein.</li>
                <li><strong>Cloudflare:</strong> Eine Regel anlegen, die Anfragen an <code>/wp-json/schiwyair-wartung/</code> von der Adresse der Zentrale durchlässt (keine Bot-Prüfung). Hier oben „Cloudflare" als Herkunft der IP wählen.</li>
                <li><strong>Plugins, die die REST-API abschalten:</strong> Den Pfad <code>schiwyair-wartung/v1</code> dort freigeben.</li>
                <li><strong>Uhrzeit:</strong> Die Serveruhr darf höchstens 5 Minuten abweichen. Serverzeit jetzt: <?php echo esc_html(gmdate('Y-m-d H:i:s')); ?> UTC.</li>
            </ul>
        </div>
        <?php
    }

    private static function formatTime(int $timestamp): string
    {
        return wp_date('d.m.Y H:i:s', $timestamp);
    }

    public static function handleSelfTest(): void
    {
        if (!current_user_can('manage_options')) {
            wp_die('Keine Berechtigung', 403);
        }
        check_admin_referer('sww_selftest');

        set_transient('sww_selftest_result', self::selfTest(), 120);
        wp_safe_redirect(self::pageUrl());
        exit;
    }

    public static function handleResetThrottle(): void
    {
        if (!current_user_can('manage_options')) {
            wp_die('Keine Berechtigung', 403);
        }
        check_admin_referer('sww_reset_throttle');

        Auth::resetThrottle();
        wp_safe_redirect(self::pageUrl(['sww_notice' => 'throttle_reset']));
        exit;
    }

    /**
     * Ruft /ping ohne Signatur von der Seite selbst aus auf. Erwartet wird die
     * eigene 401-Antwort. Alles andere deutet auf eine Sperre hin.
     */
    private static function selfTest(): array
    {
        $response = wp_remote_get(rest_url(Plugin::REST_NAMESPACE . '/ping'), [
            'timeout' => 10,
            'redirection' => 0,
            'sslverify' => apply_filters('https_local_ssl_verify', false),
        ]);

        if (is_wp_error($response)) {
            return [
                'ok' => false,
                'title' => 'Die Seite kann sich selbst nicht erreichen',
                'text' => 'Das sagt noch nichts darüber, ob die Zentrale die Seite erreicht. Es kann aber WP-Cron und damit UpdraftPlus-Backups bremsen. Meldung: ' . Redact::text($response->get_error_message(), 200),
            ];
        }

        $code = (int) wp_remote_retrieve_response_code($response);
        $body = json_decode((string) wp_remote_retrieve_body($response), true);
        $errorCode = is_array($body) && isset($body['code']) ? (string) $body['code'] : '';

        if ($code === 401 && $errorCode === 'sww_unauthorized') {
            return [
                'ok' => true,
                'title' => 'Alles in Ordnung',
                'text' => 'Die Schnittstelle ist erreichbar und lehnt Anfragen ohne Unterschrift richtig ab.',
            ];
        }
        if ($code === 404) {
            return [
                'ok' => false,
                'title' => 'Schnittstelle nicht gefunden (404)',
                'text' => 'Die REST-API ist vermutlich abgeschaltet oder die Permalinks sind defekt. Einstellungen → Permalinks einmal speichern und Plugins prüfen, die die REST-API abschalten.',
            ];
        }
        if ($errorCode !== '') {
            return [
                'ok' => false,
                'title' => 'Ein anderes Plugin sperrt die Schnittstelle',
                'text' => 'Antwort ' . $code . ' mit Kennung „' . $errorCode . '". Den Pfad schiwyair-wartung/v1 in diesem Plugin freigeben.',
            ];
        }
        return [
            'ok' => false,
            'title' => 'Unerwartete Antwort (' . $code . ')',
            'text' => 'Vermutlich blockiert eine Firewall des Hosters, Cloudflare oder ein Sicherheits-Plugin die Anfrage.',
        ];
    }
}
