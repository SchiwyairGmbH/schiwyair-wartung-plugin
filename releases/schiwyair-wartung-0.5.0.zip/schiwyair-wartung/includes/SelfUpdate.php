<?php

namespace Schiwyair\Wartung;

defined('ABSPATH') || exit;

/**
 * Updates für dieses Plugin selbst, so wie WordPress sie für jedes andere Plugin anzeigt.
 *
 * Die Kundenseiten erreichen die Zentrale nicht. Deshalb liegen die Pakete in einem öffentlichen
 * GitHub-Projekt. Vertraut wird nicht dem Ort, sondern der Unterschrift: Die Beschreibung jeder
 * Version (update.json) ist mit Ed25519 signiert und enthält die Prüfsumme des Pakets. Ein Paket
 * ohne gültige Unterschrift oder mit anderer Prüfsumme wird nicht installiert.
 */
final class SelfUpdate
{
    public const MANIFEST_URL = 'https://raw.githubusercontent.com/SchiwyairGmbH/schiwyair-wartung-plugin/main/update.json';
    /** Host aus dem Plugin-Header „Update URI". WordPress ruft dafür den Filter update_plugins_{Host} auf. */
    private const UPDATE_HOST = 'raw.githubusercontent.com';
    /** Öffentliche Schlüssel, mit denen Versionen unterschrieben sein dürfen (mehrere für einen Schlüsselwechsel). */
    private const PUBLIC_KEYS = ['aaj8JS4ULzyJ3groX1XDuqCRyxiymvBLxenE7+z1ySQ='];
    private const TRANSIENT = 'sww_update_manifest';
    private const CACHE_SECONDS = 6 * HOUR_IN_SECONDS;
    private const RETRY_SECONDS = HOUR_IN_SECONDS;

    public static function init(): void
    {
        add_filter('update_plugins_' . self::UPDATE_HOST, [self::class, 'filterUpdate'], 10, 3);
        add_filter('upgrader_pre_download', [self::class, 'filterDownload'], 10, 4);
        add_filter('auto_update_plugin', [self::class, 'filterAutoUpdate'], 10, 2);
        add_filter('plugins_api', [self::class, 'filterPluginInfo'], 10, 3);
    }

    private static function pluginFile(): string
    {
        return plugin_basename(SCHIWYAIR_WARTUNG_FILE);
    }

    private static function manifestUrl(): string
    {
        // Nur für die Testumgebung überschreibbar. Die Unterschrift wird trotzdem geprüft.
        return defined('SCHIWYAIR_WARTUNG_UPDATE_URL') ? (string) SCHIWYAIR_WARTUNG_UPDATE_URL : self::MANIFEST_URL;
    }

    /** Text, der unterschrieben wird. Muss zum Release-Skript passen (plugin/release.mjs). */
    public static function signedMessage(string $version, string $sha256, string $downloadUrl): string
    {
        return "schiwyair-wartung\n" . $version . "\n" . $sha256 . "\n" . $downloadUrl;
    }

    /**
     * Prüft die Beschreibung einer Version. Liefert sie nur zurück, wenn Form und Unterschrift stimmen.
     *
     * @return array{version:string,download_url:string,sha256:string,requires:string,requires_php:string,tested:string}|null
     */
    public static function parseManifest(string $json): ?array
    {
        $data = json_decode($json, true);
        if (!is_array($data)) {
            return null;
        }
        $version = isset($data['version']) && is_string($data['version']) ? $data['version'] : '';
        $url = isset($data['download_url']) && is_string($data['download_url']) ? $data['download_url'] : '';
        $sha256 = isset($data['sha256']) && is_string($data['sha256']) ? strtolower($data['sha256']) : '';
        $signature = isset($data['signature']) && is_string($data['signature']) ? base64_decode($data['signature'], true) : false;
        if (!preg_match('/^\d+\.\d+\.\d+$/', $version) || !preg_match('/^[0-9a-f]{64}$/', $sha256)
            || !preg_match('#^https?://[^\s]+\.zip$#', $url) || $signature === false || strlen($signature) !== 64
        ) {
            return null;
        }

        if (!function_exists('sodium_crypto_sign_verify_detached')) {
            // WordPress bringt sodium_compat mit (PHP ohne sodium-Erweiterung).
            require_once ABSPATH . WPINC . '/sodium_compat/autoload.php';
        }
        $message = self::signedMessage($version, $sha256, $url);
        $valid = false;
        foreach (self::PUBLIC_KEYS as $key) {
            $publicKey = base64_decode($key, true);
            try {
                if ($publicKey !== false && strlen($publicKey) === 32 && sodium_crypto_sign_verify_detached($signature, $message, $publicKey)) {
                    $valid = true;
                    break;
                }
            } catch (\Throwable $e) {
                // ungültiger Schlüssel oder Unterschrift: nächster Schlüssel
            }
        }
        if (!$valid) {
            return null;
        }

        $text = static function ($value, string $fallback): string {
            return is_string($value) && preg_match('/^[0-9.]{1,12}$/', $value) ? $value : $fallback;
        };
        return [
            'version' => $version,
            'download_url' => $url,
            'sha256' => $sha256,
            'requires' => $text($data['requires'] ?? null, '6.0'),
            'requires_php' => $text($data['requires_php'] ?? null, '7.4'),
            'tested' => $text($data['tested'] ?? null, ''),
        ];
    }

    /** Aktuelle, geprüfte Beschreibung der neuesten Version (mit Zwischenspeicher). */
    public static function manifest(bool $fresh = false): ?array
    {
        if (!$fresh) {
            $cached = get_transient(self::TRANSIENT);
            if (is_array($cached)) {
                return isset($cached['version']) ? $cached : null;
            }
        }
        $response = wp_remote_get(self::manifestUrl(), ['timeout' => 10, 'redirection' => 2]);
        $manifest = null;
        if (!is_wp_error($response) && (int) wp_remote_retrieve_response_code($response) === 200) {
            $manifest = self::parseManifest((string) wp_remote_retrieve_body($response));
        }
        // Auch Fehlschläge merken, damit eine nicht erreichbare Adresse die Seite nicht bei jedem Aufruf bremst
        set_transient(self::TRANSIENT, $manifest ?? ['failed' => time()], $manifest ? self::CACHE_SECONDS : self::RETRY_SECONDS);
        return $manifest;
    }

    /**
     * WordPress fragt beim Suchen nach Updates jedes Plugin mit eigenem „Update URI" über diesen Filter.
     *
     * @param array|false $update
     * @param array       $pluginData
     * @param string      $pluginFile
     * @return array|false
     */
    public static function filterUpdate($update, $pluginData, $pluginFile)
    {
        if ($pluginFile !== self::pluginFile()) {
            return $update;
        }
        $manifest = self::manifest();
        if ($manifest === null) {
            return $update;
        }
        return [
            'id' => self::MANIFEST_URL,
            'slug' => 'schiwyair-wartung',
            'version' => $manifest['version'],
            'url' => 'https://github.com/SchiwyairGmbH/schiwyair-wartung-plugin',
            'package' => $manifest['download_url'],
            'tested' => $manifest['tested'],
            'requires' => $manifest['requires'],
            'requires_php' => $manifest['requires_php'],
        ];
    }

    /** Stimmt die Prüfsumme der Datei mit der unterschriebenen Beschreibung überein? */
    public static function verifyPackage(string $file, array $manifest): bool
    {
        $hash = @hash_file('sha256', $file);
        return is_string($hash) && hash_equals($manifest['sha256'], $hash);
    }

    /**
     * Lädt das eigene Paket selbst herunter und prüft es, bevor WordPress es entpackt.
     *
     * @param bool|\WP_Error|string $reply
     * @param string                $package
     * @param \WP_Upgrader          $upgrader
     * @param array                 $hookExtra
     * @return bool|\WP_Error|string
     */
    public static function filterDownload($reply, $package, $upgrader, $hookExtra = [])
    {
        // Nur Updates dieses Plugins. Dafür gilt ohne Ausnahme: kein geprüftes Paket, keine Installation.
        $ours = is_array($hookExtra) && isset($hookExtra['plugin']) && $hookExtra['plugin'] === self::pluginFile();
        if (!$ours) {
            return $reply;
        }
        // Frisch holen und prüfen: Installiert wird nur genau das Paket aus der unterschriebenen Beschreibung
        $manifest = self::manifest(true);
        if ($manifest === null || !is_string($package) || $package !== $manifest['download_url']) {
            Log::add('selfupdate', 'error', 'Update abgelehnt: Beschreibung nicht gültig unterschrieben oder anderes Paket');
            return new \WP_Error('sww_update_manifest', 'Schiwyair Wartungszentrale: Die Beschreibung des Updates ist nicht gültig unterschrieben.');
        }
        if (!function_exists('download_url')) {
            require_once ABSPATH . 'wp-admin/includes/file.php';
        }
        $file = download_url($package, 300);
        if (is_wp_error($file)) {
            return $file;
        }
        if (!self::verifyPackage($file, $manifest)) {
            @unlink($file);
            Log::add('selfupdate', 'error', 'Update abgelehnt: Prüfsumme des Pakets stimmt nicht', ['version' => $manifest['version']]);
            return new \WP_Error('sww_update_checksum', 'Schiwyair Wartungszentrale: Das Update-Paket wurde verändert und wird nicht installiert.');
        }
        Log::add('selfupdate', 'info', 'Update-Paket geprüft', ['version' => $manifest['version']]);
        return $file;
    }

    /**
     * Neue Versionen dieses Plugins spielt WordPress von selbst ein.
     *
     * @param bool|null $update
     * @param object    $item
     * @return bool|null
     */
    public static function filterAutoUpdate($update, $item)
    {
        if (!is_object($item) || !isset($item->plugin) || $item->plugin !== self::pluginFile()) {
            return $update;
        }
        return !(defined('SCHIWYAIR_WARTUNG_NO_AUTO_UPDATE') && SCHIWYAIR_WARTUNG_NO_AUTO_UPDATE);
    }

    /**
     * Angaben für das Fenster „Details ansehen" in der Pluginliste.
     *
     * @param false|object|array $result
     * @param string             $action
     * @param object             $args
     * @return false|object|array
     */
    public static function filterPluginInfo($result, $action, $args)
    {
        if ($action !== 'plugin_information' || !is_object($args) || !isset($args->slug) || $args->slug !== 'schiwyair-wartung') {
            return $result;
        }
        $manifest = self::manifest();
        return (object) [
            'name' => 'Schiwyair Wartungszentrale',
            'slug' => 'schiwyair-wartung',
            'version' => $manifest['version'] ?? SCHIWYAIR_WARTUNG_VERSION,
            'author' => 'Schiwyair GmbH',
            'homepage' => 'https://schiwyair.de',
            'requires' => $manifest['requires'] ?? '6.0',
            'requires_php' => $manifest['requires_php'] ?? '7.4',
            'tested' => $manifest['tested'] ?? '',
            'download_link' => $manifest['download_url'] ?? '',
            'sections' => [
                'description' => 'Verbindet die Website mit der Wartungszentrale der Schiwyair GmbH. Das Plugin beantwortet nur signierte Anfragen der Zentrale und installiert nur Updates, die von der Schiwyair GmbH unterschrieben sind.',
            ],
        ];
    }
}
