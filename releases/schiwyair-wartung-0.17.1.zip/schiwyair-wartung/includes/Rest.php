<?php

namespace Schiwyair\Wartung;

use WP_REST_Request;
use WP_REST_Response;

defined('ABSPATH') || exit;

/**
 * Feste, einzeln definierte Befehle. Jede Route prüft die Signatur über Auth::check.
 *
 * Parameter werden erst im Callback gelesen ("args" bleibt leer): WordPress prüft "args"
 * vor der Signatur und würde Unbekannten sonst Fehlerdetails zeigen.
 */
final class Rest
{
    public static function registerRoutes(): void
    {
        $routes = [
            ['/ping', 'GET', 'ping'],
            // refresh=1: vorher bei wordpress.org und Herstellern nach Updates suchen
            ['/status', 'GET', 'status'],
            ['/backup', 'POST', 'backup'],
            // job=<ID aus POST /backup>
            ['/backup/status', 'GET', 'backupStatus'],
            // Body: {"type": "plugin"|"theme"|"core", "slug": "...", "version": "..." (nur core)}
            ['/update', 'POST', 'update'],
            // Body: {"type": "plugin"|"theme", "slug": "..."}, nur inaktive Plugins und ungenutzte Themes
            ['/delete', 'POST', 'delete'],
            ['/cache/clear', 'POST', 'cacheClear'],
            // Body: {"slug": "contact-form-7", "copy": "<ID, optional>"}
            ['/rollback', 'POST', 'rollback'],
            // slug=contact-form-7
            ['/copies', 'GET', 'copies'],
            // limit=1..200
            ['/log', 'GET', 'log'],
            // Body: {"redirect_to": "test@agentur.de"}
            ['/formtest/start', 'POST', 'formtestStart'],
            ['/formtest/status', 'GET', 'formtestStatus'],
            ['/formtest/stop', 'POST', 'formtestStop'],
            // Body: {"enabled": true|false, "unlock_minutes": 0..240}
            ['/lockdown', 'POST', 'lockdown'],
            // Wordfence-Scan starten und seinen Stand abfragen
            ['/wordfence/scan', 'POST', 'wordfenceScanStart'],
            ['/wordfence/scan', 'GET', 'wordfenceScanState'],
            // Body: {"email": "name@agentur.de", "name": "Vor Nachname", "role": "administrator"|"editor"}
            ['/account', 'POST', 'accountCreate'],
            // Body: {"plugin": "wp-statistics"|"wordfence", "license": "<optional, nur Wordfence>"}
            ['/setup', 'POST', 'setup'],
            // Body: {"public_key": "<neuer öffentlicher Schlüssel, Base64>"}, signiert mit dem bisherigen
            ['/key', 'POST', 'keyRotate'],
            // Eigene Sicherung (ab 0.17.0), siehe Snapshot.php
            // Body: {"id": "<32 hex>", "recipients": [{"id": "site", "public_key": "<X25519, Base64>"}], "part_size_mb": 50, "excludes": []}
            ['/snapshot/start', 'POST', 'snapshotStart'],
            // Body: {"id": "..."}
            ['/snapshot/step', 'POST', 'snapshotStep'],
            // id=…&n=<Stücknummer>, liefert die Datei selbst
            ['/snapshot/part', 'GET', 'snapshotPart'],
            // Body: {"id": "...", "n": 1}
            ['/snapshot/ack', 'POST', 'snapshotAck'],
            // Body: {"id": "..."}
            ['/snapshot/abort', 'POST', 'snapshotAbort'],
            ['/snapshot/status', 'GET', 'snapshotStatus'],
        ];
        foreach ($routes as [$path, $method, $callback]) {
            register_rest_route(Plugin::REST_NAMESPACE, $path, [
                'methods' => $method,
                'callback' => [self::class, $callback],
                'permission_callback' => [Auth::class, 'check'],
                'args' => [],
                // Nicht im öffentlichen Verzeichnis /wp-json/ aufführen (Fund N2). Gilt je Befehl
                // (WP_REST_Server::get_data_for_route), Routen ohne sichtbaren Befehl fehlen dort ganz.
                'show_in_index' => false,
            ]);
        }
    }

    /**
     * Entfernt den eigenen Namensraum aus /wp-json/ und die Übersicht des Namensraums,
     * damit niemand von außen sieht, welche Befehle es gibt (Fund N2).
     */
    public static function hideFromIndex($response)
    {
        if (is_object($response) && method_exists($response, 'get_data') && method_exists($response, 'set_data')) {
            $data = $response->get_data();
            if (is_array($data) && isset($data['namespaces']) && is_array($data['namespaces'])) {
                $data['namespaces'] = array_values(array_diff($data['namespaces'], [Plugin::REST_NAMESPACE]));
                $response->set_data($data);
            }
        }
        return $response;
    }

    /** @param array $endpoints */
    public static function removeNamespaceRoute($endpoints)
    {
        if (is_array($endpoints)) {
            unset($endpoints['/' . Plugin::REST_NAMESPACE]);
        }
        return $endpoints;
    }

    public static function ping(WP_REST_Request $request): WP_REST_Response
    {
        return self::respond([
            'ok' => true,
            'plugin_version' => SCHIWYAIR_WARTUNG_VERSION,
            'host' => Auth::siteHost(),
            'time' => time(),
        ]);
    }

    public static function status(WP_REST_Request $request): WP_REST_Response
    {
        $refresh = (string) $request->get_param('refresh') === '1';
        return self::respond(Status::collect($refresh));
    }

    public static function backup(WP_REST_Request $request): WP_REST_Response
    {
        $problem = Backup::available();
        if ($problem !== null) {
            return self::respond(['started' => false, 'code' => 'unavailable', 'message' => $problem], 409);
        }
        $running = Backup::runningJob();
        if ($running !== null) {
            return self::respond(['started' => false, 'code' => 'already_running', 'job' => $running, 'message' => 'Es läuft bereits ein Backup.'], 409);
        }
        if (Lock::current() !== null) {
            return self::respond(['started' => false, 'code' => 'locked', 'message' => 'Es läuft gerade ein Update.'], 409);
        }
        Backup::startAndDetach(); // kehrt nicht zurück
        return self::respond(['started' => false], 500);
    }

    public static function backupStatus(WP_REST_Request $request): WP_REST_Response
    {
        $job = (string) $request->get_param('job');
        if (!preg_match('/^[0-9a-f]{6,32}$/', $job)) {
            return self::respond(['code' => 'bad_request', 'message' => 'Ungültige Job-ID'], 400);
        }
        $problem = Backup::available();
        if ($problem !== null) {
            return self::respond(['code' => 'unavailable', 'message' => $problem], 409);
        }
        return self::respond(Backup::status($job));
    }

    public static function update(WP_REST_Request $request): WP_REST_Response
    {
        $body = $request->get_json_params();
        $type = is_array($body) && isset($body['type']) ? (string) $body['type'] : '';
        $slug = is_array($body) && isset($body['slug']) ? (string) $body['slug'] : '';
        $version = is_array($body) && isset($body['version']) ? (string) $body['version'] : '';
        // Plugin: Ordnername oder genau „ordner/datei.php“, Theme: Ordnername. Nie „..“ (Fund N4).
        $validPlugin = PluginCopies::validSlug($slug)
            || (preg_match('#^[A-Za-z0-9][A-Za-z0-9._-]{0,199}/[A-Za-z0-9][A-Za-z0-9._-]{0,199}\.php\z#', $slug) && strpos($slug, '..') === false);
        if (($type === 'plugin' && !$validPlugin) || ($type === 'theme' && !PluginCopies::validSlug($slug))) {
            return self::respond(['ok' => false, 'code' => 'bad_request', 'message' => 'Ungültiger Name'], 400);
        }
        $result = Updater::run($type, $slug, $version);
        $status = 200;
        if (!$result['ok']) {
            $status = in_array($result['code'], ['locked', 'backup_running', 'up_to_date', 'no_package', 'requirements', 'filesystem'], true) ? 409 : 500;
            if (in_array($result['code'], ['bad_request', 'not_found'], true)) {
                $status = 400;
            }
        }
        return self::respond($result, $status);
    }

    public static function delete(WP_REST_Request $request): WP_REST_Response
    {
        $body = $request->get_json_params();
        $type = is_array($body) && isset($body['type']) ? (string) $body['type'] : '';
        $slug = is_array($body) && isset($body['slug']) ? (string) $body['slug'] : '';
        // action: delete (Standard), deactivate oder activate (nur Plugins, für das Löschen aktiver Plugins in Schritten)
        $action = is_array($body) && isset($body['action']) ? (string) $body['action'] : 'delete';
        $result = Remover::run($type, $slug, $action);
        if ($result['ok']) {
            return self::respond($result);
        }
        $status = in_array($result['code'], ['bad_request', 'not_found'], true) ? 400 : (in_array($result['code'], ['active', 'not_allowed', 'locked', 'filesystem'], true) ? 409 : 500);
        return self::respond($result, $status);
    }

    public static function rollback(WP_REST_Request $request): WP_REST_Response
    {
        $body = $request->get_json_params();
        $slug = is_array($body) && isset($body['slug']) ? (string) $body['slug'] : '';
        $copy = is_array($body) && isset($body['copy']) ? (string) $body['copy'] : '';
        if (!PluginCopies::validSlug($slug) || ($copy !== '' && (!preg_match('/^[A-Za-z0-9][A-Za-z0-9._-]{0,79}$/', $copy) || strpos($copy, '..') !== false))) {
            return self::respond(['ok' => false, 'code' => 'bad_request', 'message' => 'Ungültiger Name'], 400);
        }
        $result = PluginCopies::restore($slug, $copy);
        return self::respond($result, $result['ok'] ? 200 : ($result['code'] === 'no_copy' || $result['code'] === 'locked' ? 409 : 500));
    }

    public static function copies(WP_REST_Request $request): WP_REST_Response
    {
        $slug = (string) $request->get_param('slug');
        if (!PluginCopies::validSlug($slug)) {
            return self::respond(['code' => 'bad_request', 'message' => 'Ungültiger Name'], 400);
        }
        return self::respond(['slug' => $slug, 'copies' => PluginCopies::list($slug)]);
    }

    public static function cacheClear(WP_REST_Request $request): WP_REST_Response
    {
        return self::respond(Cache::clearAll());
    }

    public static function log(WP_REST_Request $request): WP_REST_Response
    {
        $limit = (int) ($request->get_param('limit') ?: 50);
        return self::respond(['entries' => Log::recent($limit)]);
    }

    public static function formtestStart(WP_REST_Request $request): WP_REST_Response
    {
        $body = $request->get_json_params();
        $email = is_array($body) && isset($body['redirect_to']) ? sanitize_email((string) $body['redirect_to']) : '';
        if (!is_email($email)) {
            return self::respond(['code' => 'bad_request', 'message' => 'Ungültige Testadresse'], 400);
        }
        return self::respond(FormTest::start($email));
    }

    public static function formtestStatus(WP_REST_Request $request): WP_REST_Response
    {
        return self::respond(FormTest::status());
    }

    public static function formtestStop(WP_REST_Request $request): WP_REST_Response
    {
        return self::respond(FormTest::stop());
    }

    public static function accountCreate(WP_REST_Request $request): WP_REST_Response
    {
        $body = $request->get_json_params();
        $get = static function (string $key) use ($body): string {
            return is_array($body) && isset($body[$key]) && is_string($body[$key]) ? $body[$key] : '';
        };
        $result = Accounts::create($get('email'), $get('name'), $get('role'));
        if ($result['ok']) {
            return self::respond($result);
        }
        $status = $result['code'] === 'bad_request' ? 400 : (in_array($result['code'], ['exists', 'multisite'], true) ? 409 : 500);
        return self::respond($result, $status);
    }

    public static function setup(WP_REST_Request $request): WP_REST_Response
    {
        $body = $request->get_json_params();
        $plugin = is_array($body) && isset($body['plugin']) && is_string($body['plugin']) ? $body['plugin'] : '';
        $license = is_array($body) && isset($body['license']) && is_string($body['license']) ? $body['license'] : '';
        $result = Setup::run($plugin, $license);
        if ($result['ok']) {
            return self::respond($result);
        }
        $status = $result['code'] === 'bad_request' ? 400 : (in_array($result['code'], ['locked', 'filesystem'], true) ? 409 : 500);
        return self::respond($result, $status);
    }

    /**
     * Schlüsselwechsel aus der Zentrale (ab 0.16.0). Nur mit dem bisherigen Schlüssel signiert möglich,
     * im Backend lässt sich ein eingetragener Schlüssel nicht mehr ändern (Fund M1).
     */
    public static function keyRotate(WP_REST_Request $request): WP_REST_Response
    {
        $body = $request->get_json_params();
        $key = is_array($body) && isset($body['public_key']) && is_string($body['public_key']) ? trim($body['public_key']) : '';
        $bytes = Auth::decodePublicKey($key);
        if ($bytes === null) {
            return self::respond(['ok' => false, 'code' => 'bad_request', 'message' => 'Ungültiger Schlüssel'], 400);
        }
        if (Auth::configKey() !== null) {
            return self::respond(['ok' => false, 'code' => 'defined_in_config', 'message' => 'Der Schlüssel steht in der wp-config.php (SCHIWYAIR_WARTUNG_PUBLIC_KEY) und muss dort geändert werden.'], 409);
        }
        Lockdown::internalUpdate(Schema::OPTION_PUBLIC_KEY, $key);
        Log::add('key', 'ok', 'Schlüssel der Zentrale gewechselt, neuer Fingerabdruck ' . Auth::fingerprint($bytes));
        return self::respond(['ok' => true, 'fingerprint' => Auth::fingerprint($bytes)]);
    }

    public static function lockdown(WP_REST_Request $request): WP_REST_Response
    {
        $body = $request->get_json_params();
        $enabled = is_array($body) && isset($body['enabled']) ? $body['enabled'] : null;
        $minutes = is_array($body) && isset($body['unlock_minutes']) ? $body['unlock_minutes'] : 0;
        if (!is_bool($enabled) || !is_int($minutes) || $minutes < 0 || $minutes > Lockdown::MAX_UNLOCK_MINUTES) {
            return self::respond(['ok' => false, 'code' => 'bad_request', 'message' => 'Ungültige Angaben'], 400);
        }
        $state = Lockdown::set($enabled, $minutes);
        if ($state['disabled_by_config']) {
            return self::respond(['ok' => false, 'code' => 'disabled_by_config', 'message' => 'In der wp-config.php ist der Sperrmodus abgeschaltet (SCHIWYAIR_WARTUNG_LOCKDOWN_OFF).', 'lockdown' => $state], 409);
        }
        return self::respond(['ok' => true, 'lockdown' => $state]);
    }

    public static function wordfenceScanStart(WP_REST_Request $request): WP_REST_Response
    {
        $problem = WordfenceScan::available();
        if ($problem !== null) {
            return self::respond(['started' => false, 'code' => 'unavailable', 'message' => $problem], 409);
        }
        if (WordfenceScan::running()) {
            return self::respond(['started' => false, 'code' => 'already_running', 'message' => 'Es läuft bereits ein Scan.'], 409);
        }
        if (Lock::current() !== null) {
            return self::respond(['started' => false, 'code' => 'locked', 'message' => 'Es läuft gerade ein Update.'], 409);
        }
        $result = WordfenceScan::start();
        return self::respond($result, $result['started'] ? 200 : 500);
    }

    public static function wordfenceScanState(WP_REST_Request $request): WP_REST_Response
    {
        $problem = WordfenceScan::available();
        if ($problem !== null) {
            return self::respond(['code' => 'unavailable', 'message' => $problem], 409);
        }
        return self::respond(WordfenceScan::state());
    }

    public static function snapshotStart(WP_REST_Request $request): WP_REST_Response
    {
        $body = $request->get_json_params();
        return self::respondResult(Snapshot::start(is_array($body) ? $body : []));
    }

    public static function snapshotStep(WP_REST_Request $request): WP_REST_Response
    {
        return self::respondResult(Snapshot::step(self::bodyString($request, 'id')));
    }

    public static function snapshotAck(WP_REST_Request $request): WP_REST_Response
    {
        $body = $request->get_json_params();
        $n = is_array($body) && isset($body['n']) && is_int($body['n']) ? $body['n'] : 0;
        if ($n < 1 || $n > 1000000) {
            return self::respond(['ok' => false, 'code' => 'bad_request', 'message' => 'Ungültige Stücknummer'], 400);
        }
        return self::respondResult(Snapshot::ack(self::bodyString($request, 'id'), $n));
    }

    public static function snapshotAbort(WP_REST_Request $request): WP_REST_Response
    {
        return self::respondResult(Snapshot::abort(self::bodyString($request, 'id')));
    }

    public static function snapshotStatus(WP_REST_Request $request): WP_REST_Response
    {
        return self::respond(Snapshot::info());
    }

    /**
     * Liefert ein fertiges Stück als Datei. Die Signatur ist zu diesem Zeitpunkt geprüft (Auth::check);
     * gestreamt wird direkt, ohne die Datei in den Speicher zu laden.
     */
    public static function snapshotPart(WP_REST_Request $request)
    {
        $n = (string) $request->get_param('n');
        if (!preg_match('/^[1-9][0-9]{0,6}\z/', $n)) {
            return self::respond(['ok' => false, 'code' => 'bad_request', 'message' => 'Ungültige Stücknummer'], 400);
        }
        $result = Snapshot::partFile((string) $request->get_param('id'), (int) $n);
        if (!$result['ok']) {
            return self::respondResult($result);
        }
        $handle = @fopen($result['path'], 'rb');
        if ($handle === false) {
            return self::respond(['ok' => false, 'code' => 'filesystem', 'message' => 'Stück ließ sich nicht lesen'], 500);
        }
        if (function_exists('set_time_limit')) {
            @set_time_limit(600);
        }
        while (ob_get_level() > 0) {
            ob_end_clean();
        }
        header('Content-Type: application/octet-stream');
        header('Content-Length: ' . $result['size']);
        header('X-SWW-Sha256: ' . $result['sha256']);
        header('Cache-Control: no-store, max-age=0');
        header('X-Content-Type-Options: nosniff');
        while (!feof($handle)) {
            $chunk = fread($handle, 1048576);
            if ($chunk === false) {
                break;
            }
            echo $chunk;
            flush();
        }
        fclose($handle);
        exit;
    }

    private static function bodyString(WP_REST_Request $request, string $key): string
    {
        $body = $request->get_json_params();
        return is_array($body) && isset($body[$key]) && is_string($body[$key]) ? $body[$key] : '';
    }

    /** Ergebnis mit „status“ (HTTP-Code) als Antwort, „status“ selbst wird nicht mitgeschickt */
    private static function respondResult(array $result): WP_REST_Response
    {
        $status = (int) ($result['status'] ?? 200);
        unset($result['status']);
        return self::respond($result, $status);
    }

    private static function respond(array $data, int $status = 200): WP_REST_Response
    {
        $response = new WP_REST_Response($data, $status);
        $response->header('Cache-Control', 'no-store, max-age=0');
        return $response;
    }
}
