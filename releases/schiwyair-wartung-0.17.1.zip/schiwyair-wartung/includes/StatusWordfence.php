<?php

namespace Schiwyair\Wartung;

defined('ABSPATH') || exit;

/**
 * Wordfence (kostenlose Version). Fundstellen: docs/fundstellen.md
 */
final class StatusWordfence
{
    private const PLUGIN_FILE = 'wordfence/wordfence.php';

    /**
     * Funde, bei denen schon das Vorhandensein einer Datei das Problem ist (öffentliche Konfigurations-,
     * Backup- oder Protokolldatei, Schadcode, unbekannte oder alte Core-Datei). Ist die Datei weg, ist der
     * Fund erledigt, auch wenn Wordfence ihn bis zum nächsten Scan als offen führt.
     */
    private const FILE_TYPES = ['configReadable', 'publiclyAccessible', 'file', 'knownfile'];

    public static function collect(): array
    {
        $active = defined('WORDFENCE_VERSION') && class_exists('wfConfig');

        if (!$active) {
            $installed = array_key_exists(self::PLUGIN_FILE, get_plugins());
            return Status::thirdParty(
                self::PLUGIN_FILE,
                false,
                null,
                null,
                $installed ? 'Wordfence ist installiert, aber nicht aktiv' : 'Wordfence ist nicht installiert'
            );
        }

        return Status::thirdParty(self::PLUGIN_FILE, true, (string) WORDFENCE_VERSION, [
            'scan' => Status::section([self::class, 'scan']),
            'issues' => Status::section([self::class, 'issues']),
            'firewall' => Status::section([self::class, 'firewall']),
        ], null);
    }

    public static function scan(): array
    {
        $time = class_exists('wfScanner') ? \wfScanner::shared()->lastScanTime() : \wfConfig::get('scanTime');
        $result = (string) \wfConfig::get('lastScanCompleted', '');
        $failed = class_exists('wfIssues') ? \wfIssues::hasScanFailed() : false;

        return [
            'last_scan_at' => $time ? (int) $time : null,
            'last_scan_ok' => $result === '' ? null : $result === 'ok',
            'last_scan_message' => ($result !== '' && $result !== 'ok') ? Redact::text($result, 300) : null,
            'running' => class_exists('wfScanner') ? (bool) \wfScanner::shared()->isRunning() : null,
            // Scan angefordert, aber noch nicht angelaufen (Wordfence löscht den Eintrag, sobald der Scan loslegt)
            'start_pending' => (int) \wfConfig::get('scanStartAttempt', 0) > 0,
            'failure' => $failed ? (string) $failed : null,
        ];
    }

    public static function issues(): array
    {
        global $wpdb;
        if (!class_exists('wfDB')) {
            return ['open' => null, 'reason' => 'Wordfence-Tabellen nicht ermittelbar'];
        }
        $table = \wfDB::networkTable('wfIssues');
        $table = str_replace('`', '', $table);

        // Bei eingeschalteter Fehleranzeige gäbe wpdb Fehler als HTML aus und zerstörte die JSON-Antwort
        $suppress = $wpdb->suppress_errors(true);
        $rows = $wpdb->get_results(
            "SELECT severity, COUNT(*) AS c FROM `{$table}` WHERE status = 'new' GROUP BY severity",
            ARRAY_A
        );
        $ignored = $wpdb->get_var("SELECT COUNT(*) FROM `{$table}` WHERE status IN ('ignoreP', 'ignoreC')");

        if ($rows === null || $wpdb->last_error !== '') {
            $wpdb->suppress_errors($suppress);
            return ['open' => null, 'reason' => 'Tabelle der Funde nicht lesbar'];
        }

        $bySeverity = ['critical' => 0, 'high' => 0, 'medium' => 0, 'low' => 0, 'none' => 0];
        foreach ($rows as $row) {
            $bySeverity[self::severityName((int) $row['severity'])] += (int) $row['c'];
        }

        // Dateibezogene Funde, deren Datei inzwischen gelöscht ist: zählen nicht mehr als offen.
        // Der Datensatz in Wordfence bleibt unverändert, der nächste Scan räumt ihn selbst ab.
        $gone = [];
        $types = "'" . implode("', '", self::FILE_TYPES) . "'";
        $fileRows = $wpdb->get_results(
            "SELECT id, type, severity, data FROM `{$table}` WHERE status = 'new' AND type IN ({$types}) LIMIT 500",
            ARRAY_A
        );
        foreach ((array) $fileRows as $row) {
            if (self::fileGone((string) $row['type'], (string) $row['data'])) {
                $severity = self::severityName((int) $row['severity']);
                $gone[(int) $row['id']] = true;
                $bySeverity[$severity] = max(0, $bySeverity[$severity] - 1);
            }
        }

        // Die offenen Funde selbst (Kurztext wie in Wordfence), die schwersten zuerst
        $items = [];
        $list = $wpdb->get_results(
            "SELECT id, type, severity, shortMsg, time FROM `{$table}` WHERE status = 'new' ORDER BY severity DESC, time DESC LIMIT 20",
            ARRAY_A
        );
        foreach ((array) $list as $row) {
            $items[] = [
                'type' => (string) $row['type'],
                'severity' => self::severityName((int) $row['severity']),
                'text' => Redact::text(wp_strip_all_tags((string) $row['shortMsg']), 200),
                'time' => (int) $row['time'],
                // Datei gelöscht, Bestätigung durch den nächsten Scan steht aus
                'file_gone' => isset($gone[(int) $row['id']]),
            ];
        }
        $wpdb->suppress_errors($suppress);

        return [
            'open' => array_sum($bySeverity),
            'by_severity' => $bySeverity,
            'items' => $items,
            'ignored' => (int) $ignored,
            'file_gone' => count($gone),
        ];
    }

    /**
     * Ob die Datei eines dateibezogenen Fundes nicht mehr existiert. Nur Prüfung auf Vorhandensein, kein Lesen,
     * und nur innerhalb der WordPress-Installation. Veränderte Core-, Plugin- oder Theme-Dateien (knownfile mit
     * Vergleichsansicht) gelten immer als offen.
     */
    private static function fileGone(string $type, string $raw): bool
    {
        $data = @unserialize($raw, ['allowed_classes' => false]);
        if (!is_array($data)) {
            return false;
        }
        if ($type === 'knownfile' && !empty($data['canDiff'])) {
            return false;
        }
        $path = isset($data['realFile']) && is_string($data['realFile']) && $data['realFile'] !== ''
            ? $data['realFile']
            : (isset($data['file']) && is_string($data['file']) && $data['file'] !== '' ? ABSPATH . ltrim($data['file'], '/') : '');
        if ($path === '' || strpos($path, '..') !== false || strpos($path, chr(0)) !== false) {
            return false;
        }
        $path = wp_normalize_path($path);
        $roots = [trailingslashit(wp_normalize_path(ABSPATH)), trailingslashit(wp_normalize_path(WP_CONTENT_DIR))];
        $inside = false;
        foreach ($roots as $root) {
            if (strpos($path, $root) === 0) {
                $inside = true;
            }
        }
        if (!$inside) {
            return false;
        }
        clearstatcache(true, $path);
        return !file_exists($path);
    }

    /** Schweregrade laut wfIssues::SEVERITY_* (100, 75, 50, 25, 0). */
    private static function severityName(int $severity): string
    {
        if ($severity >= 100) {
            return 'critical';
        }
        if ($severity >= 75) {
            return 'high';
        }
        if ($severity >= 50) {
            return 'medium';
        }
        if ($severity >= 25) {
            return 'low';
        }
        return 'none';
    }

    public static function firewall(): array
    {
        if (!class_exists('wfFirewall')) {
            return ['mode' => null, 'reason' => 'Firewall-Modul nicht geladen'];
        }
        $firewall = new \wfFirewall();
        return [
            'mode' => (string) $firewall->firewallMode(),
            'protection' => (string) $firewall->protectionMode(),
        ];
    }
}
