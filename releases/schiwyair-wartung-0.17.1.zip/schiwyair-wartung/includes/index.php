<?php
// Kein direkter Zugriff.
