<?php

namespace Schiwyair\Wartung;

defined('ABSPATH') || exit;

/**
 * Datenbank-Auszug in Etappen (ohne mysqldump, das es auf Shared Hosting oft nicht gibt).
 *
 * - Nur Tabellen mit dem Präfix dieser Installation, keine Ansichten.
 * - Tabelle für Tabelle, Zeilen in Blöcken: über den Primärschlüssel, wenn er aus genau einer
 *   Ganzzahl-Spalte besteht, sonst mit LIMIT/OFFSET.
 * - Keine Tabellensperren. Was sich während der Sicherung ändert, kann halb enthalten sein
 *   (wie bei UpdraftPlus).
 * - Ergebnis: Abschnitte datenbank/000001.sql, 000002.sql … im Archiv. Hintereinander gehängt
 *   ergeben sie eine normale SQL-Datei (phpMyAdmin, mysql). Der letzte Abschnitt endet mit „-- SWW-ENDE“.
 */
final class SnapshotDb
{
    private const ROWS_PER_QUERY = 500;
    private const MAX_STATEMENT = 512000;
    private const SECTION_BYTES = 2097152;

    /** Eigene Tabellen ohne Inhalt für eine Wiederherstellung */
    public static function excludedTables(): array
    {
        return [Schema::noncesTable(), Schema::throttleTable()];
    }

    public static function initialState(): array
    {
        global $wpdb;
        $like = $wpdb->esc_like($wpdb->base_prefix) . '%';
        $rows = $wpdb->get_results($wpdb->prepare('SHOW FULL TABLES LIKE %s', $like), ARRAY_N);
        $tables = [];
        foreach ((array) $rows as $row) {
            if (isset($row[0], $row[1]) && strtoupper((string) $row[1]) === 'BASE TABLE' && !in_array($row[0], self::excludedTables(), true)) {
                $tables[] = (string) $row[0];
            }
        }
        sort($tables, SORT_STRING);
        return ['tables' => $tables, 'index' => 0, 'started' => false, 'cursor' => null, 'offset' => 0, 'rows' => 0, 'section' => 0];
    }

    /**
     * Arbeitet bis zur Frist weiter.
     *
     * @return bool true, wenn alle Tabellen fertig sind
     */
    public static function step(array &$db, SnapshotWriter $writer, float $deadline): bool
    {
        global $wpdb;
        $writer->setLevel(6);
        $sql = '';
        if ((int) $db['section'] === 0) {
            $sql .= "-- Datenbank-Sicherung der Wartungszentrale (Schiwyair)\n"
                . '-- Erstellt: ' . gmdate('c') . "\n"
                . '-- Präfix: ' . $wpdb->base_prefix . "\n"
                . 'SET NAMES ' . self::charset() . ";\n"
                . "SET FOREIGN_KEY_CHECKS=0;\n"
                . "SET SQL_MODE='NO_AUTO_VALUE_ON_ZERO';\n"
                . "SET time_zone='+00:00';\n\n";
        }

        $suppress = $wpdb->suppress_errors(true);
        try {
            while ($db['index'] < count($db['tables'])) {
                if (microtime(true) > $deadline || $writer->blocked()) {
                    break;
                }
                $table = $db['tables'][$db['index']];
                $quoted = self::quoteName($table);

                if (!$db['started']) {
                    $create = $wpdb->get_row('SHOW CREATE TABLE ' . $quoted, ARRAY_N);
                    if (!is_array($create) || !isset($create[1])) {
                        throw new \RuntimeException('Tabelle ' . $table . ' ließ sich nicht lesen: ' . self::lastError());
                    }
                    $sql .= "\n--\n-- Tabelle " . $table . "\n--\nDROP TABLE IF EXISTS " . $quoted . ";\n" . $create[1] . ";\n\n";
                    $db['started'] = true;
                    $db['cursor'] = null;
                    $db['offset'] = 0;
                    $db['meta'] = self::meta($table);
                }

                $meta = $db['meta'];
                if ($meta['key'] !== null) {
                    $where = $db['cursor'] === null ? '' : ' WHERE ' . self::quoteName($meta['key']) . ' > ' . (int) $db['cursor'];
                    $query = 'SELECT * FROM ' . $quoted . $where . ' ORDER BY ' . self::quoteName($meta['key']) . ' ASC LIMIT ' . self::ROWS_PER_QUERY;
                } else {
                    $order = $meta['order'] ? ' ORDER BY ' . implode(', ', array_map([self::class, 'quoteName'], $meta['order'])) : '';
                    $query = 'SELECT * FROM ' . $quoted . $order . ' LIMIT ' . (int) $db['offset'] . ', ' . self::ROWS_PER_QUERY;
                }
                $rows = $wpdb->get_results($query, ARRAY_N);
                if ($wpdb->last_error !== '') {
                    throw new \RuntimeException('Tabelle ' . $table . ' ließ sich nicht lesen: ' . self::lastError());
                }
                $rows = (array) $rows;

                $statement = '';
                $insertHead = 'INSERT INTO ' . $quoted . ' VALUES ';
                foreach ($rows as $row) {
                    $values = [];
                    foreach ($row as $i => $value) {
                        $values[] = self::value($value, $meta['binary'][$i] ?? false);
                    }
                    $tuple = '(' . implode(',', $values) . ')';
                    if ($statement !== '' && strlen($statement) + strlen($tuple) > self::MAX_STATEMENT) {
                        $sql .= $statement . ";\n";
                        $statement = '';
                    }
                    $statement .= ($statement === '' ? $insertHead : ',') . $tuple;
                    if ($meta['key'] !== null) {
                        $db['cursor'] = (int) $row[$meta['key_index']];
                    }
                }
                if ($statement !== '') {
                    $sql .= $statement . ";\n";
                }
                $db['offset'] += count($rows);
                $db['rows'] += count($rows);

                if (count($rows) < self::ROWS_PER_QUERY) {
                    $db['index']++;
                    $db['started'] = false;
                    unset($db['meta']);
                }
                if (strlen($sql) >= self::SECTION_BYTES) {
                    self::flush($db, $writer, $sql);
                    $sql = '';
                }
            }
        } finally {
            $wpdb->suppress_errors($suppress);
        }

        $done = $db['index'] >= count($db['tables']);
        if ($done) {
            $sql .= "\nSET FOREIGN_KEY_CHECKS=1;\n-- SWW-ENDE\n";
        }
        if ($sql !== '') {
            self::flush($db, $writer, $sql);
        }
        return $done;
    }

    private static function flush(array &$db, SnapshotWriter $writer, string $sql): void
    {
        $db['section']++;
        $writer->tarString('datenbank/' . sprintf('%06d', $db['section']) . '.sql', $sql, time());
    }

    /** Primärschlüssel und Binärspalten einer Tabelle */
    private static function meta(string $table): array
    {
        global $wpdb;
        $columns = (array) $wpdb->get_results('SHOW COLUMNS FROM ' . self::quoteName($table), ARRAY_A);
        $primary = [];
        $binary = [];
        $types = [];
        foreach ($columns as $i => $column) {
            $type = strtolower((string) ($column['Type'] ?? ''));
            $types[$i] = $type;
            $binary[$i] = (bool) preg_match('/blob|binary|^bit|geometry|point|polygon|linestring/', $type);
            if (($column['Key'] ?? '') === 'PRI') {
                $primary[] = ['name' => (string) $column['Field'], 'index' => $i];
            }
        }
        $key = null;
        $keyIndex = null;
        if (count($primary) === 1 && preg_match('/^(tiny|small|medium|big)?int/', $types[$primary[0]['index']])) {
            $key = $primary[0]['name'];
            $keyIndex = $primary[0]['index'];
        }
        return [
            'key' => $key,
            'key_index' => $keyIndex,
            'order' => array_map(static function ($p) {
                return $p['name'];
            }, $primary),
            'binary' => $binary,
        ];
    }

    private static function value($value, bool $binary): string
    {
        global $wpdb;
        if ($value === null) {
            return 'NULL';
        }
        $value = (string) $value;
        if ($binary) {
            return $value === '' ? "''" : '0x' . bin2hex($value);
        }
        // _real_escape setzt Platzhalter für „%“ ein (ab WordPress 4.8.3), die hier wieder weg müssen
        return "'" . $wpdb->remove_placeholder_escape($wpdb->_real_escape($value)) . "'";
    }

    public static function quoteName(string $name): string
    {
        return '`' . str_replace('`', '``', $name) . '`';
    }

    private static function charset(): string
    {
        global $wpdb;
        $charset = isset($wpdb->charset) && preg_match('/^[a-z0-9_]+\z/i', (string) $wpdb->charset) ? (string) $wpdb->charset : 'utf8mb4';
        return $charset;
    }

    private static function lastError(): string
    {
        global $wpdb;
        return Redact::text((string) $wpdb->last_error, 200);
    }
}
