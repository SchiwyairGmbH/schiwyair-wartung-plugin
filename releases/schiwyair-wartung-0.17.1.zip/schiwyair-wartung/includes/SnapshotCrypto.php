<?php

namespace Schiwyair\Wartung;

defined('ABSPATH') || exit;

/**
 * Verschlüsselung der eigenen Sicherung (Format 1, siehe docs/sicherung-format.md).
 *
 * - Je Sicherung ein zufälliger Schlüssel K (32 Bytes).
 * - K wird für jeden Empfänger (Zentrale je Seite, Notfallschlüssel) eingepackt:
 *   X25519 mit Einmal-Schlüsselpaar, daraus per HKDF-SHA256 ein Schlüssel, damit K per
 *   ChaCha20-Poly1305 (IETF) verschlüsselt. Die Seite kann K danach nicht mehr herstellen.
 * - Die Daten werden in Blöcken (höchstens 1 MiB) mit ChaCha20-Poly1305 (IETF) und Zufalls-Nonce
 *   verschlüsselt. Zusatzdaten binden jeden Block an Sicherung, Stück und Position, so fallen
 *   vertauschte, fehlende oder angehängte Blöcke beim Entschlüsseln auf.
 *
 * Alle Funktionen gibt es in der PHP-Erweiterung sodium und im sodium_compat von WordPress.
 */
final class SnapshotCrypto
{
    public const FORMAT = 1;
    public const MAGIC = 'SWWSICH1';
    public const BLOCK_PLAIN = 1048576;

    public static function load(): void
    {
        if (!function_exists('sodium_crypto_aead_chacha20poly1305_ietf_encrypt') && is_readable(ABSPATH . WPINC . '/sodium_compat/autoload.php')) {
            require_once ABSPATH . WPINC . '/sodium_compat/autoload.php';
        }
    }

    /** null = alles da, sonst Grund */
    public static function problem(): ?string
    {
        self::load();
        foreach (['sodium_crypto_aead_chacha20poly1305_ietf_encrypt', 'sodium_crypto_scalarmult', 'sodium_crypto_scalarmult_base'] as $fn) {
            if (!function_exists($fn)) {
                return 'Verschlüsselung (sodium) ist auf dem Server nicht verfügbar';
            }
        }
        if (!function_exists('hash_hkdf')) {
            return 'hash_hkdf fehlt (PHP zu alt)';
        }
        return null;
    }

    /** native = PHP-Erweiterung, compat = sodium_compat von WordPress (langsamer) */
    public static function engine(): string
    {
        return extension_loaded('sodium') ? 'native' : 'compat';
    }

    /**
     * Packt K für einen Empfänger ein.
     *
     * @return array{epk: string, nonce: string, wrapped: string}
     */
    public static function wrapKey(string $key, string $recipientPublic, string $snapshotId): array
    {
        self::load();
        $ephemeralSecret = random_bytes(32);
        $ephemeralPublic = sodium_crypto_scalarmult_base($ephemeralSecret);
        $shared = sodium_crypto_scalarmult($ephemeralSecret, $recipientPublic);
        if ($shared === str_repeat("\0", 32)) {
            throw new \RuntimeException('Ungültiger Empfängerschlüssel');
        }
        $kek = hash_hkdf('sha256', $shared, 32, 'sww-sicherung-v1 key', $ephemeralPublic . $recipientPublic);
        $nonce = random_bytes(12);
        $wrapped = sodium_crypto_aead_chacha20poly1305_ietf_encrypt($key, 'sww1-key|' . $snapshotId, $nonce, $kek);
        return [
            'epk' => base64_encode($ephemeralPublic),
            'nonce' => base64_encode($nonce),
            'wrapped' => base64_encode($wrapped),
        ];
    }

    public static function blockAd(string $snapshotId, int $part, int $block, bool $final): string
    {
        return 'sww1|' . $snapshotId . '|' . $part . '|' . $block . '|' . ($final ? '1' : '0');
    }

    /** Ein Block, wie er in der Datei steht: Länge (4 Bytes, big endian), Nonce (12), Chiffrat */
    public static function encryptBlock(string $plain, string $key, string $snapshotId, int $part, int $block, bool $final): string
    {
        self::load();
        $nonce = random_bytes(12);
        $cipher = sodium_crypto_aead_chacha20poly1305_ietf_encrypt($plain, self::blockAd($snapshotId, $part, $block, $final), $nonce, $key);
        return pack('N', strlen($cipher)) . $nonce . $cipher;
    }

    public static function partHeader(int $part): string
    {
        return self::MAGIC . pack('N', $part) . pack('N', 0);
    }

    /** Öffentlicher X25519-Schlüssel aus Base64 (Standard oder URL-Alphabet), 32 Bytes */
    public static function decodePublicKey($value): ?string
    {
        if (!is_string($value) || !preg_match('/^[A-Za-z0-9+\/_-]{43}=?\z/', $value)) {
            return null;
        }
        $raw = base64_decode(strtr($value, '-_', '+/') . (strlen($value) === 43 ? '=' : ''), true);
        return is_string($raw) && strlen($raw) === 32 ? $raw : null;
    }
}
