<?php

namespace Schiwyair\Wartung;

defined('ABSPATH') || exit;

/**
 * Kopien von Plugin-Ordnern vor einem Update oder Löschen (für den Rollback).
 *
 * Ablage (ab 0.16.0, siehe docs/sicherheitspruefung-plugin.md, Fund H1):
 * - Ordner mit zufälligem Namen, möglichst außerhalb des Webroots, sonst in wp-content.
 *   „Außerhalb" ist nicht sicher: Bei vielen Hostern zeigt eine andere Domain auf den Ordner darüber.
 * - Jede Kopie ist ein Zip-Archiv mit zufälligem Namen. Selbst wenn jemand den Ordner von außen
 *   erreicht, liegen dort keine ausführbaren PHP-Dateien alter Plugin-Versionen.
 * - In jedem angelegten Ordner index.php, .htaccess und web.config (Nginx beachtet nur den Zufallsnamen).
 * Aufbewahrt werden die letzten 3 Kopien je Plugin.
 */
final class PluginCopies
{
    public const KEEP = 3;
    /** Version des Ablageformats in der Option (2 = Zip-Archive in Ordnern mit Zufallsnamen) */
    private const FORMAT = 2;
    /** Früherer fester Name des Ordners außerhalb des Webroots (bis 0.15.0) */
    private const LEGACY_OUTSIDE = 'schiwyair-wartung-kopien';
    /** Beiseitegelegte Plugin-Ordner während eines Rollbacks beginnen so (im Plugin-Ordner) */
    private const PARKED_PREFIX = '.sww-alt-';

    /**
     * @return array{path: string, location: string, format?: int}|null
     */
    public static function base(): ?array
    {
        $stored = get_option(Schema::OPTION_COPY_DIR, '');
        $valid = is_array($stored) && !empty($stored['path']) && self::isOwnDir((string) $stored['path'])
            && @is_dir($stored['path']) && @is_writable($stored['path']);

        if ($valid && (int) ($stored['format'] ?? 0) === self::FORMAT && !self::isLegacyDir((string) $stored['path'])) {
            return $stored;
        }

        // Neue Ablage anlegen und, falls vorhanden, die alte übernehmen
        $outside = self::outsideWebroot();
        $base = $outside
            ? ['path' => $outside, 'location' => 'outside_webroot']
            : self::insideWpContent();
        if ($base === null) {
            return null;
        }
        $base['format'] = self::FORMAT;
        if ($valid) {
            self::migrate((string) $stored['path'], $base['path']);
        }
        // Ordner mit dem früheren festen Namen auch ohne Eintrag in der Option abräumen
        $legacy = self::legacyOutsidePath();
        if ($legacy !== null && @is_dir($legacy) && (!$valid || $legacy !== rtrim(wp_normalize_path((string) $stored['path']), '/'))) {
            self::migrate($legacy, $base['path']);
        }
        Lockdown::internalUpdate(Schema::OPTION_COPY_DIR, $base);
        return $base;
    }

    /**
     * Nur Ordner, die das Plugin selbst anlegt, gelten als Ablage. Sonst könnte jemand mit Zugriff auf
     * die Einstellungen die Kopien (alte, evtl. verwundbare Plugin-Versionen) in einen öffentlichen
     * Ordner umleiten oder ein Zurückspielen aus einem fremden Ordner auslösen.
     */
    public static function isOwnDir(string $path): bool
    {
        $path = rtrim(wp_normalize_path($path), '/');
        $parent = realpath(dirname(untrailingslashit(ABSPATH)));
        if ($parent) {
            $parentNorm = rtrim(wp_normalize_path($parent), '/');
            if ($path === $parentNorm . '/' . self::LEGACY_OUTSIDE
                || preg_match('#^' . preg_quote($parentNorm, '#') . '/sww-kopien-[0-9a-f]{32}\z#', $path)
            ) {
                return true;
            }
        }
        $content = rtrim(wp_normalize_path(WP_CONTENT_DIR), '/');
        return (bool) preg_match('#^' . preg_quote($content, '#') . '/sww-kopien-[0-9a-f]{16,32}\z#', $path);
    }

    private static function isLegacyDir(string $path): bool
    {
        $legacy = self::legacyOutsidePath();
        return $legacy !== null && rtrim(wp_normalize_path($path), '/') === $legacy;
    }

    private static function legacyOutsidePath(): ?string
    {
        $parent = realpath(dirname(untrailingslashit(ABSPATH)));
        return $parent ? rtrim(wp_normalize_path($parent), '/') . '/' . self::LEGACY_OUTSIDE : null;
    }

    /** Ordnername eines Plugins: kein „.", kein „..", keine Pfade. */
    public static function validSlug(string $slug): bool
    {
        return (bool) preg_match('/^[A-Za-z0-9][A-Za-z0-9._-]{0,199}\z/', $slug) && strpos($slug, '..') === false;
    }

    private static function outsideWebroot(): ?string
    {
        $docroot = isset($_SERVER['DOCUMENT_ROOT']) ? realpath((string) $_SERVER['DOCUMENT_ROOT']) : false;
        if (!$docroot) {
            return null; // Ohne bekannten Webroot lässt sich „außerhalb" nicht sicher bestimmen
        }
        $parent = realpath(dirname(untrailingslashit(ABSPATH)));
        if (!$parent || !@is_writable($parent)) {
            return null;
        }
        $candidate = rtrim(wp_normalize_path($parent), '/') . '/sww-kopien-' . bin2hex(random_bytes(16));
        $docrootNorm = rtrim(wp_normalize_path($docroot), '/') . '/';
        if (strpos($candidate . '/', $docrootNorm) === 0) {
            return null; // läge im Webroot
        }
        if (!@mkdir($candidate, 0700)) {
            return null;
        }
        self::protect($candidate);
        return @is_writable($candidate) ? $candidate : null;
    }

    private static function insideWpContent(): ?array
    {
        $dir = rtrim(wp_normalize_path(WP_CONTENT_DIR), '/') . '/sww-kopien-' . bin2hex(random_bytes(16));
        if (!@mkdir($dir, 0750)) {
            return null;
        }
        self::protect($dir);
        return ['path' => $dir, 'location' => 'wp_content_protected'];
    }

    /** Zugriffssperre für Apache und IIS, leere index.php gegen Verzeichnisanzeige. Nginx: Zufallsnamen. */
    public static function protect(string $dir): void
    {
        if (!@is_file($dir . '/index.php')) {
            @file_put_contents($dir . '/index.php', "<?php\n// Kein Zugriff.\n");
        }
        if (!@is_file($dir . '/.htaccess')) {
            @file_put_contents($dir . '/.htaccess', "Require all denied\n<IfModule !mod_authz_core.c>\nDeny from all\n</IfModule>\nOptions -Indexes\n");
        }
        if (!@is_file($dir . '/web.config')) {
            @file_put_contents($dir . '/web.config', '<?xml version="1.0"?><configuration><system.webServer><authorization><deny users="*" /></authorization></system.webServer></configuration>');
        }
    }

    /** Legt einen Ordner an (auch Zwischenordner) und schützt jeden neu angelegten. */
    private static function mkdirProtected(string $dir): bool
    {
        if (@is_dir($dir)) {
            return true;
        }
        if (!self::mkdirProtected(dirname($dir)) || (!@mkdir($dir, 0750) && !@is_dir($dir))) {
            return false;
        }
        self::protect($dir);
        return true;
    }

    /**
     * Kopiert einen Plugin-Ordner (oder ein Einzeldatei-Plugin) in ein Archiv.
     *
     * @return array{id: string, location: string, files: int}|null
     */
    public static function create(string $slug, string $source, string $version): ?array
    {
        $base = self::base();
        if ($base === null || !self::validSlug($slug)) {
            return null;
        }
        self::cleanupParked();
        $id = gmdate('Ymd-His') . '_' . preg_replace('/[^A-Za-z0-9.]+/', '-', $version);
        $target = $base['path'] . '/' . $slug . '/' . $id;
        if (@is_dir($target) || !self::mkdirProtected($target)) {
            return null;
        }

        $archive = 'kopie-' . bin2hex(random_bytes(16)) . '.zip';
        $singleFile = !is_dir($source);
        $files = $singleFile
            ? (is_file($source) ? self::zipFiles([basename($source) => $source], $target . '/' . $archive) : 0)
            : self::zipDir($source, $target . '/' . $archive);
        if ($files === 0) {
            self::removeDir($target);
            return null;
        }

        @file_put_contents($target . '/meta.json', wp_json_encode([
            'slug' => $slug,
            'version' => $version,
            'created_at' => time(),
            'source' => basename($source),
            'single_file' => $singleFile,
            'archive' => $archive,
            'files' => $files,
        ]));
        self::prune($slug);

        return ['id' => $id, 'location' => $base['location'], 'files' => $files];
    }

    /**
     * Spielt eine Kopie zurück (Standard: die neueste). Der aktuelle Ordner wird erst
     * beiseitegelegt und nur bei Erfolg gelöscht, sonst wiederhergestellt.
     *
     * @return array Ergebnis; bei Fehlern ok=false mit code und message
     */
    public static function restore(string $slug, string $copyId = ''): array
    {
        $fail = static function (string $code, string $message) use ($slug) {
            Log::add('rollback', 'error', "{$slug}: {$message}");
            return ['ok' => false, 'slug' => $slug, 'code' => $code, 'message' => $message];
        };
        $copies = self::list($slug);
        $copy = null;
        foreach ($copies as $candidate) {
            if ($copyId === '' || $candidate['id'] === $copyId) {
                $copy = $candidate;
                break;
            }
        }
        $base = self::base();
        if ($copy === null || $base === null) {
            return $fail('no_copy', 'Keine Sicherungskopie für dieses Plugin vorhanden');
        }
        $dir = $base['path'] . '/' . $slug . '/' . $copy['id'];
        $meta = json_decode((string) @file_get_contents($dir . '/meta.json'), true);
        $meta = is_array($meta) ? $meta : [];
        $singleFile = !empty($meta['single_file']);
        $sourceName = basename((string) ($meta['source'] ?? ''));
        if ($singleFile && !preg_match('/^[A-Za-z0-9][A-Za-z0-9._-]{0,199}\.php\z/', $sourceName)) {
            return $fail('no_copy', 'Die Sicherungskopie ist unvollständig');
        }
        $target = $singleFile ? WP_PLUGIN_DIR . '/' . $sourceName : WP_PLUGIN_DIR . '/' . $slug;

        require_once ABSPATH . 'wp-admin/includes/plugin.php';
        $file = null;
        foreach (array_keys(get_plugins()) as $candidate) {
            $candidateSlug = dirname($candidate) === '.' ? basename($candidate, '.php') : dirname($candidate);
            if ($candidateSlug === $slug) {
                $file = $candidate;
                break;
            }
        }
        $wasActive = $file !== null && is_plugin_active($file);
        $current = $file !== null ? (string) (get_plugin_data(WP_PLUGIN_DIR . '/' . $file, false, false)['Version'] ?? '') : '';

        if (!Lock::acquire('rollback:' . $slug)) {
            return $fail('locked', 'Es läuft bereits ein anderer Vorgang.');
        }
        try {
            self::cleanupParked();
            // Aktuellen Stand beiseitelegen. Punkt-Name: WordPress ignoriert den Ordner. Zufallsname: von
            // außen nicht zu erraten, falls das Löschen danach scheitert (wird beim nächsten Mal abgeräumt).
            $parked = WP_PLUGIN_DIR . '/' . self::PARKED_PREFIX . bin2hex(random_bytes(16));
            if (file_exists($target) && !@rename($target, $parked)) {
                return $fail('move_failed', 'Aktueller Plugin-Ordner ließ sich nicht verschieben');
            }
            $ok = self::restoreFiles($dir, $meta, $singleFile ? WP_PLUGIN_DIR : $target, $singleFile ? $sourceName : null);
            if (!$ok) {
                if (file_exists($target)) {
                    is_dir($target) ? self::removeDir($target) : @unlink($target);
                }
                if (file_exists($parked)) {
                    @rename($parked, $target);
                }
                return $fail('copy_failed', 'Kopie ließ sich nicht zurückspielen, alter Stand wiederhergestellt');
            }
            if (file_exists($parked)) {
                is_dir($parked) ? self::removeDir($parked) : @unlink($parked);
            }
        } finally {
            Lock::release();
        }

        if (function_exists('opcache_reset')) {
            @opcache_reset();
        }
        wp_clean_plugins_cache();
        $reactivated = false;
        if ($wasActive && $file !== null && !is_plugin_active($file)) {
            $reactivated = !is_wp_error(activate_plugin($file, '', is_multisite() && is_plugin_active_for_network($file), true));
        }
        Log::add('rollback', 'ok', sprintf('%s: %s → %s zurückgespielt', $slug, $current, $copy['version']), ['copy' => $copy['id']]);
        return [
            'ok' => true,
            'slug' => $slug,
            'from_version' => $current,
            'to_version' => $copy['version'],
            'copy' => $copy['id'],
            'active' => $file !== null && is_plugin_active($file),
            'reactivated' => $reactivated,
        ];
    }

    /**
     * Schreibt die Dateien einer Kopie nach $to. Bei Einzeldatei-Plugins ist $to der Plugin-Ordner
     * und nur genau die Datei $onlyFile wird geschrieben.
     */
    private static function restoreFiles(string $copyDir, array $meta, string $to, ?string $onlyFile): bool
    {
        $archive = isset($meta['archive']) ? basename((string) $meta['archive']) : '';
        if ($archive !== '' && preg_match('/^kopie-[0-9a-f]{32}\.zip\z/', $archive) && @is_file($copyDir . '/' . $archive)) {
            return self::unzipTo($copyDir . '/' . $archive, $to, $onlyFile);
        }
        // Kopien im alten Format (lose Dateien), falls die Umstellung sie nicht erfasst hat
        $files = $copyDir . '/files';
        if (!@is_dir($files)) {
            return false;
        }
        if ($onlyFile !== null) {
            return @copy($files . '/' . $onlyFile, $to . '/' . $onlyFile);
        }
        return self::copyDir($files, $to) > 0;
    }

    /** @return array<int, array{id: string, version: string, created_at: int}> */
    public static function list(string $slug): array
    {
        $base = self::base();
        if ($base === null || !self::validSlug($slug)) {
            return [];
        }
        $dir = $base['path'] . '/' . $slug;
        $items = [];
        foreach ((array) @scandir($dir) as $entry) {
            if (!is_string($entry) || !preg_match('/^\d{8}-\d{6}_[A-Za-z0-9.-]{0,80}\z/', $entry) || !is_dir($dir . '/' . $entry)) {
                continue;
            }
            $meta = json_decode((string) @file_get_contents($dir . '/' . $entry . '/meta.json'), true);
            $items[] = [
                'id' => $entry,
                'version' => is_array($meta) ? (string) ($meta['version'] ?? '') : '',
                'created_at' => is_array($meta) ? (int) ($meta['created_at'] ?? 0) : 0,
            ];
        }
        usort($items, static function ($a, $b) {
            return strcmp($b['id'], $a['id']);
        });
        return $items;
    }

    private static function prune(string $slug): void
    {
        $base = self::base();
        if ($base === null) {
            return;
        }
        foreach (array_slice(self::list($slug), self::KEEP) as $old) {
            self::removeDir($base['path'] . '/' . $slug . '/' . $old['id']);
        }
    }

    /**
     * Übernimmt eine alte Ablage (lose Dateien, fester Ordnername) in die neue und löscht sie danach.
     * Nur Ordner, die isOwnDir() als eigene erkennt.
     */
    private static function migrate(string $from, string $to): void
    {
        $from = rtrim(wp_normalize_path($from), '/');
        if (!self::isOwnDir($from) || !@is_dir($from) || is_link($from)) {
            return;
        }
        $sameDir = $from === rtrim(wp_normalize_path($to), '/');
        foreach ((array) @scandir($from) as $slug) {
            if (!is_string($slug) || !self::validSlug($slug) || !@is_dir($from . '/' . $slug) || is_link($from . '/' . $slug)) {
                continue;
            }
            foreach ((array) @scandir($from . '/' . $slug) as $id) {
                $old = $from . '/' . $slug . '/' . $id;
                if (!is_string($id) || !preg_match('/^\d{8}-\d{6}_[A-Za-z0-9.-]{0,80}\z/', $id) || !@is_dir($old) || is_link($old)) {
                    continue;
                }
                $meta = json_decode((string) @file_get_contents($old . '/meta.json'), true);
                $meta = is_array($meta) ? $meta : [];
                $new = rtrim($to, '/') . '/' . $slug . '/' . $id;
                if (!self::mkdirProtected($new)) {
                    continue;
                }
                if (!isset($meta['archive']) && @is_dir($old . '/files')) {
                    $archive = 'kopie-' . bin2hex(random_bytes(16)) . '.zip';
                    $files = self::zipDir($old . '/files', $new . '/' . $archive);
                    if ($files === 0) {
                        continue;
                    }
                    $meta['archive'] = $archive;
                    $meta['files'] = $files;
                    if ($sameDir) {
                        self::removeDir($old . '/files');
                    }
                } elseif (!$sameDir && isset($meta['archive']) && @is_file($old . '/' . basename((string) $meta['archive']))) {
                    @copy($old . '/' . basename((string) $meta['archive']), $new . '/' . basename((string) $meta['archive']));
                }
                @file_put_contents($new . '/meta.json', wp_json_encode($meta));
            }
        }
        if (!$sameDir) {
            self::removeDir($from);
        } else {
            self::protect($from);
        }
    }

    /** Reste beiseitegelegter Plugin-Ordner (abgebrochener Rollback) entfernen. */
    public static function cleanupParked(): void
    {
        foreach ((array) @scandir(WP_PLUGIN_DIR) as $entry) {
            if (is_string($entry) && strpos($entry, self::PARKED_PREFIX) === 0 && preg_match('/^\.sww-alt-[A-Za-z0-9._-]+\z/', $entry)) {
                $path = WP_PLUGIN_DIR . '/' . $entry;
                is_dir($path) && !is_link($path) ? self::removeDir($path) : @unlink($path);
            }
        }
    }

    // ---------------------------------------------------------------------
    // Zip-Archive (ZipArchive, sonst PclZip aus WordPress)

    /** @return int Anzahl Dateien, 0 bei Fehler */
    private static function zipDir(string $from, string $zipFile): int
    {
        $from = rtrim($from, '/\\');
        $files = [];
        $iterator = new \RecursiveIteratorIterator(
            new \RecursiveDirectoryIterator($from, \FilesystemIterator::SKIP_DOTS),
            \RecursiveIteratorIterator::SELF_FIRST
        );
        foreach ($iterator as $item) {
            /** @var \SplFileInfo $item */
            if ($item->isLink() || !$item->isFile()) {
                continue;
            }
            $relative = str_replace('\\', '/', substr($item->getPathname(), strlen($from) + 1));
            $files[$relative] = $item->getPathname();
        }
        return $files ? self::zipFiles($files, $zipFile) : 0;
    }

    /**
     * @param array<string,string> $files Pfad im Archiv => Datei
     * @return int Anzahl Dateien, 0 bei Fehler
     */
    private static function zipFiles(array $files, string $zipFile): int
    {
        if (class_exists('ZipArchive')) {
            $zip = new \ZipArchive();
            if ($zip->open($zipFile, \ZipArchive::CREATE | \ZipArchive::EXCL) !== true) {
                return 0;
            }
            foreach ($files as $name => $path) {
                if (!$zip->addFile($path, $name)) {
                    $zip->close();
                    @unlink($zipFile);
                    return 0;
                }
            }
            if (!$zip->close()) {
                @unlink($zipFile);
                return 0;
            }
            return count($files);
        }
        require_once ABSPATH . 'wp-admin/includes/class-pclzip.php';
        $zip = new \PclZip($zipFile);
        $list = [];
        foreach ($files as $name => $path) {
            $list[] = [PCLZIP_ATT_FILE_NAME => $path, PCLZIP_ATT_FILE_NEW_FULL_NAME => $name];
        }
        $result = $zip->create($list);
        if ($result === 0 || !is_array($result) || count($result) !== count($files)) {
            @unlink($zipFile);
            return 0;
        }
        return count($files);
    }

    /** Sicherer Name eines Eintrags: relativ, ohne „..", ohne Laufwerk, ohne Backslash. */
    private static function safeEntry(string $name): bool
    {
        if ($name === '' || $name[0] === '/' || strpos($name, '\\') !== false || strpos($name, ':') !== false || strpos($name, "\0") !== false) {
            return false;
        }
        foreach (explode('/', rtrim($name, '/')) as $part) {
            if ($part === '' || $part === '.' || $part === '..') {
                return false;
            }
        }
        return true;
    }

    /**
     * Entpackt ein Archiv nach $to. Jeder Eintrag wird vorher geprüft (kein Schreiben außerhalb
     * von $to). $onlyFile: nur genau diese Datei (Einzeldatei-Plugins).
     */
    private static function unzipTo(string $zipFile, string $to, ?string $onlyFile): bool
    {
        if (class_exists('ZipArchive')) {
            $zip = new \ZipArchive();
            if ($zip->open($zipFile) !== true) {
                return false;
            }
            $names = [];
            for ($i = 0; $i < $zip->numFiles; $i++) {
                $name = (string) $zip->getNameIndex($i);
                if (!self::safeEntry($name) || ($onlyFile !== null && $name !== $onlyFile)) {
                    $zip->close();
                    return false;
                }
                $names[$i] = $name;
            }
            if ($names === [] || ($onlyFile === null && !self::mkdirPlain($to))) {
                $zip->close();
                return false;
            }
            foreach ($names as $i => $name) {
                $dest = $to . '/' . $name;
                if (substr($name, -1) === '/') {
                    if (!self::mkdirPlain(rtrim($dest, '/'))) {
                        $zip->close();
                        return false;
                    }
                    continue;
                }
                $in = $zip->getStream($name);
                $out = self::mkdirPlain(dirname($dest)) ? @fopen($dest, 'wb') : false;
                if (!$in || !$out) {
                    $zip->close();
                    return false;
                }
                $copied = stream_copy_to_stream($in, $out);
                fclose($in);
                fclose($out);
                if ($copied === false) {
                    $zip->close();
                    return false;
                }
            }
            $zip->close();
            return true;
        }

        require_once ABSPATH . 'wp-admin/includes/class-pclzip.php';
        $zip = new \PclZip($zipFile);
        $entries = $zip->listContent();
        if (!is_array($entries) || $entries === []) {
            return false;
        }
        foreach ($entries as $entry) {
            $name = (string) ($entry['filename'] ?? '');
            if (!self::safeEntry($name) || ($onlyFile !== null && $name !== $onlyFile)) {
                return false;
            }
        }
        if ($onlyFile === null && !self::mkdirPlain($to)) {
            return false;
        }
        $result = $zip->extract(PCLZIP_OPT_PATH, $to, PCLZIP_OPT_REPLACE_NEWER);
        return is_array($result) && count($result) === count($entries);
    }

    private static function mkdirPlain(string $dir): bool
    {
        return @is_dir($dir) || @mkdir($dir, 0755, true) || @is_dir($dir);
    }

    // ---------------------------------------------------------------------

    private static function copyDir(string $from, string $to): int
    {
        if (!wp_mkdir_p($to)) {
            return 0;
        }
        $count = 0;
        $iterator = new \RecursiveIteratorIterator(
            new \RecursiveDirectoryIterator($from, \FilesystemIterator::SKIP_DOTS),
            \RecursiveIteratorIterator::SELF_FIRST
        );
        foreach ($iterator as $item) {
            /** @var \SplFileInfo $item */
            if ($item->isLink()) {
                continue;
            }
            $relative = substr($item->getPathname(), strlen($from) + 1);
            $dest = $to . '/' . $relative;
            if ($item->isDir()) {
                if (!@is_dir($dest) && !@mkdir($dest, 0755, true)) {
                    return 0;
                }
            } elseif (!@copy($item->getPathname(), $dest)) {
                return 0;
            } else {
                $count++;
            }
        }
        return $count;
    }

    public static function removeDir(string $dir): void
    {
        if (!is_dir($dir) || is_link($dir)) {
            return;
        }
        $iterator = new \RecursiveIteratorIterator(
            new \RecursiveDirectoryIterator($dir, \FilesystemIterator::SKIP_DOTS),
            \RecursiveIteratorIterator::CHILD_FIRST
        );
        foreach ($iterator as $item) {
            $item->isDir() && !$item->isLink() ? @rmdir($item->getPathname()) : @unlink($item->getPathname());
        }
        @rmdir($dir);
    }
}
