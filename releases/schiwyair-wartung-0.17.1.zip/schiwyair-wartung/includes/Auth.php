<?php

namespace Schiwyair\Wartung;

use WP_Error;
use WP_REST_Request;

defined('ABSPATH') || exit;

/**
 * Prüfung der signierten Anfragen der Zentrale (siehe docs/signatur.md).
 */
final class Auth
{
    public const PREFIX = 'schiwyair-wartung-v1';
    public const MAX_CLOCK_SKEW = 300;
    public const NONCE_LIFETIME = 900;

    public const FAILURE_LIMIT = 10;
    public const FAILURE_WINDOW = 600;
    public const BLOCK_DURATION = 900;

    /** Gründe für Ablehnungen, nur für die Einstellungsseite. */
    public const REASONS = [
        'ip_not_allowed' => 'IP-Adresse nicht in der Freigabeliste',
        'blocked' => 'IP-Adresse wegen zu vieler Fehlversuche gesperrt',
        'missing_headers' => 'Signatur-Kopfzeilen fehlen oder sind ungültig',
        'bad_query' => 'Ungültige Query-Parameter',
        'clock_skew' => 'Zeitstempel weicht mehr als 5 Minuten ab (Uhrzeit prüfen)',
        'no_public_key' => 'Kein öffentlicher Schlüssel eingetragen',
        'bad_signature' => 'Signatur ungültig (falscher Schlüssel oder Anfrage für eine andere Adresse)',
        'replay' => 'Anfrage wurde wiederholt (Nonce bereits verwendet)',
        'storage_error' => 'Nonce konnte nicht gespeichert werden',
    ];

    /**
     * permission_callback für alle Routen des Plugins.
     *
     * @return true|WP_Error
     */
    public static function check(WP_REST_Request $request)
    {
        // WordPress ruft die Prüfung pro Anfrage mehrfach auf (z. B. für die
        // Allow-Kopfzeile). Die Nonce darf aber nur einmal verbraucht werden.
        // Das Request-Objekt wird mit gespeichert, damit PHP seine Kennung nicht an ein neues Objekt vergibt.
        static $results = [];
        $id = spl_object_hash($request);
        if (!isset($results[$id]) || $results[$id][0] !== $request) {
            $results[$id] = [$request, self::checkOnce($request)];
        }
        return $results[$id][1];
    }

    /** @return true|WP_Error */
    private static function checkOnce(WP_REST_Request $request)
    {
        $ip = self::clientIp();
        $reason = self::verify($request, $ip);

        if ($reason === null) {
            self::recordSuccess();
            return true;
        }

        // Gesperrte Absender verursachen keine weiteren Schreibzugriffe
        if (!self::isBlocked($ip)) {
            self::recordFailure($ip, $reason);
        }

        // Keine Information über den Grund nach außen.
        return new WP_Error('sww_unauthorized', 'Unauthorized', ['status' => 401]);
    }

    /**
     * @return string|null Grund der Ablehnung oder null, wenn die Anfrage gültig ist.
     */
    private static function verify(WP_REST_Request $request, string $ip): ?string
    {
        if (!self::ipAllowed($ip)) {
            return 'ip_not_allowed';
        }
        // Die Sperre nach Fehlversuchen gilt nicht für gültig signierte Anfragen. Sonst könnte ein
        // Angreifer mit zehn falschen Anfragen über dieselbe Adresse (Proxy, Cloudflare) die Zentrale
        // aussperren. Die Signatur selbst ist mit Ed25519 nicht zu erraten.

        $timestamp = (string) $request->get_header('x_sww_timestamp');
        $nonce = (string) $request->get_header('x_sww_nonce');
        $signatureB64 = (string) $request->get_header('x_sww_signature');

        if (!preg_match('/^[0-9]{1,12}\z/', $timestamp)
            || !preg_match('/^[A-Za-z0-9_-]{16,64}\z/', $nonce)
            || $signatureB64 === ''
        ) {
            return 'missing_headers';
        }
        $signature = base64_decode($signatureB64, true);
        if ($signature === false || strlen($signature) !== 64) {
            return 'missing_headers';
        }

        $query = self::canonicalQuery($request->get_query_params());
        if ($query === null) {
            return 'bad_query';
        }

        if (abs(time() - (int) $timestamp) > self::MAX_CLOCK_SKEW) {
            return 'clock_skew';
        }

        $publicKey = self::publicKeyBytes();
        if ($publicKey === null) {
            return 'no_public_key';
        }

        $message = self::canonicalString(
            $request->get_method(),
            self::signedHost(),
            $request->get_route(),
            $query,
            $timestamp,
            $nonce,
            (string) $request->get_body()
        );

        if (!self::verifySignature($signature, $message, $publicKey)) {
            return 'bad_signature';
        }

        return self::storeNonce($nonce);
    }

    /**
     * Zu signierende Zeichenkette. $query ist bereits kanonisch (siehe canonicalQuery).
     */
    public static function canonicalString(
        string $method,
        string $host,
        string $route,
        string $query,
        string $timestamp,
        string $nonce,
        string $body
    ): string {
        return implode("\n", [
            self::PREFIX,
            strtoupper($method),
            strtolower($host),
            $route,
            $query,
            $timestamp,
            $nonce,
            hash('sha256', $body),
        ]);
    }

    /**
     * Sortierte, nach RFC 3986 kodierte Query ohne rest_route.
     *
     * @return string|null null bei Listen, verschachtelten Werten oder ungültigen Schlüsseln
     */
    public static function canonicalQuery(array $params): ?string
    {
        unset($params['rest_route']);
        $parts = [];
        foreach ($params as $key => $value) {
            $key = (string) $key;
            if (!preg_match('/^[A-Za-z0-9_]{1,64}\z/', $key) || !is_scalar($value)) {
                return null;
            }
            $parts[$key] = rawurlencode($key) . '=' . rawurlencode((string) $value);
        }
        ksort($parts, SORT_STRING);
        return implode('&', $parts);
    }

    /** Host aus der eingetragenen Website-Adresse, mit Port falls angegeben. */
    public static function siteHost(): string
    {
        $parts = wp_parse_url(home_url());
        $host = isset($parts['host']) ? strtolower($parts['host']) : '';
        if (isset($parts['port'])) {
            $host .= ':' . (int) $parts['port'];
        }
        return $host;
    }

    /**
     * Host und, falls WordPress in einem Unterordner liegt, dessen Pfad (ab 0.16.0). So nimmt eine Kopie
     * im Unterordner derselben Domain (kunde.de/staging) keine Anfragen für die Live-Seite an.
     * Bei Seiten ohne Unterordner ist das genau siteHost(), also unverändert zu früheren Versionen.
     */
    public static function signedHost(): string
    {
        $path = (string) wp_parse_url(home_url(), PHP_URL_PATH);
        $path = rtrim($path, '/');
        return self::siteHost() . ($path !== '' && $path[0] === '/' ? $path : '');
    }

    /** Schlüssel aus der wp-config.php (SCHIWYAIR_WARTUNG_PUBLIC_KEY), Vorrang vor der Einstellung. */
    public static function configKey(): ?string
    {
        if (!defined('SCHIWYAIR_WARTUNG_PUBLIC_KEY')) {
            return null;
        }
        return (string) SCHIWYAIR_WARTUNG_PUBLIC_KEY;
    }

    /** @return string|null 32 Bytes oder null, wenn kein gültiger Schlüssel eingetragen ist. */
    public static function publicKeyBytes(): ?string
    {
        $config = self::configKey();
        if ($config !== null) {
            // Ungültiger Schlüssel in der wp-config: alles ablehnen, nicht auf die Einstellung ausweichen
            return self::decodePublicKey($config);
        }
        return self::decodePublicKey((string) get_option(Schema::OPTION_PUBLIC_KEY, ''));
    }

    public static function decodePublicKey(string $base64): ?string
    {
        $bytes = base64_decode(trim($base64), true);
        return ($bytes !== false && strlen($bytes) === 32) ? $bytes : null;
    }

    /** Kurzer Fingerabdruck zum Abgleich mit der Zentrale. */
    public static function fingerprint(string $publicKeyBytes): string
    {
        return implode(':', str_split(substr(hash('sha256', $publicKeyBytes), 0, 16), 4));
    }

    public static function verifySignature(string $signature, string $message, string $publicKey): bool
    {
        try {
            if (!function_exists('sodium_crypto_sign_verify_detached')) {
                // WordPress bringt sodium_compat mit (PHP ohne sodium-Erweiterung).
                require_once ABSPATH . WPINC . '/sodium_compat/autoload.php';
            }
            return sodium_crypto_sign_verify_detached($signature, $message, $publicKey);
        } catch (\Throwable $e) {
            return false;
        }
    }

    /** @return string|null null = neu gespeichert, sonst Grund der Ablehnung */
    private static function storeNonce(string $nonce): ?string
    {
        global $wpdb;
        $table = Schema::noncesTable();
        $now = time();

        $wpdb->query($wpdb->prepare("DELETE FROM `{$table}` WHERE created_at < %d", $now - self::NONCE_LIFETIME));

        // INSERT IGNORE ist atomar: 1 = neu, 0 = schon vorhanden.
        $result = $wpdb->query($wpdb->prepare(
            "INSERT IGNORE INTO `{$table}` (nonce, created_at) VALUES (%s, %d)",
            $nonce,
            $now
        ));
        if ($result === false) {
            return 'storage_error';
        }
        return $result === 1 ? null : 'replay';
    }

    // ---------------------------------------------------------------------
    // IP-Adresse, Freigabeliste, Fehlversuche

    public const IP_SOURCES = [
        'remote_addr' => ['REMOTE_ADDR', 'Direkte Verbindung (Standard)'],
        'cloudflare' => ['HTTP_CF_CONNECTING_IP', 'Cloudflare (CF-Connecting-IP)'],
        'x_real_ip' => ['HTTP_X_REAL_IP', 'Proxy (X-Real-IP)'],
        'x_forwarded_for' => ['HTTP_X_FORWARDED_FOR', 'Proxy (X-Forwarded-For, letzter Eintrag)'],
    ];

    /** Netze von Cloudflare (https://www.cloudflare.com/ips/, Stand 2026-11) */
    private const CLOUDFLARE_NETS = [
        '173.245.48.0/20', '103.21.244.0/22', '103.22.200.0/22', '103.31.4.0/22', '141.101.64.0/18',
        '108.162.192.0/18', '190.93.240.0/20', '188.114.96.0/20', '197.234.240.0/22', '198.41.128.0/17',
        '162.158.0.0/15', '104.16.0.0/13', '104.24.0.0/14', '172.64.0.0/13', '131.0.72.0/22',
        '2400:cb00::/32', '2606:4700::/32', '2803:f800::/32', '2405:b500::/32', '2405:8100::/32',
        '2a06:98c0::/29', '2c0f:f248::/32',
    ];

    /** Eigene Proxys des Hosters liegen im privaten Netz oder auf demselben Rechner. */
    private const PRIVATE_NETS = [
        '127.0.0.0/8', '10.0.0.0/8', '172.16.0.0/12', '192.168.0.0/16', '100.64.0.0/10',
        '::1/128', 'fc00::/7', 'fe80::/10',
    ];

    /**
     * Kommt die Verbindung von einem Proxy, dem die gewählte Kopfzeile vertraut werden darf?
     * Sonst könnte jeder, der den Server direkt erreicht, die Kopfzeile selbst setzen (Fund M4).
     */
    public static function trustedProxy(string $remote, string $source): bool
    {
        $nets = self::PRIVATE_NETS;
        if ($source === 'cloudflare') {
            $nets = array_merge($nets, self::CLOUDFLARE_NETS);
        }
        foreach ($nets as $net) {
            if (self::ipMatches($remote, $net)) {
                return true;
            }
        }
        return false;
    }

    public static function clientIp(): string
    {
        $remote = isset($_SERVER['REMOTE_ADDR']) ? (string) $_SERVER['REMOTE_ADDR'] : '';
        $source = (string) get_option(Schema::OPTION_CLIENT_IP_SOURCE, 'remote_addr');
        if (!isset(self::IP_SOURCES[$source]) || $source === 'remote_addr' || !self::trustedProxy(self::validIp($remote), $source)) {
            return self::validIp($remote);
        }
        $server_key = self::IP_SOURCES[$source][0];
        $value = isset($_SERVER[$server_key]) ? (string) $_SERVER[$server_key] : '';
        if ($source === 'x_forwarded_for') {
            // Den ersten Eintrag kann der Absender frei wählen. Der letzte stammt vom eigenen Proxy.
            $parts = explode(',', $value);
            $value = trim((string) end($parts));
        }
        $ip = self::validIp($value);
        return $ip !== '' ? $ip : self::validIp($remote);
    }

    private static function validIp(string $ip): string
    {
        $ip = trim($ip);
        return filter_var($ip, FILTER_VALIDATE_IP) !== false ? $ip : '';
    }

    /** @return string[] */
    public static function allowlist(): array
    {
        $raw = (string) get_option(Schema::OPTION_IP_ALLOWLIST, '');
        $lines = preg_split('/[\s,]+/', $raw, -1, PREG_SPLIT_NO_EMPTY);
        return is_array($lines) ? $lines : [];
    }

    public static function ipAllowed(string $ip): bool
    {
        $list = self::allowlist();
        if ($list === []) {
            return true;
        }
        foreach ($list as $entry) {
            if (self::ipMatches($ip, $entry)) {
                return true;
            }
        }
        return false;
    }

    /** Einzelne IP oder CIDR-Bereich, IPv4 und IPv6. */
    public static function ipMatches(string $ip, string $entry): bool
    {
        $ipBin = @inet_pton($ip);
        if ($ipBin === false) {
            return false;
        }
        $bits = null;
        if (strpos($entry, '/') !== false) {
            [$entry, $bits] = explode('/', $entry, 2);
            if (!ctype_digit($bits)) {
                return false;
            }
            $bits = (int) $bits;
        }
        $netBin = @inet_pton($entry);
        if ($netBin === false || strlen($netBin) !== strlen($ipBin)) {
            return false;
        }
        $maxBits = strlen($ipBin) * 8;
        if ($bits === null) {
            $bits = $maxBits;
        }
        if ($bits < 0 || $bits > $maxBits) {
            return false;
        }
        $bytes = intdiv($bits, 8);
        if (substr($ipBin, 0, $bytes) !== substr($netBin, 0, $bytes)) {
            return false;
        }
        $rest = $bits % 8;
        if ($rest === 0) {
            return true;
        }
        $mask = (0xFF << (8 - $rest)) & 0xFF;
        return (ord($ipBin[$bytes]) & $mask) === (ord($netBin[$bytes]) & $mask);
    }

    public static function isValidAllowlistEntry(string $entry): bool
    {
        $address = strpos($entry, '/') !== false ? explode('/', $entry, 2)[0] : $entry;
        if (filter_var($address, FILTER_VALIDATE_IP) === false) {
            return false;
        }
        return self::ipMatches($address, $entry);
    }

    /** IPv6-Adressen zählen je /64-Netz, sonst ließe sich die Sperre mit wechselnden Adressen umgehen. */
    private static function throttleKey(string $ip): string
    {
        if (strpos($ip, ':') === false) {
            return $ip;
        }
        $bin = @inet_pton($ip);
        return $bin === false ? $ip : inet_ntop(substr($bin, 0, 8) . str_repeat("\0", 8)) . '/64';
    }

    private static function isBlocked(string $ip): bool
    {
        global $wpdb;
        $table = Schema::throttleTable();
        $blockedUntil = $wpdb->get_var($wpdb->prepare("SELECT blocked_until FROM `{$table}` WHERE ip = %s", self::throttleKey($ip)));
        return $blockedUntil !== null && (int) $blockedUntil > time();
    }

    private static function recordFailure(string $ip, string $reason): void
    {
        global $wpdb;
        $table = Schema::throttleTable();
        $now = time();
        $key = self::throttleKey($ip);

        // Zuweisungen werden von links nach rechts ausgewertet: failures nutzt das
        // alte window_start, blocked_until das neue failures.
        $wpdb->query($wpdb->prepare(
            "INSERT INTO `{$table}` (ip, failures, window_start, blocked_until) VALUES (%s, 1, %d, 0)
             ON DUPLICATE KEY UPDATE
                failures = IF(window_start < %d, 1, failures + 1),
                window_start = IF(window_start < %d, %d, window_start),
                blocked_until = IF(failures >= %d, %d, blocked_until)",
            $key,
            $now,
            $now - self::FAILURE_WINDOW,
            $now - self::FAILURE_WINDOW,
            $now,
            self::FAILURE_LIMIT,
            $now + self::BLOCK_DURATION
        ));

        // Gelegentlich alte Einträge entfernen.
        if (wp_rand(1, 20) === 1) {
            $wpdb->query($wpdb->prepare(
                "DELETE FROM `{$table}` WHERE window_start < %d AND blocked_until < %d",
                $now - 3600,
                $now
            ));
        }

        // Für die Einstellungsseite, höchstens einmal je Minute schreiben
        $last = get_option(Schema::OPTION_LAST_FAILURE, []);
        if (!is_array($last) || (int) ($last['time'] ?? 0) < $now - 60) {
            Lockdown::internalUpdate(Schema::OPTION_LAST_FAILURE, [
                'time' => $now,
                'reason' => $reason,
                'ip' => $ip,
            ]);
        }
    }

    private static function recordSuccess(): void
    {
        $last = (int) get_option(Schema::OPTION_LAST_SUCCESS, 0);
        if (time() - $last >= 60) {
            Lockdown::internalUpdate(Schema::OPTION_LAST_SUCCESS, time());
        }
    }

    /** Hebt alle Sperren auf (Button auf der Einstellungsseite). */
    public static function resetThrottle(): void
    {
        global $wpdb;
        $wpdb->query('DELETE FROM `' . Schema::throttleTable() . '`');
    }
}
