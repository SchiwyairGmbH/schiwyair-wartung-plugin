<?php

namespace Schiwyair\Wartung;

defined('ABSPATH') || exit;

/**
 * Dateien der Sicherung: erst auflisten (in Etappen), dann einpacken (in Etappen, auch mitten in großen Dateien).
 *
 * Was gesichert wird, legt das Plugin fest, nicht die Zentrale (sie kann nur weitere Ausnahmen angeben):
 * - wp-content komplett, außer Cache, Ordnern anderer Backup-Plugins, eigenen Arbeitsordnern, node_modules, .git
 * - die Einzeldateien im Hauptordner von WordPress (wp-config.php, .htaccess, .user.ini, robots.txt …)
 * - WordPress selbst (wp-admin, wp-includes), damit sich die Seite allein aus der Sicherung wieder aufbauen lässt.
 *   Andere Unterordner des Hauptordners (fremde Anwendungen, Unterseiten) nicht.
 * - wp-config.php eine Ebene höher, wenn sie dort liegt (wie WordPress selbst sucht)
 * Namen im Archiv: wp-content/…, wordpress-root/… (auch wordpress-root/wp-admin/…), oberhalb/wp-config.php
 */
final class SnapshotFiles
{
    public const MAX_FILE = 2147483647;
    private const MAX_LOG = 10485760;
    private const MAX_ROOT_FILE = 52428800;
    private const CHUNK = 1048576;
    /** Ordner im Hauptordner, die mitgesichert werden (WordPress selbst) */
    private const CORE_DIRS = ['wp-admin', 'wp-includes'];
    /** Kennzeichen im Stapel für Ordner relativ zum Hauptordner statt zu wp-content */
    private const ROOT_MARK = '@root/';

    /** Ordner direkt in wp-content, die nie gesichert werden (Cache, andere Backup-Plugins, Updates) */
    private const SKIP_TOP = [
        'cache', 'et-cache', 'wpo-cache', 'litespeed', 'upgrade', 'upgrade-temp-backup',
        'updraft', 'ai1wm-backups', 'backups-dup-lite', 'backups-dup-pro', 'wpvividbackups', 'backupwordpress',
    ];

    /** Dateiendungen, die schon komprimiert sind (nur verpacken) */
    private const PACKED = ['jpg', 'jpeg', 'png', 'gif', 'webp', 'avif', 'heic', 'mp4', 'm4v', 'mov', 'webm', 'mp3', 'm4a', 'ogg', 'zip', 'gz', 'tgz', 'bz2', 'xz', 'rar', '7z', 'woff', 'woff2', 'pdf', 'wpress'];

    public static function initialState(array $excludes): array
    {
        return [
            'phase' => 'scan',
            'stack' => [''],
            'root_done' => false,
            'excludes' => $excludes,
            'listed' => 0,
            'listed_bytes' => 0,
            'offset' => 0,
            'current' => null,
            'packed' => 0,
            'packed_bytes' => 0,
            'skipped' => ['symlinks' => 0, 'unreadable' => 0, 'too_large' => [], 'excluded' => [], 'vanished' => 0, 'changed' => 0],
        ];
    }

    /** Prüft eine Ausnahme der Zentrale: relativer Pfad in wp-content, kein „..“ */
    public static function validExclude($path): bool
    {
        return is_string($path) && $path !== '' && strlen($path) <= 200
            && (bool) preg_match('#^[A-Za-z0-9._ -]+(/[A-Za-z0-9._ -]+)*\z#', $path)
            && strpos($path, '..') === false;
    }

    public static function contentDir(): string
    {
        return rtrim(wp_normalize_path(WP_CONTENT_DIR), '/');
    }

    /**
     * Auflisten. Schreibt Zeilen „c<TAB>pfad“ (wp-content), „r<TAB>name“ (Hauptordner), „o<TAB>wp-config.php“ (oberhalb).
     *
     * @return bool true, wenn fertig
     */
    public static function scan(array &$files, string $listFile, float $deadline): bool
    {
        $out = @fopen($listFile, 'ab');
        if ($out === false) {
            throw new \RuntimeException('Dateiliste ließ sich nicht schreiben');
        }
        try {
            if (!$files['root_done']) {
                self::scanRoot($files, $out);
                $files['root_done'] = true;
            }
            $content = self::contentDir();
            $root = rtrim(wp_normalize_path(ABSPATH), '/');
            while ($files['stack'] && microtime(true) < $deadline) {
                $rel = array_pop($files['stack']);
                if (strpos($rel, self::ROOT_MARK) === 0) {
                    self::scanCoreDir($files, $out, $root, substr($rel, strlen(self::ROOT_MARK)));
                    continue;
                }
                $dir = $rel === '' ? $content : $content . '/' . $rel;
                $entries = @scandir($dir);
                if ($entries === false) {
                    $files['skipped']['unreadable']++;
                    continue;
                }
                foreach ($entries as $entry) {
                    if ($entry === '.' || $entry === '..') {
                        continue;
                    }
                    $childRel = $rel === '' ? $entry : $rel . '/' . $entry;
                    $path = $dir . '/' . $entry;
                    if (is_link($path)) {
                        $files['skipped']['symlinks']++;
                        continue;
                    }
                    if (is_dir($path)) {
                        if (self::skipDir($childRel, $entry, $files['excludes'])) {
                            if (count($files['skipped']['excluded']) < 50) {
                                $files['skipped']['excluded'][] = 'wp-content/' . $childRel;
                            }
                            continue;
                        }
                        $files['stack'][] = $childRel;
                        continue;
                    }
                    if (!is_file($path)) {
                        continue;
                    }
                    if (self::excludedByUser($childRel, $files['excludes'])) {
                        continue;
                    }
                    $size = @filesize($path);
                    if ($size === false || !is_readable($path)) {
                        $files['skipped']['unreadable']++;
                        continue;
                    }
                    if ($size > self::MAX_FILE || ($size > self::MAX_LOG && preg_match('/\.log\z/i', $entry))) {
                        self::tooLarge($files, 'wp-content/' . $childRel, (int) $size);
                        continue;
                    }
                    self::listLine($out, $files, 'c', $childRel, (int) $size);
                }
            }
        } finally {
            fclose($out);
        }
        return !$files['stack'];
    }

    /** Ein Ordner von WordPress selbst (wp-admin, wp-includes und darunter) */
    private static function scanCoreDir(array &$files, $out, string $root, string $rel): void
    {
        $dir = $root . '/' . $rel;
        $entries = @scandir($dir);
        if ($entries === false) {
            $files['skipped']['unreadable']++;
            return;
        }
        foreach ($entries as $entry) {
            if ($entry === '.' || $entry === '..') {
                continue;
            }
            $childRel = $rel . '/' . $entry;
            $path = $dir . '/' . $entry;
            if (is_link($path)) {
                $files['skipped']['symlinks']++;
                continue;
            }
            if (is_dir($path)) {
                if ($entry !== 'node_modules' && $entry !== '.git' && $entry !== '.svn') {
                    $files['stack'][] = self::ROOT_MARK . $childRel;
                }
                continue;
            }
            if (!is_file($path)) {
                continue;
            }
            $size = @filesize($path);
            if ($size === false || !is_readable($path)) {
                $files['skipped']['unreadable']++;
                continue;
            }
            if ($size > self::MAX_ROOT_FILE) {
                self::tooLarge($files, 'wordpress-root/' . $childRel, (int) $size);
                continue;
            }
            self::listLine($out, $files, 'r', $childRel, (int) $size);
        }
    }

    private static function scanRoot(array &$files, $out): void
    {
        $root = rtrim(wp_normalize_path(ABSPATH), '/');
        foreach (self::CORE_DIRS as $core) {
            if (is_dir($root . '/' . $core) && !is_link($root . '/' . $core)) {
                $files['stack'][] = self::ROOT_MARK . $core;
            }
        }
        foreach ((array) @scandir($root) as $entry) {
            if (!is_string($entry) || $entry === '.' || $entry === '..') {
                continue;
            }
            $path = $root . '/' . $entry;
            if (is_link($path) || !is_file($path)) {
                continue;
            }
            $size = @filesize($path);
            if ($size === false || !is_readable($path)) {
                $files['skipped']['unreadable']++;
                continue;
            }
            if ($size > self::MAX_ROOT_FILE) {
                self::tooLarge($files, 'wordpress-root/' . $entry, (int) $size);
                continue;
            }
            self::listLine($out, $files, 'r', $entry, (int) $size);
        }
        // wp-config.php eine Ebene höher (wie wp-load.php: nur, wenn dort keine eigene WordPress-Installation liegt)
        if (!is_file($root . '/wp-config.php')) {
            $parent = dirname($root);
            if (is_file($parent . '/wp-config.php') && !is_file($parent . '/wp-settings.php') && is_readable($parent . '/wp-config.php')) {
                self::listLine($out, $files, 'o', 'wp-config.php', (int) filesize($parent . '/wp-config.php'));
            }
        }
    }

    private static function listLine($out, array &$files, string $kind, string $rel, int $size): void
    {
        if (strpos($rel, "\n") !== false || strpos($rel, "\t") !== false) {
            $files['skipped']['unreadable']++;
            return;
        }
        fwrite($out, $kind . "\t" . $rel . "\n");
        $files['listed']++;
        $files['listed_bytes'] += $size;
    }

    private static function tooLarge(array &$files, string $name, int $size): void
    {
        if (count($files['skipped']['too_large']) < 50) {
            $files['skipped']['too_large'][] = ['name' => $name, 'size' => $size];
        }
    }

    private static function skipDir(string $rel, string $name, array $excludes): bool
    {
        if ($name === 'node_modules' || $name === '.git' || $name === '.svn') {
            return true;
        }
        if (strpos($rel, '/') === false) {
            if (in_array(strtolower($name), self::SKIP_TOP, true) || preg_match('/^sww-(kopien|sicherung)-[0-9a-f]+\z/', $name)) {
                return true;
            }
        }
        if (preg_match('#^plugins/\.sww-alt-#', $rel) || preg_match('#^uploads/backwpup-#', $rel)) {
            return true;
        }
        return self::excludedByUser($rel, $excludes);
    }

    private static function excludedByUser(string $rel, array $excludes): bool
    {
        foreach ($excludes as $exclude) {
            if ($rel === $exclude || strpos($rel, $exclude . '/') === 0) {
                return true;
            }
        }
        return false;
    }

    /** Aufgelösten Pfad und Archivnamen zu einer Listenzeile */
    private static function resolve(string $kind, string $rel): ?array
    {
        if ($kind === 'c') {
            return ['path' => self::contentDir() . '/' . $rel, 'name' => 'wp-content/' . $rel];
        }
        $root = rtrim(wp_normalize_path(ABSPATH), '/');
        if ($kind === 'r') {
            return ['path' => $root . '/' . $rel, 'name' => 'wordpress-root/' . $rel];
        }
        if ($kind === 'o') {
            return ['path' => dirname($root) . '/wp-config.php', 'name' => 'oberhalb/wp-config.php'];
        }
        return null;
    }

    /**
     * Einpacken bis zur Frist.
     *
     * @return bool true, wenn alle Dateien im Archiv sind
     */
    public static function pack(array &$files, string $listFile, SnapshotWriter $writer, float $deadline): bool
    {
        $list = @fopen($listFile, 'rb');
        if ($list === false) {
            throw new \RuntimeException('Dateiliste ließ sich nicht lesen');
        }
        try {
            if (fseek($list, (int) $files['offset']) !== 0) {
                throw new \RuntimeException('Dateiliste beschädigt');
            }
            while (microtime(true) < $deadline && !$writer->blocked()) {
                if ($files['current'] !== null) {
                    self::continueFile($files, $writer, $deadline);
                    continue;
                }
                $line = fgets($list);
                if ($line === false) {
                    return true;
                }
                $files['offset'] = ftell($list);
                $parts = explode("\t", rtrim($line, "\n"), 2);
                if (count($parts) !== 2) {
                    continue;
                }
                $target = self::resolve($parts[0], $parts[1]);
                if ($target === null || is_link($target['path']) || !is_file($target['path'])) {
                    $files['skipped']['vanished']++;
                    continue;
                }
                clearstatcache(true, $target['path']);
                $size = @filesize($target['path']);
                if ($size === false || $size > self::MAX_FILE) {
                    $files['skipped']['vanished']++;
                    continue;
                }
                $mtime = (int) @filemtime($target['path']);
                $perms = @fileperms($target['path']);
                $writer->setLevel(self::isPacked($target['name']) ? 1 : 6);
                $writer->tarHeader($target['name'], (int) $size, $mtime, $perms === false ? 0644 : ($perms & 0777));
                $files['current'] = ['name' => $target['name'], 'path' => $target['path'], 'size' => (int) $size, 'done' => 0];
                if ((int) $size === 0) {
                    self::endFile($files);
                }
            }
            return false;
        } finally {
            fclose($list);
        }
    }

    private static function continueFile(array &$files, SnapshotWriter $writer, float $deadline): void
    {
        $current = &$files['current'];
        $writer->setLevel(self::isPacked($current['name']) ? 1 : 6);
        $handle = @fopen($current['path'], 'rb');
        if ($handle !== false && $current['done'] > 0 && fseek($handle, $current['done']) !== 0) {
            fclose($handle);
            $handle = false;
        }
        while ($current['done'] < $current['size']) {
            $want = (int) min(self::CHUNK, $current['size'] - $current['done']);
            $data = $handle !== false ? fread($handle, $want) : false;
            if ($data === false || $data === '') {
                // Datei wurde kürzer oder ist weg: mit Nullen auffüllen, damit das Archiv stimmt
                $data = str_repeat("\0", $want);
                $files['skipped']['changed']++;
                if ($handle !== false) {
                    fclose($handle);
                    $handle = false;
                }
            }
            $writer->write($data);
            $current['done'] += strlen($data);
            if (microtime(true) > $deadline || $writer->blocked()) {
                break;
            }
        }
        if ($handle !== false) {
            fclose($handle);
        }
        if ($current['done'] >= $current['size']) {
            $writer->write(SnapshotWriter::padding($current['size']));
            unset($current);
            self::endFile($files);
        }
    }

    private static function endFile(array &$files): void
    {
        $files['packed']++;
        $files['packed_bytes'] += $files['current']['size'];
        $files['current'] = null;
    }

    private static function isPacked(string $name): bool
    {
        $ext = strtolower((string) pathinfo($name, PATHINFO_EXTENSION));
        return in_array($ext, self::PACKED, true);
    }
}
