<?php

namespace Schiwyair\Wartung;

defined('ABSPATH') || exit;

/**
 * UpdraftPlus (kostenlose Version). Fundstellen: docs/fundstellen.md
 */
final class StatusUpdraftPlus
{
    private const PLUGIN_FILE = 'updraftplus/updraftplus.php';

    public static function collect(): array
    {
        global $updraftplus;
        $active = class_exists('UpdraftPlus') && class_exists('UpdraftPlus_Options') && is_object($updraftplus);

        if (!$active) {
            $installed = array_key_exists(self::PLUGIN_FILE, get_plugins());
            return Status::thirdParty(
                self::PLUGIN_FILE,
                false,
                null,
                null,
                $installed ? 'UpdraftPlus ist installiert, aber nicht aktiv' : 'UpdraftPlus ist nicht installiert'
            );
        }

        $version = isset($updraftplus->version) ? (string) $updraftplus->version : null;

        return Status::thirdParty(self::PLUGIN_FILE, true, $version, [
            'last_backup' => Status::section([self::class, 'lastBackup']),
            'remote_storage' => Status::section([self::class, 'remoteStorage']),
            'running' => Status::section([self::class, 'runningJobs']),
            'settings' => Status::section([self::class, 'settings']),
        ], null);
    }

    public static function lastBackup(): ?array
    {
        global $updraftplus;
        $last = \UpdraftPlus_Options::get_updraft_option('updraft_last_backup', null);
        if (!is_array($last) || empty($last['backup_time'])) {
            return null;
        }

        $errors = [];
        $warnings = 0;
        foreach ((array) ($last['errors'] ?? []) as $error) {
            $level = is_array($error) && isset($error['level']) ? $error['level'] : 'error';
            $message = is_array($error) && isset($error['message']) ? (string) $error['message'] : (is_string($error) ? $error : '');
            if ($level === 'warning') {
                $warnings++;
                continue;
            }
            $errors[] = Redact::text($message, 300);
        }

        $entities = method_exists($updraftplus, 'get_backupable_file_entities')
            ? array_keys((array) $updraftplus->get_backupable_file_entities(true, false))
            : [];
        $entities = array_merge($entities, ['plugins', 'themes', 'uploads', 'others', 'mu-plugins', 'wpcore', 'more']);

        $parts = [];
        foreach (array_keys((array) ($last['backup_array'] ?? [])) as $key) {
            $key = (string) $key;
            if (preg_match('/^db\d*$/', $key) || in_array($key, $entities, true)) {
                $parts[] = $key;
            }
        }

        return [
            'time' => (int) $last['backup_time'],
            'success' => !empty($last['success']),
            'parts' => array_values(array_unique($parts)),
            'includes_database' => (bool) preg_grep('/^db\d*$/', $parts),
            'includes_files' => (bool) array_diff($parts, preg_grep('/^db\d*$/', $parts)),
            'error_count' => count($errors),
            'warning_count' => $warnings,
            'errors' => array_slice($errors, 0, 5),
        ];
    }

    public static function remoteStorage(): array
    {
        global $updraftplus;
        $services = method_exists($updraftplus, 'get_canonical_service_list')
            ? (array) $updraftplus->get_canonical_service_list()
            : [];
        $services = array_values(array_filter(array_map('strval', $services)));

        return [
            'configured' => $services !== [],
            'services' => $services,
            'ftp_folder' => in_array('ftp', $services, true) ? self::ftpFolder() : null,
            'note' => 'Zeigt nur, ob ein externer Speicher gewählt ist, nicht ob die Zugangsdaten gültig sind',
        ];
    }

    /**
     * Zielordner auf dem FTP-Server (ab 0.17.0, für die Zuordnung der eigenen Sicherung zum Kundenordner).
     * Nur der Ordnername, nie Server, Benutzer oder Passwort.
     * Fundstelle: updraft_ftp = {version, settings: {<instanz>: {host, user, pass, path, passive}}}
     * (methods/ftp.php, methods/backup-module.php get_options(), UpdraftPlus 1.26.8).
     */
    public static function ftpFolder(): ?string
    {
        $options = \UpdraftPlus_Options::get_updraft_option('updraft_ftp');
        if (!is_array($options)) {
            return null;
        }
        $settings = isset($options['settings']) && is_array($options['settings']) ? reset($options['settings']) : $options;
        $path = is_array($settings) && isset($settings['path']) && is_string($settings['path']) ? $settings['path'] : '';
        $path = trim(str_replace('\\', '/', $path), '/ ');
        if ($path === '' || strlen($path) > 200 || preg_match('/[\x00-\x1f]/', $path)) {
            return null;
        }
        return $path;
    }

    /** Zeitplan und Aufbewahrung (nur lesen). Fundstellen: docs/fundstellen.md */
    public static function settings(): array
    {
        $retain = \UpdraftPlus_Options::get_updraft_option('updraft_retain', 2);
        $retain = is_numeric($retain) ? (int) $retain : 1;
        $retainDb = \UpdraftPlus_Options::get_updraft_option('updraft_retain_db', $retain);
        $retainDb = is_numeric($retainDb) ? (int) $retainDb : 1;
        $files = \UpdraftPlus_Options::get_updraft_option('updraft_interval', 'manual');
        $db = \UpdraftPlus_Options::get_updraft_option('updraft_interval_database', $files);

        return [
            'retain_files' => $retain,
            'retain_db' => $retainDb,
            'interval_files' => is_string($files) ? $files : 'manual',
            'interval_db' => is_string($db) ? $db : 'manual',
        ];
    }

    public static function runningJobs(): array
    {
        global $updraftplus;
        $crons = function_exists('_get_cron_array') ? (array) _get_cron_array() : [];
        $jobs = [];

        foreach ($crons as $time => $hooks) {
            if (!is_array($hooks) || !isset($hooks['updraft_backup_resume'])) {
                continue;
            }
            foreach ((array) $hooks['updraft_backup_resume'] as $event) {
                if (!isset($event['args'][1])) {
                    continue;
                }
                $jobId = (string) $event['args'][1];
                $jobdata = method_exists($updraftplus, 'jobdata_getarray') ? (array) $updraftplus->jobdata_getarray($jobId) : [];
                $jobs[] = [
                    'job_id' => $jobId,
                    'started_at' => isset($jobdata['backup_time']) ? (int) $jobdata['backup_time'] : null,
                    'status' => isset($jobdata['jobstatus']) ? (string) $jobdata['jobstatus'] : null,
                    'resumption' => (int) $event['args'][0],
                    'next_resumption_at' => (int) $time,
                ];
            }
        }

        return [
            'running' => $jobs !== [],
            'jobs' => $jobs,
        ];
    }
}
