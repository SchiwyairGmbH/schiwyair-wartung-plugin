<?php

namespace Schiwyair\Wartung;

defined('ABSPATH') || exit;

/**
 * Testversand von Formularen, ohne dass der Kunde eine Mail bekommt.
 *
 * Ablauf: Die Zentrale fordert per signierter Anfrage ein Test-Token an (10 Minuten gültig, höchstens
 * 10 umgeleitete Mails, die Zentrale beendet den Test danach mit /formtest/stop).
 * Ihr Browser sendet das Formular mit dem Cookie sww_formtest=<Token>. Nur in dieser Anfrage
 * leitet das Plugin jede Mail von WordPress (wp_mail) an die Testadresse um, entfernt Cc/Bcc
 * und setzt [WARTUNGSTEST] vor den Betreff. Andere Besucher sind nicht betroffen.
 *
 * Elementor Pro (ab 4.0.3): In der Testanfrage laufen nur die Aktionen „E-Mail", „E-Mail 2" und
 * „Weiterleitung". Speichern der Einsendung, Webhooks, Newsletter- und CRM-Anbindungen entfallen,
 * damit der Kunde keinen Testeintrag sieht und nichts nach außen geht. Fundstelle: docs/fundstellen.md
 */
final class FormTest
{
    public const OPTION = 'schiwyair_wartung_formtest';
    public const COOKIE = 'sww_formtest';
    private const LIFETIME = 600;
    /**
     * Höchstens so viele Mails leitet ein Token um (Fund N6). Danach wirkt es nicht mehr, auch wenn es
     * noch gilt: Wer ein Token mitliest, kann so nicht minutenlang echte Mails der Seite abfangen.
     */
    private const MAX_REDIRECTS = 10;
    /** Aktionen von Elementor Pro, die beim Test laufen dürfen (Namen aus get_name() der Aktionen) */
    private const ELEMENTOR_SAFE_ACTIONS = ['email', 'email2', 'redirect'];
    /** Ab dieser Version gibt es den Filter elementor_pro/forms/submit_actions */
    private const ELEMENTOR_MIN_VERSION = '4.0.3';

    /** Früh beim Laden des Plugins: Cookie prüfen und nur dann die Umleitung aktivieren. */
    public static function maybeActivate(): void
    {
        if (empty($_COOKIE[self::COOKIE]) || !is_string($_COOKIE[self::COOKIE])) {
            return;
        }
        $state = get_option(self::OPTION);
        $token = (string) $_COOKIE[self::COOKIE];
        if (!is_array($state) || empty($state['hash']) || (int) ($state['expires'] ?? 0) < time()
            || !hash_equals((string) $state['hash'], hash('sha256', $token))
        ) {
            return;
        }
        $redirected = count(array_filter((array) ($state['events'] ?? []), static function ($e) {
            return is_array($e) && ($e['event'] ?? '') === 'redirected';
        }));
        if ($redirected >= self::MAX_REDIRECTS) {
            return;
        }
        $redirect = (string) $state['redirect_to'];
        add_filter('wp_mail', static function ($args) use ($redirect) {
            return self::rewrite($args, $redirect);
        }, PHP_INT_MAX);
        // Zweite Sicherung direkt vor dem Versand: Manche SMTP-Plugins fügen erst hier Empfänger hinzu
        // (etwa „Kopie aller Mails an …"). Danach steht nur noch die Testadresse drin.
        add_action('phpmailer_init', static function ($phpmailer) use ($redirect) {
            if (is_object($phpmailer) && method_exists($phpmailer, 'clearAllRecipients')) {
                $phpmailer->clearAllRecipients();
                $phpmailer->addAddress($redirect);
            }
        }, PHP_INT_MAX);
        add_filter('elementor_pro/forms/submit_actions', static function ($actions) {
            $actions = is_array($actions) ? $actions : [];
            $keep = array_values(array_intersect($actions, self::ELEMENTOR_SAFE_ACTIONS));
            $dropped = array_values(array_diff($actions, self::ELEMENTOR_SAFE_ACTIONS));
            if ($dropped !== []) {
                self::record('actions_skipped', '', null, 0, implode(', ', $dropped));
            }
            return $keep;
        }, PHP_INT_MAX);
        add_action('wp_mail_succeeded', static function ($data) {
            self::record('sent', is_array($data) ? (string) ($data['subject'] ?? '') : '', null);
        });
        add_action('wp_mail_failed', static function ($error) {
            self::record('failed', '', is_wp_error($error) ? Redact::text($error->get_error_message(), 200) : 'Fehler');
        });
    }

    public static function rewrite($args, string $redirect)
    {
        if (!is_array($args)) {
            return $args;
        }
        $original = is_array($args['to'] ?? null) ? count($args['to']) : count(array_filter(explode(',', (string) ($args['to'] ?? ''))));
        $args['to'] = $redirect;
        $subject = (string) ($args['subject'] ?? '');
        if (strpos($subject, '[WARTUNGSTEST]') !== 0) {
            $args['subject'] = '[WARTUNGSTEST] ' . $subject;
        }
        // To, Cc und Bcc aus den Kopfzeilen entfernen, damit keine Kopie an den Kunden geht
        $headers = $args['headers'] ?? [];
        $list = is_array($headers) ? $headers : preg_split("/\r\n|\n|\r/", (string) $headers);
        $args['headers'] = array_values(array_filter((array) $list, static function ($h) {
            return !preg_match('/^\s*(to|cc|bcc)\s*:/i', (string) $h);
        }));
        self::record('redirected', $subject, null, $original);
        return $args;
    }

    private static function record(string $event, string $subject, ?string $error, int $originalRecipients = 0, string $detail = ''): void
    {
        $state = get_option(self::OPTION);
        if (!is_array($state)) {
            return;
        }
        $state['events'] = array_slice(array_merge((array) ($state['events'] ?? []), [[
            'time' => time(),
            'event' => $event,
            'subject' => Redact::text($subject, 120),
            'original_recipients' => $originalRecipients,
            'error' => $error,
            'detail' => $detail !== '' ? Redact::text($detail, 200) : null,
        ]]), -20);
        Lockdown::internalUpdate(self::OPTION, $state, false);
    }

    /** Neues Token für die Testadresse. Nur ein Test gleichzeitig. */
    public static function start(string $redirectTo): array
    {
        $token = bin2hex(random_bytes(24));
        Lockdown::internalUpdate(self::OPTION, [
            'hash' => hash('sha256', $token),
            'redirect_to' => $redirectTo,
            'expires' => time() + self::LIFETIME,
            'events' => [],
        ], false);
        Log::add('formtest', 'info', 'Formulartest gestartet, Mails gehen an die Testadresse');
        return ['token' => $token, 'cookie' => self::COOKIE, 'expires' => time() + self::LIFETIME, 'supports' => self::supports()];
    }

    /**
     * Welche Formulare sich gefahrlos testen lassen. Die Zentrale schickt andere nicht ab.
     * elementor: Elementor Pro fehlt oder ist neu genug für den Filter der Aktionen.
     * cf7: Flamingo (speichert jede Einsendung von Contact Form 7) ist nicht aktiv.
     */
    public static function supports(): array
    {
        return [
            'elementor' => !defined('ELEMENTOR_PRO_VERSION') || version_compare((string) ELEMENTOR_PRO_VERSION, self::ELEMENTOR_MIN_VERSION, '>='),
            'elementor_version' => defined('ELEMENTOR_PRO_VERSION') ? (string) ELEMENTOR_PRO_VERSION : null,
            'cf7' => !defined('FLAMINGO_VERSION'),
        ];
    }

    public static function status(): array
    {
        $state = get_option(self::OPTION);
        if (!is_array($state)) {
            return ['active' => false, 'events' => []];
        }
        return [
            'active' => (int) ($state['expires'] ?? 0) >= time(),
            'redirect_to' => (string) ($state['redirect_to'] ?? ''),
            'events' => (array) ($state['events'] ?? []),
        ];
    }

    public static function stop(): array
    {
        $status = self::status();
        delete_option(self::OPTION);
        $sent = count(array_filter($status['events'], static function ($e) {
            return ($e['event'] ?? '') === 'sent';
        }));
        Log::add('formtest', $sent > 0 ? 'ok' : 'info', $sent > 0 ? "Formulartest: {$sent} Mail(s) an die Testadresse" : 'Formulartest beendet, keine Mail');
        return $status;
    }
}
