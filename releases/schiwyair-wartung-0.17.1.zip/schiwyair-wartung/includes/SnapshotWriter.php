<?php

namespace Schiwyair\Wartung;

defined('ABSPATH') || exit;

/**
 * Schreibt den Datenstrom der Sicherung: Tar-Archiv → gzip → verschlüsselte Stücke.
 *
 * Jeder Aufruf (Etappe) beginnt ein neues gzip-Mitglied und schließt es am Ende ab. Aneinandergehängte
 * gzip-Mitglieder sind eine gültige .tar.gz-Datei (gzip, GNU tar, Node zlib). So muss zwischen zwei
 * Anfragen kein Kompressor-Zustand gespeichert werden.
 *
 * Ein Stück wird geschlossen, sobald es die Zielgröße erreicht (Schlussblock mit Kennzeichen „final“).
 * Es liegt dann zum Abholen bereit; erst nach der Bestätigung der Zentrale wird es gelöscht.
 */
final class SnapshotWriter
{
    /** Höchstens so viele fertige, noch nicht abgeholte Stücke liegen auf der Seite */
    public const MAX_READY = 1;

    /** @var array Zustand (wird vom Aufrufer gespeichert) */
    public $state;
    /** @var string */
    private $dir;
    /** @var string */
    private $id;
    /** @var string */
    private $key;
    /** @var resource|null */
    private $deflate = null;
    /** @var int */
    private $level = 0;
    /** @var string komprimierte, noch nicht verschlüsselte Daten */
    private $buffer = '';
    /** @var resource|null */
    private $part = null;

    public static function initialState(): array
    {
        return [
            'part' => 0,          // Nummer des offenen Stücks (0 = keins offen)
            'part_bytes' => 0,
            'block' => 0,         // nächste Blocknummer im offenen Stück
            'ready' => [],        // fertige Stücke [{n, size, sha256}]
            'acked' => [],        // bestätigte Stücknummern
            'closed' => [],       // alle geschlossenen Stücke (für das Inhaltsverzeichnis)
            'plain_bytes' => 0,   // Bytes des Tar-Stroms
            'written_bytes' => 0, // Bytes in Stücken (verschlüsselt)
        ];
    }

    public function __construct(array $state, string $dir, string $id, string $key, int $partSize)
    {
        $this->state = $state;
        $this->dir = $dir;
        $this->id = $id;
        $this->key = $key;
        $this->state['part_size'] = $partSize;
    }

    public function readyCount(): int
    {
        return count($this->state['ready']);
    }

    /** Ohne Platz für weitere Stücke darf nicht weitergeschrieben werden */
    public function blocked(): bool
    {
        return $this->readyCount() >= self::MAX_READY;
    }

    /** Stufe 1 für bereits komprimierte Daten (Bilder, Videos, Archive), sonst 6 */
    public function setLevel(int $level): void
    {
        if ($this->deflate !== null && $this->level !== $level) {
            $this->finishMember();
        }
        $this->level = $level;
    }

    public function write(string $data): void
    {
        if ($data === '') {
            return;
        }
        if ($this->deflate === null) {
            $context = deflate_init(ZLIB_ENCODING_GZIP, ['level' => $this->level ?: 6]);
            if ($context === false) {
                throw new \RuntimeException('gzip ließ sich nicht starten');
            }
            $this->deflate = $context;
        }
        $this->state['plain_bytes'] += strlen($data);
        $out = deflate_add($this->deflate, $data, ZLIB_NO_FLUSH);
        if ($out === false) {
            throw new \RuntimeException('gzip-Fehler');
        }
        $this->buffer .= $out;
        $this->drain(false);
    }

    /** Tar-Kopf für eine Datei (mit PAX-Erweiterung für lange oder nicht-ASCII-Namen) */
    public function tarHeader(string $name, int $size, int $mtime, int $mode = 0644): void
    {
        $short = $name;
        if (strlen($name) > 100 || preg_match('/[^\x20-\x7e]/', $name)) {
            $record = self::paxRecord('path', $name);
            $this->write(self::ustarHeader('PaxHeader/' . substr(md5($name), 0, 16), strlen($record), $mtime, 0644, 'x'));
            $this->write($record . self::padding(strlen($record)));
            $short = substr(preg_replace('/[^\x20-\x7e]/', '_', $name), -100);
        }
        $this->write(self::ustarHeader($short, $size, $mtime, $mode, '0'));
    }

    /** Ganze Datei aus einem String (Datenbank-Abschnitte, Inhaltsverzeichnis) */
    public function tarString(string $name, string $content, int $mtime): void
    {
        $this->tarHeader($name, strlen($content), $mtime);
        $this->write($content);
        $this->write(self::padding(strlen($content)));
    }

    public static function padding(int $size): string
    {
        $rest = $size % 512;
        return $rest === 0 ? '' : str_repeat("\0", 512 - $rest);
    }

    /** Schließt das gzip-Mitglied dieser Etappe ab und schreibt alles in die Stücke */
    public function endStep(): void
    {
        $this->finishMember();
        $this->drain(true);
        if ($this->part !== null) {
            fclose($this->part);
            $this->part = null;
        }
    }

    /** Letzte Etappe: Tar-Ende, letztes Stück schließen */
    public function finish(): void
    {
        $this->write(str_repeat("\0", 1024));
        $this->finishMember();
        $this->drain(true);
        if ((int) $this->state['part'] > 0) {
            $this->closePart();
        }
        if ($this->part !== null) {
            fclose($this->part);
            $this->part = null;
        }
    }

    public function partPath(int $n): string
    {
        return $this->dir . '/teil-' . sprintf('%05d', $n) . '.sww';
    }

    private function finishMember(): void
    {
        if ($this->deflate === null) {
            return;
        }
        $out = deflate_add($this->deflate, '', ZLIB_FINISH);
        if ($out === false) {
            throw new \RuntimeException('gzip-Fehler');
        }
        $this->buffer .= $out;
        $this->deflate = null;
    }

    /** Verschlüsselt volle Blöcke; mit $all auch den Rest */
    private function drain(bool $all): void
    {
        while (strlen($this->buffer) >= SnapshotCrypto::BLOCK_PLAIN || ($all && $this->buffer !== '')) {
            $chunk = substr($this->buffer, 0, SnapshotCrypto::BLOCK_PLAIN);
            $this->buffer = (string) substr($this->buffer, strlen($chunk));
            $this->writeBlock($chunk);
        }
    }

    private function writeBlock(string $plain): void
    {
        if ((int) $this->state['part'] === 0) {
            $this->openPart();
        }
        $data = SnapshotCrypto::encryptBlock($plain, $this->key, $this->id, (int) $this->state['part'], (int) $this->state['block'], false);
        $this->append($data);
        $this->state['block']++;
        if ((int) $this->state['part_bytes'] >= (int) $this->state['part_size']) {
            $this->closePart();
        }
    }

    private function openPart(): void
    {
        $n = (int) ($this->state['last_part'] ?? 0) + 1;
        $this->state['part'] = $n;
        $this->state['last_part'] = $n;
        $this->state['block'] = 0;
        $this->state['part_bytes'] = 0;
        $path = $this->partPath($n);
        // Reste eines abgebrochenen Versuchs mit derselben Nummer verwerfen
        $this->part = @fopen($path, 'wb');
        if ($this->part === false) {
            $this->part = null;
            throw new \RuntimeException('Stück ließ sich nicht anlegen');
        }
        $this->append(SnapshotCrypto::partHeader($n));
    }

    private function append(string $data): void
    {
        if ($this->part === null) {
            // Offenes Stück einer früheren Etappe: auf den gespeicherten Stand kürzen. Brach die letzte
            // Etappe nach dem Schreiben, aber vor dem Speichern des Zustands ab, fällt der Rest so weg.
            $handle = @fopen($this->partPath((int) $this->state['part']), 'cb');
            if ($handle === false || !ftruncate($handle, (int) $this->state['part_bytes']) || fseek($handle, 0, SEEK_END) !== 0) {
                throw new \RuntimeException('Stück ließ sich nicht öffnen');
            }
            $this->part = $handle;
        }
        $written = fwrite($this->part, $data);
        if ($written !== strlen($data)) {
            throw new \RuntimeException('Schreiben fehlgeschlagen (Speicherplatz voll?)');
        }
        $this->state['part_bytes'] += $written;
        $this->state['written_bytes'] += $written;
    }

    private function closePart(): void
    {
        $n = (int) $this->state['part'];
        $this->append(SnapshotCrypto::encryptBlock('', $this->key, $this->id, $n, (int) $this->state['block'], true));
        if ($this->part !== null) {
            fflush($this->part);
            fclose($this->part);
            $this->part = null;
        }
        clearstatcache(true, $this->partPath($n));
        $info = [
            'n' => $n,
            'size' => (int) filesize($this->partPath($n)),
            'sha256' => (string) hash_file('sha256', $this->partPath($n)),
        ];
        $this->state['ready'][] = $info;
        $this->state['closed'][] = $info;
        $this->state['part'] = 0;
        $this->state['part_bytes'] = 0;
        $this->state['block'] = 0;
    }

    private static function paxRecord(string $key, string $value): string
    {
        $body = ' ' . $key . '=' . $value . "\n";
        $length = strlen($body) + 1;
        while (strlen($length . $body) !== $length) {
            $length = strlen($length . $body);
        }
        return $length . $body;
    }

    private static function ustarHeader(string $name, int $size, int $mtime, int $mode, string $type): string
    {
        $mtime = max(0, min($mtime, 077777777777));
        $header = str_pad(substr($name, 0, 100), 100, "\0")
            . sprintf('%07o', $mode & 0777) . "\0"
            . sprintf('%07o', 0) . "\0"
            . sprintf('%07o', 0) . "\0"
            . sprintf('%011o', $size) . "\0"
            . sprintf('%011o', $mtime) . "\0"
            . '        '
            . $type
            . str_repeat("\0", 100)
            . "ustar\0" . '00'
            . str_pad('', 32, "\0")
            . str_pad('', 32, "\0")
            . sprintf('%07o', 0) . "\0"
            . sprintf('%07o', 0) . "\0"
            . str_repeat("\0", 155)
            . str_repeat("\0", 12);
        $sum = 0;
        for ($i = 0; $i < 512; $i++) {
            $sum += ord($header[$i]);
        }
        return substr_replace($header, sprintf('%06o', $sum) . "\0 ", 148, 8);
    }
}
