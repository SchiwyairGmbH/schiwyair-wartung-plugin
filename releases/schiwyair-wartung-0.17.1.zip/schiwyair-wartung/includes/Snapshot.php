<?php

namespace Schiwyair\Wartung;

defined('ABSPATH') || exit;

/**
 * Eigene Sicherung (ab 0.17.0), gesteuert von der Zentrale. Plan: docs/plan-eigene-sicherung.md,
 * Format: docs/sicherung-format.md.
 *
 * Die Zentrale ruft start, dann so lange step, bis die Sicherung fertig ist. Fertige Stücke holt sie mit
 * part ab und bestätigt sie mit ack, erst dann werden sie hier gelöscht. Jede Etappe arbeitet nur wenige
 * Sekunden; es läuft nichts im Hintergrund und kein WP-Cron.
 *
 * Arbeitsordner: wp-content/sww-sicherung-<Zufall> mit Zugriffssperre. Die Stücke sind verschlüsselt,
 * der Schlüssel der Sicherung liegt nur während der Arbeit dort und wird am Ende gelöscht.
 */
final class Snapshot
{
    public const OPTION = 'schiwyair_wartung_snapshot';
    public const OPTION_LAST = 'schiwyair_wartung_snapshot_last';
    /** Ohne Fortschritt so lange gilt eine Sicherung als verwaist */
    private const STALE_SECONDS = 21600;
    private const MAX_EXCLUDES = 50;

    // ---------- Befehle ----------

    public static function start(array $body): array
    {
        $id = isset($body['id']) && is_string($body['id']) ? $body['id'] : '';
        if (!self::validId($id)) {
            return self::fail('bad_request', 'Ungültige Sicherungs-ID', 400);
        }
        $recipients = self::parseRecipients($body['recipients'] ?? null);
        if ($recipients === null) {
            return self::fail('bad_request', 'Ungültige Empfängerschlüssel', 400);
        }
        $partMb = $body['part_size_mb'] ?? 50;
        if (!is_int($partMb) || $partMb < 1 || $partMb > 90) {
            return self::fail('bad_request', 'Ungültige Stückgröße', 400);
        }
        $excludes = $body['excludes'] ?? [];
        if (!is_array($excludes) || count($excludes) > self::MAX_EXCLUDES) {
            return self::fail('bad_request', 'Ungültige Ausnahmen', 400);
        }
        foreach ($excludes as $exclude) {
            if (!SnapshotFiles::validExclude($exclude)) {
                return self::fail('bad_request', 'Ungültige Ausnahme', 400);
            }
        }
        $problem = self::problem();
        if ($problem !== null) {
            return self::fail('unavailable', $problem, 409);
        }
        if (Lock::current() !== null) {
            return self::fail('locked', 'Es läuft gerade ein Update.', 409);
        }

        $current = self::current();
        if ($current !== null) {
            $state = self::readState($current['dir']);
            if ($current['id'] === $id && $state !== null) {
                return ['ok' => true, 'status' => 200, 'snapshot' => self::summary($state)];
            }
            $updated = $state !== null ? (int) $state['updated_at'] : (int) ($current['started_at'] ?? 0);
            if ($state !== null && $state['phase'] !== 'failed' && time() - $updated < self::STALE_SECONDS) {
                return self::fail('already_running', 'Es läuft bereits eine Sicherung.', 409, ['running' => $current['id']]);
            }
            self::cleanup();
        }
        self::removeStrayDirs(null);

        $content = rtrim(wp_normalize_path(WP_CONTENT_DIR), '/');
        $partSize = $partMb * 1048576;
        $free = function_exists('disk_free_space') ? @disk_free_space($content) : false;
        if ($free !== false && $free < 2 * $partSize + 20 * 1048576) {
            return self::fail('disk_full', 'Zu wenig freier Speicher beim Hoster (' . (int) ($free / 1048576) . ' MB frei).', 409);
        }

        $dir = $content . '/sww-sicherung-' . bin2hex(random_bytes(16));
        if (!@mkdir($dir, 0750)) {
            return self::fail('filesystem', 'Arbeitsordner ließ sich nicht anlegen.', 500);
        }
        PluginCopies::protect($dir);

        $key = random_bytes(32);
        $wraps = [];
        try {
            foreach ($recipients as $recipient) {
                $wraps[] = ['recipient' => $recipient['id']] + SnapshotCrypto::wrapKey($key, $recipient['public_key'], $id);
            }
        } catch (\Throwable $e) {
            self::removeDir($dir);
            return self::fail('bad_request', 'Ungültige Empfängerschlüssel', 400);
        }

        $state = [
            'format' => SnapshotCrypto::FORMAT,
            'id' => $id,
            'created_at' => time(),
            'updated_at' => time(),
            'phase' => 'db',
            'error' => null,
            'key' => base64_encode($key),
            'keys' => $wraps,
            'part_size' => $partSize,
            'writer' => SnapshotWriter::initialState(),
            'db' => SnapshotDb::initialState(),
            'files' => SnapshotFiles::initialState(array_values($excludes)),
            'steps' => 0,
            'manifest' => null,
        ];
        if (!self::writeState($dir, $state)) {
            self::removeDir($dir);
            return self::fail('filesystem', 'Arbeitsordner ist nicht beschreibbar.', 500);
        }
        Lockdown::internalUpdate(self::OPTION, ['id' => $id, 'dir' => $dir, 'started_at' => time()]);
        Log::add('snapshot', 'info', 'Sicherung gestartet (' . count($state['db']['tables']) . ' Tabellen)', ['id' => $id]);
        return ['ok' => true, 'status' => 200, 'snapshot' => self::summary($state)];
    }

    public static function step(string $id): array
    {
        $loaded = self::load($id);
        if (isset($loaded['error'])) {
            return $loaded['error'];
        }
        $dir = $loaded['dir'];
        $lock = @fopen($dir . '/lock', 'cb');
        if ($lock === false || !flock($lock, LOCK_EX | LOCK_NB)) {
            if ($lock !== false) {
                fclose($lock);
            }
            return ['ok' => true, 'status' => 200, 'busy' => true, 'snapshot' => self::summary($loaded['state'])];
        }
        try {
            // Zustand erst unter der Sperre lesen (eine parallele Etappe könnte ihn gerade geändert haben)
            $state = self::readState($dir);
            if ($state === null) {
                return self::fail('not_found', 'Sicherung nicht gefunden', 404);
            }
            if (in_array($state['phase'], ['done', 'failed'], true)) {
                return ['ok' => true, 'status' => 200, 'snapshot' => self::summary($state)];
            }
            if (function_exists('set_time_limit')) {
                @set_time_limit(120);
            }
            $deadline = microtime(true) + self::budget();
            try {
                self::work($state, $dir, $deadline);
            } catch (\Throwable $e) {
                $state['phase'] = 'failed';
                $state['error'] = Redact::text($e->getMessage(), 300);
                unset($state['key']);
                Log::add('snapshot', 'error', 'Sicherung fehlgeschlagen: ' . $state['error'], ['id' => $id]);
            }
            $state['updated_at'] = time();
            $state['steps']++;
            if (!self::writeState($dir, $state)) {
                return self::fail('filesystem', 'Zustand ließ sich nicht speichern (Speicherplatz?)', 500);
            }
            $summary = self::summary($state);
            if ($state['phase'] === 'failed') {
                return self::fail('failed', (string) $state['error'], 500, ['snapshot' => $summary]);
            }
            return ['ok' => true, 'status' => 200, 'snapshot' => $summary];
        } finally {
            flock($lock, LOCK_UN);
            fclose($lock);
        }
    }

    /** Pfad und Größe eines fertigen Stücks zum Herunterladen, sonst Fehler */
    public static function partFile(string $id, int $n): array
    {
        $loaded = self::load($id);
        if (isset($loaded['error'])) {
            return $loaded['error'];
        }
        foreach ($loaded['state']['writer']['ready'] as $part) {
            if ((int) $part['n'] === $n) {
                $path = $loaded['dir'] . '/teil-' . sprintf('%05d', $n) . '.sww';
                if (!is_file($path)) {
                    return self::fail('not_found', 'Stück fehlt', 404);
                }
                return ['ok' => true, 'status' => 200, 'path' => $path, 'size' => (int) $part['size'], 'sha256' => (string) $part['sha256']];
            }
        }
        return self::fail('not_ready', 'Stück ist nicht bereit', 409);
    }

    public static function ack(string $id, int $n): array
    {
        $loaded = self::load($id);
        if (isset($loaded['error'])) {
            return $loaded['error'];
        }
        $dir = $loaded['dir'];
        $lock = @fopen($dir . '/lock', 'cb');
        if ($lock === false || !flock($lock, LOCK_EX)) {
            return self::fail('filesystem', 'Sperre ließ sich nicht setzen', 500);
        }
        try {
            $state = self::readState($dir);
            if ($state === null) {
                return self::fail('not_found', 'Sicherung nicht gefunden', 404);
            }
            $found = false;
            foreach ($state['writer']['ready'] as $i => $part) {
                if ((int) $part['n'] === $n) {
                    unset($state['writer']['ready'][$i]);
                    $found = true;
                }
            }
            $state['writer']['ready'] = array_values($state['writer']['ready']);
            if (!$found && !in_array($n, $state['writer']['acked'], true)) {
                return self::fail('not_ready', 'Stück ist nicht bereit', 409);
            }
            if ($found) {
                @unlink($dir . '/teil-' . sprintf('%05d', $n) . '.sww');
                $state['writer']['acked'][] = $n;
            }
            $state['updated_at'] = time();
            $complete = $state['phase'] === 'done' && $state['writer']['ready'] === [];
            if ($complete) {
                self::finishCleanup($state);
            } else {
                self::writeState($dir, $state);
            }
            return ['ok' => true, 'status' => 200, 'snapshot' => self::summary($state), 'complete' => $complete];
        } finally {
            flock($lock, LOCK_UN);
            fclose($lock);
        }
    }

    public static function abort(string $id): array
    {
        $current = self::current();
        if ($current === null || $current['id'] !== $id) {
            return ['ok' => true, 'status' => 200, 'aborted' => false];
        }
        self::cleanup();
        Log::add('snapshot', 'info', 'Sicherung abgebrochen', ['id' => $id]);
        return ['ok' => true, 'status' => 200, 'aborted' => true];
    }

    /** Kurzinfo für /status und GET /snapshot/status */
    public static function info(): array
    {
        $current = self::current();
        $state = $current !== null ? self::readState($current['dir']) : null;
        $last = get_option(self::OPTION_LAST, null);
        return [
            'available' => self::problem() === null,
            'problem' => self::problem(),
            'engine' => SnapshotCrypto::problem() === null ? SnapshotCrypto::engine() : null,
            'current' => $state !== null ? self::summary($state, false) : null,
            'last' => is_array($last) ? $last : null,
        ];
    }

    // ---------- Arbeit ----------

    private static function work(array &$state, string $dir, float $deadline): void
    {
        $key = base64_decode((string) $state['key'], true);
        if (!is_string($key) || strlen($key) !== 32) {
            throw new \RuntimeException('Schlüssel der Sicherung fehlt');
        }
        $writer = new SnapshotWriter($state['writer'], $dir, $state['id'], $key, (int) $state['part_size']);
        try {
            while (microtime(true) < $deadline && !$writer->blocked()) {
                if ($state['phase'] === 'db') {
                    if (SnapshotDb::step($state['db'], $writer, $deadline)) {
                        $state['phase'] = 'files';
                    }
                } elseif ($state['phase'] === 'files') {
                    $files = &$state['files'];
                    if ($files['phase'] === 'scan') {
                        if (SnapshotFiles::scan($files, $dir . '/dateiliste.txt', $deadline)) {
                            $files['phase'] = 'pack';
                        }
                    } elseif (SnapshotFiles::pack($files, $dir . '/dateiliste.txt', $writer, $deadline)) {
                        $state['phase'] = 'finish';
                    }
                    unset($files);
                } elseif ($state['phase'] === 'finish') {
                    $writer->setLevel(6);
                    $writer->tarString('sww-inhalt.json', (string) wp_json_encode(self::contents($state), JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE), time());
                    $writer->finish();
                    $state['writer'] = $writer->state;
                    $state['phase'] = 'done';
                    $state['finished_at'] = time();
                    unset($state['key']);
                    @unlink($dir . '/dateiliste.txt');
                    $state['manifest'] = self::manifest($state);
                    Log::add('snapshot', 'ok', 'Sicherung erstellt (' . count($state['writer']['closed']) . ' Stücke, ' . size_format((int) $state['writer']['written_bytes']) . ')', ['id' => $state['id']]);
                    return;
                } else {
                    return;
                }
            }
            $writer->endStep();
        } finally {
            if ($state['phase'] !== 'done') {
                $state['writer'] = $writer->state;
            }
        }
    }

    /** Arbeitszeit je Etappe: 15 Sekunden, bei knappem Zeitlimit des Servers ein Drittel davon */
    private static function budget(): float
    {
        $limit = (int) ini_get('max_execution_time');
        $budget = 15.0;
        if ($limit > 0) {
            $budget = min($budget, $limit / 3);
        }
        return max(2.0, $budget);
    }

    /** Inhaltsverzeichnis im Archiv (ohne Stücke, die stehen erst danach fest) */
    private static function contents(array $state): array
    {
        global $wpdb;
        return [
            'format' => SnapshotCrypto::FORMAT,
            'id' => $state['id'],
            'created_at' => gmdate('c', (int) $state['created_at']),
            'site' => Auth::siteHost(),
            'home_url' => home_url('/'),
            'site_url' => site_url('/'),
            'wordpress' => get_bloginfo('version'),
            'php' => PHP_VERSION,
            'plugin_version' => SCHIWYAIR_WARTUNG_VERSION,
            'multisite' => is_multisite(),
            'database' => [
                'prefix' => $wpdb->base_prefix,
                'charset' => isset($wpdb->charset) ? (string) $wpdb->charset : null,
                'tables' => $state['db']['tables'],
                'rows' => (int) $state['db']['rows'],
                'sections' => (int) $state['db']['section'],
            ],
            'files' => [
                'count' => (int) $state['files']['packed'],
                'bytes' => (int) $state['files']['packed_bytes'],
                'skipped' => $state['files']['skipped'],
                'excludes' => $state['files']['excludes'],
                'wp_content_dir' => SnapshotFiles::contentDir(),
                'abspath' => rtrim(wp_normalize_path(ABSPATH), '/'),
            ],
        ];
    }

    private static function manifest(array $state): array
    {
        return [
            'format' => SnapshotCrypto::FORMAT,
            'id' => $state['id'],
            'created_at' => (int) $state['created_at'],
            'finished_at' => (int) $state['finished_at'],
            'keys' => $state['keys'],
            'parts' => $state['writer']['closed'],
            'tar_bytes' => (int) $state['writer']['plain_bytes'],
            'bytes' => (int) $state['writer']['written_bytes'],
            'engine' => SnapshotCrypto::engine(),
            'steps' => (int) $state['steps'] + 1,
            'contents' => self::contents($state),
        ];
    }

    private static function summary(array $state, bool $withManifest = true): array
    {
        $files = $state['files'];
        $summary = [
            'id' => $state['id'],
            'phase' => $state['phase'],
            'done' => $state['phase'] === 'done',
            'error' => $state['error'],
            'created_at' => (int) $state['created_at'],
            'updated_at' => (int) $state['updated_at'],
            'ready' => array_values($state['writer']['ready']),
            'acked' => count($state['writer']['acked']),
            'progress' => [
                'db_tables' => count($state['db']['tables']),
                'db_table' => (int) $state['db']['index'],
                'db_rows' => (int) $state['db']['rows'],
                'files_listed' => (int) $files['listed'],
                'files_listed_bytes' => (int) $files['listed_bytes'],
                'files_scanned' => $files['phase'] !== 'scan',
                'files_packed' => (int) $files['packed'],
                'files_packed_bytes' => (int) $files['packed_bytes'],
                'tar_bytes' => (int) $state['writer']['plain_bytes'],
                'written_bytes' => (int) $state['writer']['written_bytes'],
            ],
        ];
        if ($withManifest && $state['phase'] === 'done') {
            $summary['manifest'] = $state['manifest'];
        }
        return $summary;
    }

    // ---------- Ablage ----------

    public static function problem(): ?string
    {
        if (!function_exists('deflate_init')) {
            return 'zlib (gzip) ist auf dem Server nicht verfügbar';
        }
        if (is_multisite()) {
            return 'Multisite wird von der eigenen Sicherung noch nicht unterstützt';
        }
        return SnapshotCrypto::problem();
    }

    public static function validId($id): bool
    {
        return is_string($id) && (bool) preg_match('/^[0-9a-f]{32}\z/', $id);
    }

    private static function parseRecipients($value): ?array
    {
        if (!is_array($value) || count($value) < 1 || count($value) > 3) {
            return null;
        }
        $result = [];
        foreach ($value as $recipient) {
            $rid = is_array($recipient) && isset($recipient['id']) && is_string($recipient['id']) ? $recipient['id'] : '';
            $key = is_array($recipient) ? SnapshotCrypto::decodePublicKey($recipient['public_key'] ?? null) : null;
            if (!preg_match('/^[a-z0-9_-]{1,20}\z/', $rid) || $key === null) {
                return null;
            }
            $result[] = ['id' => $rid, 'public_key' => $key];
        }
        return $result;
    }

    /** @return array{id: string, dir: string, started_at: int}|null */
    private static function current(): ?array
    {
        $value = get_option(self::OPTION, null);
        if (!is_array($value) || !self::validId($value['id'] ?? null) || !self::isOwnDir((string) ($value['dir'] ?? ''))) {
            return null;
        }
        return $value;
    }

    /** @return array{dir: string, state: array}|array{error: array} */
    private static function load(string $id): array
    {
        if (!self::validId($id)) {
            return ['error' => self::fail('bad_request', 'Ungültige Sicherungs-ID', 400)];
        }
        $current = self::current();
        if ($current === null || $current['id'] !== $id) {
            return ['error' => self::fail('not_found', 'Sicherung nicht gefunden', 404)];
        }
        $state = self::readState($current['dir']);
        if ($state === null) {
            return ['error' => self::fail('not_found', 'Sicherung nicht gefunden', 404)];
        }
        return ['dir' => $current['dir'], 'state' => $state];
    }

    public static function isOwnDir(string $path): bool
    {
        $content = rtrim(wp_normalize_path(WP_CONTENT_DIR), '/');
        return (bool) preg_match('#^' . preg_quote($content, '#') . '/sww-sicherung-[0-9a-f]{32}\z#', rtrim(wp_normalize_path($path), '/'));
    }

    private static function readState(string $dir): ?array
    {
        $raw = @file_get_contents($dir . '/state.json');
        $state = is_string($raw) ? json_decode($raw, true) : null;
        return is_array($state) && isset($state['id'], $state['phase']) ? $state : null;
    }

    private static function writeState(string $dir, array $state): bool
    {
        $json = wp_json_encode($state);
        if (!is_string($json)) {
            return false;
        }
        $tmp = $dir . '/state.json.tmp';
        if (@file_put_contents($tmp, $json) !== strlen($json)) {
            return false;
        }
        return @rename($tmp, $dir . '/state.json');
    }

    /** Fertig und alles abgeholt: Ordner weg, Kurzinfo merken */
    private static function finishCleanup(array $state): void
    {
        Lockdown::internalUpdate(self::OPTION_LAST, [
            'id' => $state['id'],
            'finished_at' => (int) ($state['finished_at'] ?? time()),
            'parts' => count($state['writer']['closed']),
            'bytes' => (int) $state['writer']['written_bytes'],
        ]);
        self::cleanup();
    }

    private static function cleanup(): void
    {
        $current = self::current();
        if ($current !== null) {
            self::removeDir($current['dir']);
        }
        delete_option(self::OPTION);
    }

    /** Übrig gebliebene Arbeitsordner (z. B. nach einem Abbruch), außer dem aktuellen */
    private static function removeStrayDirs(?string $keep): void
    {
        $content = rtrim(wp_normalize_path(WP_CONTENT_DIR), '/');
        foreach ((array) @scandir($content) as $entry) {
            if (is_string($entry) && preg_match('/^sww-sicherung-[0-9a-f]{32}\z/', $entry)) {
                $path = $content . '/' . $entry;
                if ($path !== $keep && self::isOwnDir($path)) {
                    self::removeDir($path);
                }
            }
        }
    }

    private static function removeDir(string $dir): void
    {
        if (!self::isOwnDir($dir) || !is_dir($dir) || is_link($dir)) {
            return;
        }
        foreach ((array) @scandir($dir) as $entry) {
            if (!is_string($entry) || $entry === '.' || $entry === '..') {
                continue;
            }
            $path = $dir . '/' . $entry;
            if (is_file($path) || is_link($path)) {
                @unlink($path);
            }
        }
        @rmdir($dir);
    }

    private static function fail(string $code, string $message, int $status, array $extra = []): array
    {
        return ['ok' => false, 'status' => $status, 'code' => $code, 'message' => $message] + $extra;
    }
}
