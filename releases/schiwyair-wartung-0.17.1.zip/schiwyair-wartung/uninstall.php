<?php
/**
 * Entfernt beim Löschen des Plugins alle Optionen und Tabellen restlos.
 */

defined('WP_UNINSTALL_PLUGIN') || exit;

global $wpdb;

$sww_options = [
    'schiwyair_wartung_public_key',
    'schiwyair_wartung_ip_allowlist',
    'schiwyair_wartung_client_ip_source',
    'schiwyair_wartung_last_success',
    'schiwyair_wartung_last_failure',
    'schiwyair_wartung_db_version',
    'schiwyair_wartung_copy_dir',
    'schiwyair_wartung_lock',
    'schiwyair_wartung_backup_job',
    'schiwyair_wartung_formtest',
    'schiwyair_wartung_file_editor_off',
    'schiwyair_wartung_lockdown',
    'schiwyair_wartung_update_seen',
    'schiwyair_wartung_snapshot',
    'schiwyair_wartung_snapshot_last',
];

// Plugin-Kopien löschen (außerhalb des Webroots oder im zufällig benannten Ordner in wp-content)
$sww_remove_dir = static function ($dir) use (&$sww_remove_dir) {
    if (!is_string($dir) || $dir === '' || !is_dir($dir) || is_link($dir)) {
        return;
    }
    foreach ((array) scandir($dir) as $entry) {
        if ($entry === '.' || $entry === '..') {
            continue;
        }
        $path = $dir . '/' . $entry;
        is_dir($path) && !is_link($path) ? $sww_remove_dir($path) : @unlink($path);
    }
    @rmdir($dir);
};

// Nur Ordner, die das Plugin selbst anlegt (wie PluginCopies::isOwnDir): voller Pfad, nicht nur der Name
$sww_parent = realpath(dirname(untrailingslashit(ABSPATH)));
$sww_parent = $sww_parent ? rtrim(wp_normalize_path($sww_parent), '/') : null;
$sww_content = rtrim(wp_normalize_path(WP_CONTENT_DIR), '/');
$sww_own_dir = static function ($path) use ($sww_parent, $sww_content) {
    $path = rtrim(wp_normalize_path((string) $path), '/');
    if ($sww_parent !== null && ($path === $sww_parent . '/schiwyair-wartung-kopien'
        || preg_match('#^' . preg_quote($sww_parent, '#') . '/sww-kopien-[0-9a-f]{32}\z#', $path))) {
        return true;
    }
    return (bool) preg_match('#^' . preg_quote($sww_content, '#') . '/sww-kopien-[0-9a-f]{16,32}\z#', $path);
};

$sww_delete_site_data = static function () use ($sww_options, $sww_remove_dir, $sww_own_dir) {
    $copies = get_option('schiwyair_wartung_copy_dir');
    if (is_array($copies) && !empty($copies['path']) && $sww_own_dir($copies['path'])) {
        $sww_remove_dir($copies['path']);
    }
    foreach ($sww_options as $option) {
        delete_option($option);
    }
    delete_transient('sww_selftest_result');
    delete_transient('sww_update_manifest');
};

if (is_multisite()) {
    foreach (get_sites(['fields' => 'ids', 'number' => 0]) as $sww_blog_id) {
        switch_to_blog($sww_blog_id);
        $sww_delete_site_data();
        restore_current_blog();
    }
} else {
    $sww_delete_site_data();
}

// Ordner mit dem früheren festen Namen außerhalb des Webroots und beiseitegelegte Plugin-Ordner
if ($sww_parent !== null) {
    $sww_remove_dir($sww_parent . '/schiwyair-wartung-kopien');
}
foreach ((array) @scandir(WP_PLUGIN_DIR) as $sww_entry) {
    if (is_string($sww_entry) && preg_match('/^\.sww-alt-[A-Za-z0-9._-]+\z/', $sww_entry)) {
        $sww_path = WP_PLUGIN_DIR . '/' . $sww_entry;
        is_dir($sww_path) && !is_link($sww_path) ? $sww_remove_dir($sww_path) : @unlink($sww_path);
    }
}

// Arbeitsordner der eigenen Sicherung (nur Dateien direkt darin, keine Unterordner)
foreach ((array) @scandir(WP_CONTENT_DIR) as $sww_entry) {
    if (is_string($sww_entry) && preg_match('/^sww-sicherung-[0-9a-f]{32}\z/', $sww_entry)) {
        $sww_remove_dir(rtrim(wp_normalize_path(WP_CONTENT_DIR), '/') . '/' . $sww_entry);
    }
}

$wpdb->query('DROP TABLE IF EXISTS `' . $wpdb->base_prefix . 'sww_nonces`');
$wpdb->query('DROP TABLE IF EXISTS `' . $wpdb->base_prefix . 'sww_throttle`');
$wpdb->query('DROP TABLE IF EXISTS `' . $wpdb->base_prefix . 'sww_log`');
